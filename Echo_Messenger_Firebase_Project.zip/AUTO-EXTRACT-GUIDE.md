# GitHub Actions: automatic ZIP extraction

The workflow at `.github/workflows/build.yml` now:

1. Looks for an Android Gradle project already in the repository (including inside a subfolder).
2. If it cannot find one, searches for a ZIP archive and extracts it automatically.
3. Locates `settings.gradle` and runs `gradle assembleDebug` from that project root.
4. Uploads the generated debug APK as the `Echo-Messenger-APK` artifact.

## Use from a phone
- Upload this project's files to your GitHub repository, keeping `.github/workflows/build.yml`.
- If uploading only the ZIP, place the project ZIP in the repository root (or a folder up to four levels deep).
- Open **Actions → Build Echo Messenger APK → Run workflow**.
- Download `Echo-Messenger-APK` under the completed run's Artifacts.

Keep `google-services.json` at `app/google-services.json` if your app uses Firebase. Do not commit private service-account keys.
