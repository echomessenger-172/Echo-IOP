# Echo Messenger 0.8.0 Beta — implementation notes

## Implemented in this source update
- Android app version bumped to `0.8.0-beta` (`versionCode 8`).
- Echo Stories 2.0 composer: text-only stories, selectable background colors, 24-hour expiration, story cards, emoji reactions stored under each story, and owner deletion.
- Added a community creation entry. Communities currently use the existing group chat model and save `isCommunity` plus `communityDescription` metadata; a separate community feed/role hierarchy is not yet implemented.
- Updated Firestore rules to permit signed-in users to create/update their own per-story reaction document with an allowlisted emoji.
- No Firebase Storage dependency was added.

## Firebase setup
1. Keep your project's `app/google-services.json` in the project (it is not included in this archive).
2. Publish `firestore.rules` in Firebase Console before testing story reactions.
3. Existing `users/{uid}/stories/{storyId}` rules remain owner-write; story reactions are saved in `users/{uid}/stories/{storyId}/reactions/{uid}`.
4. Stories are text-only. Images, videos, real-time voice/video calling, and server-driven notification delivery are not added by this patch.

## Build
Build with the repository's GitHub Actions workflow (`workflow_dispatch`). This environment did not run a complete Android/Gradle build, so treat the archive as source code awaiting CI verification.
