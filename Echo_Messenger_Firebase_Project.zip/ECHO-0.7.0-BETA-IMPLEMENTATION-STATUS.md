# Echo Messenger 0.7.0 Beta — implementation status

## Included in this package
- App version set to `0.7.0-beta` / versionCode `7`.
- Scheduled text messages: scheduling screen, list/cancel UI, Firestore rules, and `dispatchScheduledMessages` Cloud Function.
- FCM message notifications for chat messages, plus an incoming-call invitation notification trigger.
- Echo Bots: local `/help`, `/time`, `/echo`, `/dice`, `/coin`, and `/id` demo commands.
- Echo Translate UI and a callable `translateText` Cloud Function using Google Cloud Translation.
- Privacy settings include online-visibility preference; user block list and unblock UI are persisted in the user's Firestore profile.
- Echo Calls invitation signaling: create an audio-call invitation, query incoming invitations, accept/decline, and FCM incoming-call notification.
- Firestore rules for call invitation documents.
- No Firebase Storage dependency or usage was added.

## Required Firebase setup
1. Keep `app/google-services.json` for the correct Firebase Android app in place (it is intentionally not included in this ZIP).
2. Deploy Firestore rules: `firebase deploy --only firestore:rules`.
3. From `functions/`, run `npm install`, then deploy with `firebase deploy --only functions`.
4. For translation, enable **Cloud Translation API** in the linked Google Cloud project, enable billing as required, and ensure the Cloud Functions runtime service account has permission to call it.
5. Ensure Firestore scheduled-message indexes are created if Firebase prompts for one. The once-per-minute scheduler may require the Blaze plan.
6. Build the APK with GitHub Actions; download `app-debug.apk` from the workflow artifact.

## Important limitations — not to misrepresent as finished
- Echo Calls currently implements call invitations/signaling only. It does **not** stream live audio yet; real in-app audio needs WebRTC peer connections and STUN/TURN configuration.
- Echo Bots are local demo commands, not a public bot platform or remotely programmable bot API.
- Blocking is stored on the current user's profile and prevents starting a direct chat from this client. It is not yet a complete server-enforced block across all clients, groups, and message reads; do not treat it as a security boundary.
- `presence_visible` is a saved preference only; online presence visibility is not yet enforced by all profile/query surfaces.
- Translation requires Cloud Translation API setup and may incur Google Cloud charges.
- The Android APK has not been built or device-tested in this environment. The project must pass GitHub Actions before calling this release build-verified.
