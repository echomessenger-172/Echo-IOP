# Echo Messenger 0.6.0 Beta — implementation plan

## Target stack
- Existing Android Java project; keep Firebase Authentication, Cloud Firestore and Firebase Cloud Messaging.
- No Firebase Storage. Do not store audio/photo/video bytes in Firestore documents.
- Build from Android phone with the existing GitHub Actions workflow.
- `versionCode = 6`, `versionName = 0.6.0-beta`.

## Scope
1. Chats 3.0: preserve existing direct/group/channel messaging; verify send, reply, reactions, edit/delete, read status and permissions.
2. Voice messages 2.0: recording UI, preview, playback speed and send only after choosing a media upload endpoint. This cannot be completed end-to-end without an external upload server or another storage provider.
3. Liquid Glass 2.0: consolidate settings and chat controls on the existing dark card theme and vector drawable icons; retain the Liquid Glass preference.
4. Favorites 2.0: save a message from its long-press menu, add personal text notes, list/copy/delete saved items under `users/{uid}/favorites`.
5. PIN/biometric protection: first pass includes local PIN setup/hash and manual lock verification. Startup/background auto-lock and Android BiometricPrompt still need lifecycle integration; do not advertise those as complete yet.
6. Echo Easter eggs: secret section and a test trigger; wire the 10-tap app-title trigger to the actual image resource in a follow-up.
7. Chat folders: create/delete local folder names. Assigning chats to folders and cross-device sync remain follow-up work.
8. Echo Stories: text stories stored under `users/{uid}/stories`, with 24-hour expiry metadata. Photo/video stories require external storage.
9. Groups and channels 2.0: retain existing implementation and test owner/admin/member permissions and invites; deeper role management is follow-up work.
10. Echo Plus 2.0: improve the existing benefits page; real payments/subscriptions are not connected.

## Firestore additions
- `users/{uid}/favorites/{favoriteId}`: only that UID may read/write.
- `users/{uid}/stories/{storyId}`: signed-in users may read; owner may create/update/delete own stories.
- Existing chat rules remain in place. Validate chat queries against Firestore rules; rules are not filters.

## 115 MB target
115 MB is a target for the installed app plus local cache/data, not a guaranteed APK size. Do not add dummy files to inflate the app. Keep the APK optimized and use a bounded media/cache policy once real media downloads exist. APK size, installed size and user data vary by Android version/device.

## Validation checklist
- Run GitHub Actions and resolve compiler errors first.
- Test two accounts: create direct chat, send/receive, reopen chat, reply, react, edit/delete, save message to Favorites.
- Verify Favorites and Stories with Firestore Rules Emulator/Rules Playground before publishing.
- Test PIN setup and manual unlock; do not treat it as full app locking until startup/background gating is implemented.
- Test on Android 13+ notification permission and FCM token registration.
- Do not publish production rules until queries are tested against them.
