# Echo Messenger 0.9.0 Beta — implementation notes

## Added in this source update
- Android version bumped to `0.9.0-beta` (`versionCode 9`).
- Echo Assist Beta: offline message-draft templates for friendly replies, refusals, apologies, invitations, and project announcements. Drafts can be shared through Android's share sheet. This is template-based, not a connected generative AI service.
- Echo Plus page now includes four saved profile-accent presets and a preview card. The selection is stored locally; it does not yet recolor the entire app or activate paid benefits.
- Data settings now provide a share/export of visible profile fields, excluding passwords, tokens, and private conversations.
- Settings About entry updated to 0.9.0 Beta.
- No Firebase Storage dependency added.

## Existing functionality retained
The archive is based on Echo Messenger 0.8.0 Beta, including text-only Echo Stories and the community creation entry. Stories still use Firestore and expire based on client-side checks when displayed.

## Limitations
- No real generative AI backend, paid subscription billing, biometric integration, photo/video stories, or WebRTC calls were added.
- Echo Plus themes currently affect the preview card only.
- This environment did not run a full Android/Gradle build; run the GitHub Actions workflow to validate compilation. Keep your own `app/google-services.json` in the project; it is intentionally not included.
