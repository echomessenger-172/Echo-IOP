const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

function requireOwner(request) {
  if (!request.auth || request.auth.token.owner !== true) {
    throw new HttpsError('permission-denied', 'Only the Echo owner can perform this action.');
  }
}
function targetUid(request) {
  const uid = request.data && request.data.uid;
  if (typeof uid !== 'string' || uid.length < 10 || uid.length > 128) {
    throw new HttpsError('invalid-argument', 'A valid target UID is required.');
  }
  if (uid === request.auth.uid) {
    throw new HttpsError('failed-precondition', 'This action cannot be applied to the owner account.');
  }
  return uid;
}

exports.setUserVerification = onCall(async request => {
  requireOwner(request); const uid = targetUid(request);
  const ref = db.collection('users').doc(uid); const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User not found.');
  const next = snap.get('verified') !== true;
  await ref.set({ verified: next, verificationUpdatedAt: FieldValue.serverTimestamp(), verificationUpdatedBy: request.auth.uid }, { merge: true });
  return { uid, verified: next };
});

exports.setUserPremium = onCall(async request => {
  requireOwner(request); const uid = targetUid(request);
  const ref = db.collection('users').doc(uid); const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User not found.');
  const next = snap.get('premium') !== true;
  await ref.set({ premium: next, premiumUpdatedAt: FieldValue.serverTimestamp(), premiumUpdatedBy: request.auth.uid }, { merge: true });
  return { uid, premium: next };
});

exports.setUserRole = onCall(async request => {
  requireOwner(request); const uid = targetUid(request);
  const ref = db.collection('users').doc(uid); const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User not found.');
  const next = snap.get('role') === 'moderator' ? 'user' : 'moderator';
  await ref.set({ role: next, roleUpdatedAt: FieldValue.serverTimestamp(), roleUpdatedBy: request.auth.uid }, { merge: true });
  return { uid, role: next };
});

exports.setUserBanned = onCall(async request => {
  requireOwner(request); const uid = targetUid(request);
  const ref = db.collection('users').doc(uid); const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User not found.');
  const next = snap.get('banned') !== true;
  await ref.set({ banned: next, bannedAt: next ? FieldValue.serverTimestamp() : null, bannedBy: request.auth.uid }, { merge: true });
  return { uid, banned: next };
});


// Send FCM push notifications to other members when a chat message is created.
// Deploy with: firebase deploy --only functions:notifyChatMembers
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { getMessaging } = require('firebase-admin/messaging');

exports.notifyChatMembers = onDocumentCreated('chats/{chatId}/messages/{messageId}', async event => {
  const message = event.data && event.data.data();
  if (!message || !message.sender) return;
  const chatSnap = await db.collection('chats').doc(event.params.chatId).get();
  if (!chatSnap.exists) return;
  const chat = chatSnap.data() || {};
  const members = Array.isArray(chat.members) ? chat.members : [];
  const recipientIds = members.filter(id => id && id !== message.sender);
  if (!recipientIds.length) return;
  const senderName = typeof message.senderName === 'string' ? message.senderName : 'Новое сообщение';
  const body = typeof message.text === 'string' ? message.text.slice(0, 180) : 'Отправлено новое сообщение';
  const tokens = [];
  for (const recipientId of recipientIds) {
    const user = await db.collection('users').doc(recipientId).get();
    if (!user.exists) continue;
    const token = user.get('fcmToken');
    if (typeof token === 'string' && token.length > 20) tokens.push({ token, recipientId });
  }
  if (!tokens.length) return;
  const response = await getMessaging().sendEach(tokens.map(({ token }) => ({
    token,
    notification: { title: senderName, body },
    data: { chatId: event.params.chatId, messageId: event.params.messageId, type: 'chat_message' },
    android: { priority: 'high', notification: { channelId: 'echo_messages' } }
  })));
  const stale = [];
  response.responses.forEach((result, index) => {
    if (!result.success && result.error && ['messaging/registration-token-not-registered', 'messaging/invalid-registration-token'].includes(result.error.code)) stale.push(tokens[index]);
  });
  await Promise.all(stale.map(({ token, recipientId }) => db.collection('users').doc(recipientId).update({ fcmToken: FieldValue.delete() }).catch(() => {})));
});

// Dispatch scheduled text messages once per minute. Cloud Scheduler may require
// the Firebase project to be on the Blaze billing plan.
const { onSchedule } = require('firebase-functions/v2/scheduler');
exports.dispatchScheduledMessages = onSchedule('every 1 minutes', async () => {
  const now = new Date();
  const due = await db.collection('scheduledMessages')
    .where('status', '==', 'pending')
    .where('dueAt', '<=', now)
    .limit(100).get();
  for (const item of due.docs) {
    const ref = item.ref;
    let data;
    try {
      await db.runTransaction(async tx => {
        const fresh = await tx.get(ref);
        if (!fresh.exists || fresh.get('status') !== 'pending') return;
        data = fresh.data();
        tx.update(ref, { status: 'sending', processingAt: FieldValue.serverTimestamp() });
      });
      if (!data) continue;
      const chatId = typeof data.chatId === 'string' ? data.chatId : '';
      const sender = typeof data.sender === 'string' ? data.sender : '';
      const text = typeof data.text === 'string' ? data.text.trim() : '';
      if (!sender || !text || text.length > 4000 || !chatId) throw new Error('Invalid scheduled message');
      const general = data.general === true;
      if (!general) {
        const chatSnap = await db.collection('chats').doc(chatId).get();
        if (!chatSnap.exists) throw new Error('Chat no longer exists');
        const chat = chatSnap.data() || {};
        const members = Array.isArray(chat.members) ? chat.members : [];
        if (!members.includes(sender) && !(chat.type === 'channel' && chat.owner === sender)) throw new Error('Sender is no longer allowed to post');
      }
      const message = {
        text, sender,
        senderName: typeof data.senderName === 'string' ? data.senderName : 'Echo user',
        createdAt: FieldValue.serverTimestamp(),
        readBy: [sender]
      };
      if (typeof data.replyTo === 'string') message.replyTo = data.replyTo;
      if (typeof data.replyText === 'string') message.replyText = data.replyText;
      const messagesRef = general
        ? db.collection('rooms').doc('general').collection('messages')
        : db.collection('chats').doc(chatId).collection('messages');
      await messagesRef.add(message);
      if (!general) await db.collection('chats').doc(chatId).update({
        lastText: text, lastSender: message.senderName, lastAt: FieldValue.serverTimestamp()
      });
      await ref.update({ status: 'sent', sentAt: FieldValue.serverTimestamp() });
    } catch (error) {
      console.error('Scheduled message dispatch failed', ref.id, error);
      await ref.update({ status: 'failed', error: String(error.message || error).slice(0, 300), failedAt: FieldValue.serverTimestamp() }).catch(() => {});
    }
  }
});

// Translate text through Google Cloud Translation. Enable the Cloud Translation API
// and ensure the Functions runtime service account has permission to use it.
const { onCall: onTranslateCall } = require('firebase-functions/v2/https');
const { Translate } = require('@google-cloud/translate').v2;
const translator = new Translate();
exports.translateText = onTranslateCall(async request => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in to translate text.');
  const text = request.data && request.data.text;
  const target = request.data && request.data.target;
  const allowed = new Set(['en','ru','uk','zh','es','fr','de','ja']);
  if (typeof text !== 'string' || !text.trim() || text.length > 4000)
    throw new HttpsError('invalid-argument', 'Text must contain 1–4000 characters.');
  if (typeof target !== 'string' || !allowed.has(target))
    throw new HttpsError('invalid-argument', 'Unsupported target language.');
  try {
    const [translatedText] = await translator.translate(text.trim(), target);
    return { translatedText, target };
  } catch (e) {
    console.error('Translation failed', e);
    throw new HttpsError('failed-precondition', 'Translation service unavailable. Enable Cloud Translation API and billing.', { reason: String(e.message || e).slice(0, 180) });
  }
});

// Notify the callee that an audio-call invitation has arrived. This is signaling
// only; media transport must be provided by a WebRTC client implementation.
exports.notifyIncomingCall = onDocumentCreated('calls/{callId}', async event => {
  const call = event.data && event.data.data();
  if (!call || call.kind !== 'audio' || !call.callerUid || !call.calleeUid) return;
  const user = await db.collection('users').doc(call.calleeUid).get();
  const token = user.exists ? user.get('fcmToken') : null;
  if (typeof token !== 'string' || token.length < 20) return;
  await getMessaging().send({
    token,
    notification: { title: 'Входящий вызов Echo', body: 'Тебе поступил аудиовызов' },
    data: { type: 'incoming_call', callId: event.params.callId, callerUid: call.callerUid },
    android: { priority: 'high', notification: { channelId: 'echo_messages' } }
  });
});

// ---------------------------------------------------------------------------
// Echo 0.10: media upload (Cloudflare R2 / any S3-compatible bucket) and story cleanup
// ---------------------------------------------------------------------------
const { defineSecret, defineString } = require('firebase-functions/params');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const crypto = require('crypto');

const R2_ACCOUNT_ID = defineSecret('R2_ACCOUNT_ID');
const R2_ACCESS_KEY_ID = defineSecret('R2_ACCESS_KEY_ID');
const R2_SECRET_ACCESS_KEY = defineSecret('R2_SECRET_ACCESS_KEY');
const R2_BUCKET = defineString('R2_BUCKET');
const R2_PUBLIC_BASE = defineString('R2_PUBLIC_BASE'); // e.g. https://media.example.com (no trailing slash)

const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
const UPLOADS_PER_HOUR = 60;
// Allow-list only. No html/svg/js so an uploaded file can never run as a page on the media domain.
const ALLOWED_TYPE = /^(image\/(jpeg|png|gif|webp|heic|heif)|video\/(mp4|quicktime|webm)|audio\/(mpeg|mp4|ogg|webm|aac|wav|x-m4a)|application\/(pdf|zip|msword|octet-stream|vnd\.[a-z0-9.+-]+)|text\/plain)$/i;

exports.getUploadUrl = onCall(
  { secrets: [R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY] },
  async request => {
    if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in to upload files.');
    const uid = request.auth.uid;
    const { name, contentType, size, chatId, general } = request.data || {};

    if (typeof contentType !== 'string' || !ALLOWED_TYPE.test(contentType))
      throw new HttpsError('invalid-argument', 'This file type is not allowed.');
    if (!Number.isInteger(size) || size <= 0 || size > MAX_UPLOAD_BYTES)
      throw new HttpsError('invalid-argument', 'File must be between 1 byte and 25 MB.');
    if (typeof chatId !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(chatId))
      throw new HttpsError('invalid-argument', 'Invalid chat.');

    // The sender must really be allowed to post in this chat.
    if (general === true) {
      if (chatId !== 'general') throw new HttpsError('invalid-argument', 'Invalid room.');
    } else {
      const chat = await db.collection('chats').doc(chatId).get();
      if (!chat.exists) throw new HttpsError('not-found', 'Chat not found.');
      const c = chat.data();
      const allowed = c.type === 'channel' ? c.owner === uid : Array.isArray(c.members) && c.members.includes(uid);
      if (!allowed) throw new HttpsError('permission-denied', 'You cannot post in this chat.');
    }

    // Simple hourly quota per user.
    const hour = Math.floor(Date.now() / 3600000);
    const quotaRef = db.collection('uploadQuota').doc(uid + '_' + hour);
    await db.runTransaction(async tx => {
      const q = await tx.get(quotaRef);
      const n = q.exists ? q.data().count : 0;
      if (n >= UPLOADS_PER_HOUR) throw new HttpsError('resource-exhausted', 'Upload limit reached. Try again later.');
      tx.set(quotaRef, { count: n + 1, uid, hour });
    });

    const safe = String(name || 'file').replace(/[^A-Za-z0-9._-]/g, '_').slice(-80) || 'file';
    const key = `chat/${chatId}/${uid}/${Date.now()}-${crypto.randomUUID()}-${safe}`;

    const s3 = new S3Client({
      region: 'auto',
      endpoint: `https://${R2_ACCOUNT_ID.value()}.r2.cloudflarestorage.com`,
      credentials: { accessKeyId: R2_ACCESS_KEY_ID.value(), secretAccessKey: R2_SECRET_ACCESS_KEY.value() },
      requestChecksumCalculation: 'WHEN_REQUIRED',
      responseChecksumValidation: 'WHEN_REQUIRED'
    });
    const uploadUrl = await getSignedUrl(
      s3,
      new PutObjectCommand({ Bucket: R2_BUCKET.value(), Key: key, ContentType: contentType, ContentLength: size }),
      { expiresIn: 300 }
    );
    return { uploadUrl, publicUrl: `${R2_PUBLIC_BASE.value().replace(/\/$/, '')}/${key}`, key };
  }
);

// Stories live 24 h. Clients already hide expired ones; this actually deletes them (and their reactions).
exports.cleanupExpiredStories = onSchedule('every 60 minutes', async () => {
  const now = Date.now();
  for (let round = 0; round < 5; round++) {
    const snap = await db.collectionGroup('stories').where('expiresAt', '<', now).limit(200).get();
    if (snap.empty) return;
    for (const doc of snap.docs) {
      if (doc.ref.path.startsWith('users/')) await db.recursiveDelete(doc.ref);
    }
    if (snap.size < 200) return;
  }
});

// Old hourly quota counters are useless after a day.
exports.cleanupUploadQuota = onSchedule('every 24 hours', async () => {
  const cutoff = Math.floor(Date.now() / 3600000) - 24;
  const snap = await db.collection('uploadQuota').where('hour', '<', cutoff).limit(400).get();
  const batch = db.batch();
  snap.docs.forEach(d => batch.delete(d.ref));
  if (!snap.empty) await batch.commit();
});
