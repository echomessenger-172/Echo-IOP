// Run only in a trusted environment with Firebase Admin credentials.
// This project owner UID is preconfigured; never ship a service-account key in the APK.
const { initializeApp, applicationDefault } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const OWNER_UID = 'IJ3sGSDS8GPYuggABp9H4uYF74Y2';
const uid = process.argv[2] || OWNER_UID;
if (!process.env.PROJECT_ID) {
  console.error('Missing PROJECT_ID environment variable.');
  process.exit(1);
}
initializeApp({ credential: applicationDefault(), projectId: process.env.PROJECT_ID });
(async () => {
  await getAuth().setCustomUserClaims(uid, { owner: true });
  console.log(`Owner claim assigned to ${uid}. Sign out/in or refresh the ID token.`);
})().catch(err => { console.error(err); process.exit(1); });
