# Echo Messenger Cloud Functions

These functions provide server-authoritative moderation actions. They require a trusted Firebase project with billing/Cloud Functions enabled.

## Deploy
1. From the project root, install Firebase CLI and run `firebase login`.
2. Run `firebase init functions` only if you need to create/link `.firebaserc`; choose JavaScript and Node 20, keeping this `functions` directory.
3. Run `cd functions && npm install`.
4. From the project root run `firebase deploy --only functions`.
5. Assign the `owner: true` custom claim to the owner's Auth UID from a trusted environment using `set-owner-claim.js`. Never place a service-account key in the Android app or GitHub repository.
6. Sign out/in on the owner account to refresh the ID token. The owner panel appears on the profile screen.

Callable functions: `setUserVerification`, `setUserPremium`, `setUserRole`, `setUserBanned`. They verify the `owner` custom claim on the server and write moderation fields with Admin SDK. The app checks the `banned` field after sign-in and blocks access if it is true.

FCM sending still requires a separate trusted notification trigger; the Android service can receive notifications and refresh the token, but client code must never send notifications using service-account credentials.

## Grant the project owner from GitHub Actions (phone-friendly)

The owner UID is preconfigured as `IJ3sGSDS8GPYuggABp9H4uYF74Y2`. In GitHub repository Settings → Secrets and variables → Actions, add:

- `FIREBASE_PROJECT_ID`: the Firebase project ID (not its display name).
- `FIREBASE_SERVICE_ACCOUNT_JSON`: the complete JSON key for a trusted Firebase service account with permission to update Firebase Authentication custom claims. Keep this secret private; never add the JSON key to the repository or APK.

Then open Actions → **Grant Echo Owner Access** → Run workflow. A successful run assigns `owner: true` to the configured UID. In Echo Messenger, sign out and sign back in (after confirming the email if required), then open your profile; the **👑 Панель владельца Echo** button should appear. If the workflow fails, check that the UID belongs to an existing Firebase Authentication user and the secrets are correct.

The workflow changes the Firebase Auth custom claim only. It does not create the Firebase project or deploy the callable moderation functions; deploy `functions/index.js` separately if the owner panel's moderation buttons are not yet deployed.
