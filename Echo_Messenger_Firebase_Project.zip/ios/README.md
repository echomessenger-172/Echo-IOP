# Echo Messenger — iOS (SwiftUI)

Нативная iOS-версия Echo, использует тот же Firebase-проект (Auth + Firestore) и те же правила `firestore.rules`, что и Android.

## Как собрать IPA на GitHub
1. В Firebase Console → Project settings → **Add app → iOS**, Bundle ID: `com.echo.messenger`. Скачай `GoogleService-Info.plist`.
2. Положи его в `ios/Echo/GoogleService-Info.plist` **или** добавь секрет репозитория `IOS_GOOGLE_SERVICE_INFO_PLIST_BASE64` (`base64 -i GoogleService-Info.plist | pbcopy`).
3. GitHub → **Actions → Build Echo Messenger IPA (iOS) → Run workflow**.
4. Скачай артефакт `Echo-Messenger-IPA` → `Echo-unsigned.ipa`.

IPA **не подписан**. Установить: Sideloadly / AltStore (подпишут твоим Apple ID, 7 дней), TrollStore, либо подписать своим сертификатом.

## Этап 1 (готово)
Вход / регистрация по почте, подтверждение почты, сброс пароля, выбор username (транзакция `usernames`), список чатов (realtime), общий чат, личные чаты, поиск людей, сообщения (отправка, ответ, правка, удаление, реакции, закрепление, избранное, статус «прочитано»), профиль, избранное, чёрный список.

## Дальше
2 — группы и каналы, вступление по @username, настройки чата; 3 — истории, посты профиля, отложенные сообщения; 4 — push (APNs), фото/файлы, автоблокировка, остальные разделы.
