import Foundation
import FirebaseFirestore

struct Profile {
    var name: String = ""
    var username: String = ""
    var about: String = ""
    var verified: Bool = false
    var blocked: [String] = []

    init() {}

    init(data: [String: Any]) {
        name = data["name"] as? String ?? ""
        username = data["username"] as? String ?? ""
        about = data["about"] as? String ?? ""
        verified = data["verified"] as? Bool ?? false
        blocked = data["blockedUsers"] as? [String] ?? []
    }
}

struct Chat: Identifiable, Hashable {
    static let generalId = "general"

    var id: String
    var name: String
    var type: String            // direct | group | channel
    var owner: String
    var members: [String]
    var lastText: String
    var lastSender: String
    var lastAt: Date?
    var createdAt: Date?
    var username: String
    var verified: Bool
    var pinnedId: String?
    var pinnedText: String?

    static var general: Chat {
        Chat(id: generalId, name: "Общий чат", type: "group", owner: "", members: [],
             lastText: "", lastSender: "", lastAt: nil, createdAt: nil, username: "",
             verified: false, pinnedId: nil, pinnedText: nil)
    }

    init(id: String, name: String, type: String, owner: String, members: [String],
         lastText: String, lastSender: String, lastAt: Date?, createdAt: Date?,
         username: String, verified: Bool, pinnedId: String?, pinnedText: String?) {
        self.id = id; self.name = name; self.type = type; self.owner = owner
        self.members = members; self.lastText = lastText; self.lastSender = lastSender
        self.lastAt = lastAt; self.createdAt = createdAt; self.username = username
        self.verified = verified; self.pinnedId = pinnedId; self.pinnedText = pinnedText
    }

    init?(doc: DocumentSnapshot) {
        guard let d = doc.data(with: .estimate) else { return nil }
        self.init(
            id: doc.documentID,
            name: d["name"] as? String ?? "Чат",
            type: d["type"] as? String ?? "direct",
            owner: d["owner"] as? String ?? "",
            members: d["members"] as? [String] ?? [],
            lastText: d["lastText"] as? String ?? "",
            lastSender: d["lastSender"] as? String ?? "",
            lastAt: (d["lastAt"] as? Timestamp)?.dateValue(),
            createdAt: (d["createdAt"] as? Timestamp)?.dateValue(),
            username: d["username"] as? String ?? "",
            verified: d["verified"] as? Bool ?? false,
            pinnedId: d["pinnedMessageId"] as? String,
            pinnedText: d["pinnedMessageText"] as? String
        )
    }

    var sortDate: Date { lastAt ?? createdAt ?? .distantPast }

    func otherMember(me: String?) -> String? {
        guard type == "direct" else { return nil }
        return members.first { $0 != me }
    }

    static func == (a: Chat, b: Chat) -> Bool { a.id == b.id }
    func hash(into h: inout Hasher) { h.combine(id) }
}

struct Message: Identifiable, Equatable {
    var id: String
    var text: String
    var sender: String
    var senderName: String
    var createdAt: Date?
    var readBy: [String]
    var replyTo: String?
    var replyText: String?
    var reactions: [String: String]

    init?(doc: DocumentSnapshot) {
        guard let d = doc.data(with: .estimate) else { return nil }
        id = doc.documentID
        text = d["text"] as? String ?? ""
        sender = d["sender"] as? String ?? ""
        senderName = d["senderName"] as? String ?? ""
        createdAt = (d["createdAt"] as? Timestamp)?.dateValue()
        readBy = d["readBy"] as? [String] ?? []
        replyTo = d["replyTo"] as? String
        replyText = d["replyText"] as? String
        var r: [String: String] = [:]
        if let map = d["reactions"] as? [String: Any] {
            for (k, v) in map { if let s = v as? String { r[k] = s } }
        }
        reactions = r
        if let mt = d["mediaType"] as? String, text.isEmpty {
            text = mt == "image" ? "📷 Фото" : "📎 Файл"
        }
    }
}

struct DirectoryUser: Identifiable {
    var id: String
    var name: String
    var username: String
    var verified: Bool
}

struct Favorite: Identifiable {
    var id: String
    var text: String
    var chatName: String?
}
