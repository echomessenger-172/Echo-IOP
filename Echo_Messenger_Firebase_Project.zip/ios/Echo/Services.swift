import Foundation
import FirebaseAuth
import FirebaseFirestore

enum EchoError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let m) = self { return m }
        return nil
    }
}

func friendlyError(_ error: Error) -> String {
    let ns = error as NSError
    if ns.domain == "FIRAuthErrorDomain", let code = AuthErrorCode.Code(rawValue: ns.code) {
        switch code {
        case .wrongPassword, .invalidCredential, .userNotFound: return "Неверная почта или пароль"
        case .invalidEmail: return "Некорректный адрес почты"
        case .emailAlreadyInUse: return "Эта почта уже зарегистрирована"
        case .weakPassword: return "Слишком простой пароль (минимум 6 символов)"
        case .networkError: return "Нет соединения с интернетом"
        case .tooManyRequests: return "Слишком много попыток, попробуй позже"
        case .userDisabled: return "Аккаунт отключён"
        default: break
        }
    }
    if ns.domain == "FIRFirestoreErrorDomain" && ns.code == 7 {
        return "Недостаточно прав (проверь правила Firestore)"
    }
    return error.localizedDescription
}

func messagesRef(_ chatId: String) -> CollectionReference {
    let db = Firestore.firestore()
    if chatId == Chat.generalId {
        return db.collection("rooms").document("general").collection("messages")
    }
    return db.collection("chats").document(chatId).collection("messages")
}

enum ChatService {
    static let db = Firestore.firestore()

    static func send(chat: Chat, uid: String, senderName: String, text: String,
                     replyTo: Message?) async throws {
        var m: [String: Any] = [
            "text": text,
            "sender": uid,
            "senderName": senderName,
            "createdAt": FieldValue.serverTimestamp(),
            "readBy": [uid]
        ]
        if let r = replyTo {
            m["replyTo"] = r.id
            m["replyText"] = r.text
        }
        try await messagesRef(chat.id).addDocument(data: m)
        if chat.id != Chat.generalId {
            try await db.collection("chats").document(chat.id).updateData([
                "lastText": text,
                "lastSender": senderName,
                "lastAt": FieldValue.serverTimestamp()
            ])
        }
    }

    static func edit(chatId: String, messageId: String, text: String) async throws {
        try await messagesRef(chatId).document(messageId).updateData(["text": text])
    }

    static func delete(chatId: String, messageId: String) async throws {
        try await messagesRef(chatId).document(messageId).delete()
    }

    static func react(chatId: String, messageId: String, uid: String, emoji: String) async throws {
        try await messagesRef(chatId).document(messageId).updateData(["reactions.\(uid)": emoji])
    }

    static func markRead(chatId: String, messageId: String, uid: String) {
        messagesRef(chatId).document(messageId).updateData(["readBy": FieldValue.arrayUnion([uid])])
    }

    static func pin(chatId: String, message: Message) async throws {
        try await db.collection("chats").document(chatId).updateData([
            "pinnedMessageId": message.id,
            "pinnedMessageText": message.text
        ])
    }

    static func unpin(chatId: String) async throws {
        try await db.collection("chats").document(chatId).updateData([
            "pinnedMessageId": FieldValue.delete(),
            "pinnedMessageText": FieldValue.delete()
        ])
    }

    static func saveFavorite(uid: String, chat: Chat, title: String, message: Message) async throws {
        try await db.collection("users").document(uid).collection("favorites")
            .document("\(chat.id)_\(message.id)")
            .setData([
                "text": message.text,
                "chatId": chat.id,
                "chatName": title,
                "messageId": message.id,
                "createdAt": FieldValue.serverTimestamp()
            ])
    }

    /// Finds an existing direct chat with `otherUid` or creates a new one.
    static func openDirect(myUid: String, otherUid: String, otherName: String) async throws -> Chat {
        if myUid == otherUid { throw EchoError.message("Нельзя начать диалог с самим собой") }
        let me = try await db.collection("users").document(myUid).getDocument()
        let blocked = me.data()?["blockedUsers"] as? [String] ?? []
        if blocked.contains(otherUid) {
            throw EchoError.message("Сначала разблокируй этого пользователя")
        }
        let key = myUid < otherUid ? "\(myUid)_\(otherUid)" : "\(otherUid)_\(myUid)"
        // Rules allow reading chats only for members, so query by members first.
        let snap = try await db.collection("chats").whereField("members", arrayContains: myUid).getDocuments()
        for d in snap.documents {
            guard let chat = Chat(doc: d), chat.type == "direct", chat.members.contains(otherUid) else { continue }
            let existingKey = d.data()["directKey"] as? String ?? ""
            if existingKey.isEmpty || existingKey == key { return chat }
        }
        let ref = db.collection("chats").document()
        try await ref.setData([
            "name": otherName,
            "type": "direct",
            "owner": myUid,
            "members": [myUid, otherUid],
            "directKey": key,
            "createdAt": FieldValue.serverTimestamp(),
            "lastText": ""
        ])
        return Chat(id: ref.documentID, name: otherName, type: "direct", owner: myUid,
                    members: [myUid, otherUid], lastText: "", lastSender: "", lastAt: nil,
                    createdAt: Date(), username: "", verified: false, pinnedId: nil, pinnedText: nil)
    }

    static func loadUsers(excluding uid: String?) async throws -> [DirectoryUser] {
        let snap = try await db.collection("users").limit(to: 100).getDocuments()
        return snap.documents.compactMap { d in
            if d.documentID == uid { return nil }
            let data = d.data()
            return DirectoryUser(
                id: d.documentID,
                name: data["name"] as? String ?? "Пользователь",
                username: data["username"] as? String ?? "",
                verified: data["verified"] as? Bool ?? false)
        }
    }
}
