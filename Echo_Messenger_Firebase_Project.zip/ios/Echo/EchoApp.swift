import SwiftUI
import FirebaseCore

@main
struct EchoApp: App {
    @StateObject private var session: Session
    @Environment(\.scenePhase) private var scenePhase

    init() {
        FirebaseApp.configure()
        _session = StateObject(wrappedValue: Session())
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .preferredColorScheme(.dark)
                .tint(Theme.accent)
        }
        .onChange(of: scenePhase) { phase in
            session.setPresence(online: phase == .active)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var session: Session

    var body: some View {
        ZStack {
            AuroraBackground()
            switch session.state {
            case .loading:
                ProgressView().scaleEffect(1.4)
            case .signedOut:
                AuthView()
            case .needsVerification(let email):
                VerifyEmailView(email: email)
            case .onboarding:
                OnboardingView()
            case .ready:
                MainTabs()
            }
        }
        .animation(.easeInOut(duration: 0.25), value: session.stateKey)
    }
}

struct MainTabs: View {
    var body: some View {
        TabView {
            ChatsView()
                .tabItem { Label("Чаты", systemImage: "bubble.left.and.bubble.right.fill") }
            ProfileView()
                .tabItem { Label("Профиль", systemImage: "person.crop.circle.fill") }
        }
    }
}
