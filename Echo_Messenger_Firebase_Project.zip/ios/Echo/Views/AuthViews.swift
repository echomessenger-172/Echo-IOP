import SwiftUI

struct AuthView: View {
    enum Mode { case login, register, reset }

    @EnvironmentObject var session: Session
    @State private var mode: Mode = .login
    @State private var email = ""
    @State private var password = ""
    @State private var busy = false
    @State private var message: String?
    @State private var isError = false

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                Spacer(minLength: 60)
                Text("Echo").font(.system(size: 44, weight: .bold, design: .rounded)).foregroundColor(Theme.text)
                Text(subtitle).foregroundColor(Theme.muted)

                VStack(spacing: 12) {
                    TextField("Электронная почта", text: $email)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled()
                        .padding(14).glass(14)
                    if mode != .reset {
                        SecureField("Пароль", text: $password)
                            .padding(14).glass(14)
                    }
                }

                if let message = message {
                    Text(message).font(.footnote)
                        .foregroundColor(isError ? .red : .green)
                        .multilineTextAlignment(.center)
                }

                Button(action: submit) {
                    if busy { ProgressView().tint(.white) } else { Text(buttonTitle) }
                }
                .buttonStyle(PrimaryButtonStyle())
                .disabled(busy)

                VStack(spacing: 10) {
                    if mode == .login {
                        Button("Нет аккаунта? Регистрация") { switchTo(.register) }
                        Button("Забыли пароль?") { switchTo(.reset) }
                    } else {
                        Button("Назад ко входу") { switchTo(.login) }
                    }
                }
                .font(.subheadline)
            }
            .padding(.horizontal, 24)
        }
    }

    private var subtitle: String {
        switch mode {
        case .login: return "Войди в аккаунт"
        case .register: return "Создай аккаунт"
        case .reset: return "Сброс пароля"
        }
    }

    private var buttonTitle: String {
        switch mode {
        case .login: return "Войти"
        case .register: return "Зарегистрироваться"
        case .reset: return "Отправить письмо"
        }
    }

    private func switchTo(_ m: Mode) {
        mode = m
        message = nil
    }

    private func submit() {
        let em = email.trimmed
        guard em.contains("@"), em.contains(".") else { show("Введи корректный адрес почты", error: true); return }
        if mode != .reset && password.count < 6 { show("Пароль — минимум 6 символов", error: true); return }
        busy = true
        Task {
            defer { busy = false }
            do {
                switch mode {
                case .login: try await session.signIn(email: em, password: password)
                case .register: try await session.register(email: em, password: password)
                case .reset:
                    try await session.resetPassword(email: em)
                    show("Письмо для сброса пароля отправлено", error: false)
                }
            } catch {
                show(friendlyError(error), error: true)
            }
        }
    }

    private func show(_ text: String, error: Bool) {
        message = text
        isError = error
    }
}

struct VerifyEmailView: View {
    @EnvironmentObject var session: Session
    let email: String
    @State private var message: String?
    @State private var busy = false

    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: "envelope.badge").font(.system(size: 54)).foregroundColor(Theme.accent)
            Text("Подтверди почту").font(.title2.bold()).foregroundColor(Theme.text)
            Text("Мы отправили письмо на\n\(email)\nПерейди по ссылке в письме, затем вернись сюда.")
                .multilineTextAlignment(.center).foregroundColor(Theme.muted)
            if let message = message {
                Text(message).font(.footnote).foregroundColor(Theme.muted).multilineTextAlignment(.center)
            }
            Button("Я подтвердил(а)") { run { try await session.recheckVerification() } }
                .buttonStyle(PrimaryButtonStyle()).disabled(busy)
            Button("Отправить письмо ещё раз") {
                run { try await session.resendVerification(); message = "Письмо отправлено" }
            }
            Button("Выйти", role: .destructive) { session.signOut() }
            Spacer()
        }
        .padding(.horizontal, 24)
    }

    private func run(_ work: @escaping () async throws -> Void) {
        busy = true
        Task {
            defer { busy = false }
            do { try await work() } catch { message = friendlyError(error) }
        }
    }
}

struct OnboardingView: View {
    @EnvironmentObject var session: Session
    @State private var username = ""
    @State private var busy = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 16) {
            Spacer()
            Text("Выбери имя пользователя").font(.title2.bold()).foregroundColor(Theme.text)
            Text("Его смогут найти другие люди. 3–24 символа: a–z, 0–9, _")
                .font(.footnote).foregroundColor(Theme.muted).multilineTextAlignment(.center)
            HStack {
                Text("@").foregroundColor(Theme.muted)
                TextField("username", text: $username)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            .padding(14).glass(14)
            if let error = error {
                Text(error).font(.footnote).foregroundColor(.red)
            }
            Button {
                busy = true
                Task {
                    defer { busy = false }
                    do { try await session.claimUsername(username); error = nil }
                    catch { self.error = friendlyError(error) }
                }
            } label: {
                if busy { ProgressView().tint(.white) } else { Text("Продолжить") }
            }
            .buttonStyle(PrimaryButtonStyle()).disabled(busy)
            Button("Выйти", role: .destructive) { session.signOut() }
            Spacer()
        }
        .padding(.horizontal, 24)
    }
}
