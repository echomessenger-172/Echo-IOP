import SwiftUI
import FirebaseFirestore

struct ProfileView: View {
    @EnvironmentObject var session: Session
    @State private var editing = false
    @AppStorage("winterSnow") private var winterSnow = true

    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()
                ScrollView {
                    VStack(spacing: 16) {
                        AvatarView(name: session.profile.name, size: 96).padding(.top, 24)
                        HStack(spacing: 6) {
                            Text(session.profile.name).font(.title2.bold()).foregroundColor(Theme.text)
                            if session.profile.verified {
                                Image(systemName: "checkmark.seal.fill").foregroundColor(Theme.accent)
                            }
                        }
                        Text("@\(session.profile.username)").foregroundColor(Theme.muted)
                        if !session.profile.about.isEmpty {
                            Text(session.profile.about).foregroundColor(Theme.text)
                                .padding(14).frame(maxWidth: .infinity, alignment: .leading).glass()
                        }
                        VStack(spacing: 0) {
                            row("Редактировать профиль", "pencil") { editing = true }
                            Divider().opacity(0.3)
                            NavigationLink { FavoritesView() } label: { rowLabel("Избранное", "star.fill") }
                            Divider().opacity(0.3)
                            NavigationLink { BlockedView() } label: { rowLabel("Заблокированные", "hand.raised.fill") }
                            Divider().opacity(0.3)
                            Toggle(isOn: $winterSnow) {
                                HStack {
                                    Image(systemName: "snowflake").frame(width: 28).foregroundColor(Theme.accent)
                                    Text("Зимний снегопад").foregroundColor(Theme.text)
                                }
                            }
                            .padding(14)
                        }
                        .glass()
                        Button("Выйти из аккаунта", role: .destructive) { session.signOut() }
                            .padding(.top, 8)
                        Text("Echo iOS 1.0.0 · этап 1").font(.caption).foregroundColor(Theme.muted)
                    }
                    .padding(.horizontal, 16)
                }
            }
            .navigationTitle("Профиль")
            .sheet(isPresented: $editing) { EditProfileView() }
        }
    }

    private func row(_ title: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) { rowLabel(title, icon) }
    }

    private func rowLabel(_ title: String, _ icon: String) -> some View {
        HStack {
            Image(systemName: icon).frame(width: 28).foregroundColor(Theme.accent)
            Text(title).foregroundColor(Theme.text)
            Spacer()
            Image(systemName: "chevron.right").font(.caption).foregroundColor(Theme.muted)
        }
        .padding(14)
        .contentShape(Rectangle())
    }
}

struct EditProfileView: View {
    @EnvironmentObject var session: Session
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var about = ""
    @State private var busy = false
    @State private var errorText: String?

    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()
                VStack(spacing: 12) {
                    TextField("Имя", text: $name).padding(14).glass(14)
                    TextField("О себе", text: $about, axis: .vertical).lineLimit(2...5).padding(14).glass(14)
                    if let e = errorText { Text(e).font(.footnote).foregroundColor(.red) }
                    Spacer()
                }
                .padding(16)
            }
            .navigationTitle("Профиль")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Сохранить") {
                        busy = true
                        Task {
                            defer { busy = false }
                            do { try await session.updateProfile(name: name, about: about); dismiss() }
                            catch { errorText = friendlyError(error) }
                        }
                    }
                    .disabled(busy || name.trimmed.isEmpty)
                }
            }
            .onAppear {
                name = session.profile.name
                about = session.profile.about
            }
        }
    }
}

struct FavoritesView: View {
    @EnvironmentObject var session: Session
    @State private var items: [Favorite] = []
    @State private var loading = true
    @State private var adding = false
    @State private var note = ""
    @State private var errorText: String?

    private var col: CollectionReference? {
        guard let uid = session.uid else { return nil }
        return Firestore.firestore().collection("users").document(uid).collection("favorites")
    }

    var body: some View {
        ZStack {
            AuroraBackground()
            List {
                ForEach(items) { f in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(f.text).foregroundColor(Theme.text)
                        if let c = f.chatName { Text("Из чата: \(c)").font(.caption).foregroundColor(Theme.muted) }
                    }
                    .padding(.vertical, 4)
                    .listRowBackground(Color.clear)
                    .contextMenu {
                        Button { UIPasteboard.general.string = f.text } label: { Label("Копировать", systemImage: "doc.on.doc") }
                    }
                }
                .onDelete(perform: delete)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .overlay {
                if loading { ProgressView() }
                else if items.isEmpty {
                    Text("Здесь будут сохранённые сообщения и заметки").foregroundColor(Theme.muted)
                }
            }
        }
        .navigationTitle("Избранное")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { adding = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $adding) {
            NavigationStack {
                TextEditor(text: $note).padding().navigationTitle("Новая заметка")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) { Button("Отмена") { adding = false; note = "" } }
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("Сохранить") { saveNote() }.disabled(note.trimmed.isEmpty)
                        }
                    }
            }
        }
        .alert("Ошибка", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(errorText ?? "") }
        .task { await load() }
    }

    private func load() async {
        guard let col = col else { return }
        do {
            let snap = try await col.order(by: "createdAt", descending: true).limit(to: 100).getDocuments()
            items = snap.documents.map {
                Favorite(id: $0.documentID, text: $0.data()["text"] as? String ?? "",
                         chatName: $0.data()["chatName"] as? String)
            }
        } catch { errorText = friendlyError(error) }
        loading = false
    }

    private func saveNote() {
        let text = note.trimmed
        guard !text.isEmpty, let col = col else { return }
        Task {
            do {
                try await col.addDocument(data: ["text": text, "kind": "note", "createdAt": FieldValue.serverTimestamp()])
                note = ""; adding = false
                await load()
            } catch { errorText = friendlyError(error) }
        }
    }

    private func delete(at offsets: IndexSet) {
        guard let col = col else { return }
        let victims = offsets.map { items[$0] }
        items.remove(atOffsets: offsets)
        for v in victims { col.document(v.id).delete() }
    }
}

struct BlockedView: View {
    @EnvironmentObject var session: Session
    @State private var errorText: String?

    var body: some View {
        ZStack {
            AuroraBackground()
            List(session.profile.blocked, id: \.self) { id in
                HStack {
                    Text(session.userNames[id] ?? id).foregroundColor(Theme.text).lineLimit(1)
                    Spacer()
                    Button("Разблокировать") {
                        Task {
                            do { try await session.unblock(id) } catch { errorText = friendlyError(error) }
                        }
                    }
                    .font(.footnote)
                }
                .listRowBackground(Color.clear)
                .task { await session.loadName(id) }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .overlay {
                if session.profile.blocked.isEmpty {
                    Text("Нет заблокированных пользователей").foregroundColor(Theme.muted)
                }
            }
        }
        .navigationTitle("Заблокированные")
        .alert("Ошибка", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(errorText ?? "") }
    }
}
