import SwiftUI
import FirebaseFirestore

@MainActor
final class ChatsViewModel: ObservableObject {
    @Published var chats: [Chat] = []
    private var listener: ListenerRegistration?
    private var startedFor: String?

    func start(uid: String?) {
        guard let uid = uid, startedFor != uid else { return }
        startedFor = uid
        listener?.remove()
        listener = Firestore.firestore().collection("chats")
            .whereField("members", arrayContains: uid)
            .addSnapshotListener { [weak self] snap, _ in
                guard let snap = snap else { return }
                let items = snap.documents.compactMap { Chat(doc: $0) }
                    .sorted { $0.sortDate > $1.sortDate }
                Task { @MainActor in self?.chats = items }
            }
    }

    func stop() {
        listener?.remove()
        listener = nil
        startedFor = nil
    }

    deinit { listener?.remove() }
}

struct ChatsView: View {
    @EnvironmentObject var session: Session
    @StateObject private var vm = ChatsViewModel()
    @State private var path: [Chat] = []
    @State private var showNew = false

    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                AuroraBackground()
                List {
                    NavigationLink(value: Chat.general) {
                        ChatRow(chat: Chat.general, title: "Общий чат", subtitle: "Комната для всех")
                    }
                    .listRowBackground(Color.clear)
                    ForEach(vm.chats) { chat in
                        NavigationLink(value: chat) {
                            ChatRow(chat: chat, title: session.title(for: chat),
                                    subtitle: subtitle(chat))
                        }
                        .listRowBackground(Color.clear)
                        .task {
                            if let other = chat.otherMember(me: session.uid) { await session.loadName(other) }
                        }
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .overlay {
                    if vm.chats.isEmpty {
                        Text("Пока нет чатов.\nНажми ✎ и найди собеседника.")
                            .multilineTextAlignment(.center).foregroundColor(Theme.muted)
                            .offset(y: 80)
                    }
                }
            }
            .navigationTitle("Echo")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showNew = true } label: { Image(systemName: "square.and.pencil") }
                }
            }
            .navigationDestination(for: Chat.self) { chat in
                ChatView(chat: chat)
            }
            .sheet(isPresented: $showNew) {
                NewChatView { chat in
                    showNew = false
                    path.append(chat)
                }
            }
        }
        .onAppear { vm.start(uid: session.uid) }
    }

    private func subtitle(_ chat: Chat) -> String {
        if chat.lastText.isEmpty { return "Нет сообщений" }
        if chat.type != "direct", !chat.lastSender.isEmpty { return "\(chat.lastSender): \(chat.lastText)" }
        return chat.lastText
    }
}

struct ChatRow: View {
    let chat: Chat
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 12) {
            AvatarView(name: title, size: 52)
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 4) {
                    Text(title).font(.headline).foregroundColor(Theme.text).lineLimit(1)
                    if chat.verified { Image(systemName: "checkmark.seal.fill").foregroundColor(Theme.accent).font(.caption) }
                    if chat.type == "channel" { Image(systemName: "megaphone.fill").foregroundColor(Theme.muted).font(.caption2) }
                }
                Text(subtitle).font(.subheadline).foregroundColor(Theme.muted).lineLimit(1)
            }
            Spacer()
            if let d = chat.lastAt {
                Text(shortTime(d)).font(.caption).foregroundColor(Theme.muted)
            }
        }
        .padding(.vertical, 4)
    }
}

func shortTime(_ date: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = Calendar.current.isDateInToday(date) ? "HH:mm" : "d MMM"
    return f.string(from: date)
}

struct NewChatView: View {
    @EnvironmentObject var session: Session
    let onOpen: (Chat) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var users: [DirectoryUser] = []
    @State private var query = ""
    @State private var loading = true
    @State private var errorText: String?

    private var filtered: [DirectoryUser] {
        let q = query.trimmed.lowercased()
        if q.count < 2 { return users }
        return users.filter { $0.name.lowercased().contains(q) || $0.username.lowercased().contains(q) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AuroraBackground()
                List(filtered) { u in
                    Button { open(u) } label: {
                        HStack(spacing: 12) {
                            AvatarView(name: u.name, size: 44)
                            VStack(alignment: .leading) {
                                HStack(spacing: 4) {
                                    Text(u.name).foregroundColor(Theme.text)
                                    if u.verified { Image(systemName: "checkmark.seal.fill").foregroundColor(Theme.accent).font(.caption) }
                                }
                                if !u.username.isEmpty { Text("@\(u.username)").font(.caption).foregroundColor(Theme.muted) }
                            }
                        }
                    }
                    .listRowBackground(Color.clear)
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .overlay { if loading { ProgressView() } }
            }
            .navigationTitle("Новый чат")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, prompt: "Имя или @username")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Закрыть") { dismiss() } }
            }
            .alert("Ошибка", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(errorText ?? "") }
            .task {
                do { users = try await ChatService.loadUsers(excluding: session.uid) }
                catch { errorText = friendlyError(error) }
                loading = false
            }
        }
    }

    private func open(_ u: DirectoryUser) {
        guard let uid = session.uid else { return }
        Task {
            do {
                let chat = try await ChatService.openDirect(myUid: uid, otherUid: u.id, otherName: u.name)
                session.userNames[u.id] = u.name
                onOpen(chat)
            } catch { errorText = friendlyError(error) }
        }
    }
}
