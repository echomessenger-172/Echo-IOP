import SwiftUI
import FirebaseFirestore

@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [Message] = []
    @Published var chat: Chat
    private var msgListener: ListenerRegistration?
    private var chatListener: ListenerRegistration?
    private var uid: String?

    init(chat: Chat) { self.chat = chat }

    func start(uid: String?) {
        guard msgListener == nil else { return }
        self.uid = uid
        let chatId = chat.id
        msgListener = messagesRef(chatId)
            .order(by: "createdAt")
            .limit(toLast: 300)
            .addSnapshotListener { [weak self] snap, _ in
                guard let snap = snap else { return }
                let items = snap.documents.compactMap { Message(doc: $0) }
                Task { @MainActor in
                    self?.messages = items
                    self?.markRead(items)
                }
            }
        if chatId != Chat.generalId {
            chatListener = Firestore.firestore().collection("chats").document(chatId)
                .addSnapshotListener { [weak self] doc, _ in
                    guard let doc = doc, let c = Chat(doc: doc) else { return }
                    Task { @MainActor in self?.chat = c }
                }
        }
    }

    func stop() {
        msgListener?.remove(); msgListener = nil
        chatListener?.remove(); chatListener = nil
    }

    private func markRead(_ items: [Message]) {
        guard let uid = uid, chat.id != Chat.generalId else { return }
        let isMember = chat.members.contains(uid)
        guard isMember else { return }
        for m in items where m.sender != uid && !m.readBy.contains(uid) {
            ChatService.markRead(chatId: chat.id, messageId: m.id, uid: uid)
        }
    }

    deinit {
        msgListener?.remove()
        chatListener?.remove()
    }
}

struct ChatView: View {
    @EnvironmentObject var session: Session
    @StateObject private var vm: ChatViewModel
    @State private var input = ""
    @State private var replyTo: Message?
    @State private var editing: Message?
    @State private var deleting: Message?
    @State private var errorText: String?
    @State private var toast: String?

    private let emojis = ["👍", "❤️", "😂", "😮", "😢", "🔥"]

    init(chat: Chat) {
        _vm = StateObject(wrappedValue: ChatViewModel(chat: chat))
    }

    private var canPost: Bool {
        vm.chat.type != "channel" || vm.chat.owner == session.uid
    }

    var body: some View {
        ZStack {
            AuroraBackground()
            VStack(spacing: 0) {
                if let pin = vm.chat.pinnedText, !pin.isEmpty { pinBanner(pin) }
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 6) {
                            ForEach(vm.messages) { m in
                                bubble(m).id(m.id)
                            }
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                    }
                    .onChange(of: vm.messages.count) { _ in scrollToEnd(proxy) }
                    .onChange(of: vm.messages.last?.id) { _ in scrollToEnd(proxy) }
                }
            }
        }
        .safeAreaInset(edge: .bottom) { composer }
        .navigationTitle(session.title(for: vm.chat))
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { vm.start(uid: session.uid) }
        .onDisappear { vm.stop() }
        .confirmationDialog("Удалить это сообщение?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let m = deleting { run { try await ChatService.delete(chatId: vm.chat.id, messageId: m.id) } }
                deleting = nil
            }
        }
        .alert("Ошибка", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(errorText ?? "") }
        .overlay(alignment: .top) {
            if let toast = toast {
                Text(toast).font(.footnote).padding(.horizontal, 14).padding(.vertical, 8)
                    .glass(20).padding(.top, 8).transition(.opacity)
            }
        }
    }

    // MARK: Pieces

    private func pinBanner(_ text: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "pin.fill").foregroundColor(Theme.accent)
            Text(text).lineLimit(1).font(.subheadline).foregroundColor(Theme.text)
            Spacer()
            if vm.chat.owner == session.uid {
                Button { run { try await ChatService.unpin(chatId: vm.chat.id) } } label: {
                    Image(systemName: "xmark").foregroundColor(Theme.muted)
                }
            }
        }
        .padding(10).glass(12).padding(.horizontal, 10).padding(.top, 6)
    }

    @ViewBuilder
    private func bubble(_ m: Message) -> some View {
        let mine = m.sender == session.uid
        HStack {
            if mine { Spacer(minLength: 48) }
            VStack(alignment: .leading, spacing: 4) {
                if !mine && vm.chat.type != "direct" && !m.senderName.isEmpty {
                    Text(m.senderName).font(.caption.bold()).foregroundColor(Theme.accent)
                }
                if let rt = m.replyText, !rt.isEmpty {
                    Text(rt).font(.caption).lineLimit(2).foregroundColor(.white.opacity(0.8))
                        .padding(6)
                        .background(Color.black.opacity(0.18), in: RoundedRectangle(cornerRadius: 8))
                }
                Text(m.text).foregroundColor(.white)
                if !m.reactions.isEmpty {
                    Text(reactionSummary(m)).font(.caption)
                }
                HStack(spacing: 4) {
                    Spacer(minLength: 0)
                    if let d = m.createdAt { Text(shortTime(d)).font(.caption2).foregroundColor(.white.opacity(0.65)) }
                    if mine {
                        Image(systemName: m.readBy.count > 1 ? "checkmark.circle.fill" : "checkmark")
                            .font(.caption2).foregroundColor(.white.opacity(0.75))
                    }
                }
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(mine ? Theme.accent : Theme.card2,
                        in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .contextMenu { menu(for: m, mine: mine) }
            if !mine { Spacer(minLength: 48) }
        }
    }

    @ViewBuilder
    private func menu(for m: Message, mine: Bool) -> some View {
        if canPost {
            Button { replyTo = m; editing = nil } label: { Label("Ответить", systemImage: "arrowshape.turn.up.left") }
        }
        Menu {
            ForEach(emojis, id: \.self) { e in
                Button(e) {
                    guard let uid = session.uid else { return }
                    run { try await ChatService.react(chatId: vm.chat.id, messageId: m.id, uid: uid, emoji: e) }
                }
            }
        } label: { Label("Реакция", systemImage: "face.smiling") }
        Button { UIPasteboard.general.string = m.text; flash("Скопировано") } label: { Label("Копировать", systemImage: "doc.on.doc") }
        Button {
            guard let uid = session.uid else { return }
            run {
                try await ChatService.saveFavorite(uid: uid, chat: vm.chat, title: session.title(for: vm.chat), message: m)
                flash("Добавлено в Избранное ⭐")
            }
        } label: { Label("В избранное", systemImage: "star") }
        if vm.chat.id != Chat.generalId {
            Button { run { try await ChatService.pin(chatId: vm.chat.id, message: m) } } label: { Label("Закрепить", systemImage: "pin") }
        }
        if mine {
            Button { editing = m; replyTo = nil; input = m.text } label: { Label("Изменить", systemImage: "pencil") }
            Button(role: .destructive) { deleting = m } label: { Label("Удалить", systemImage: "trash") }
        }
    }

    private var composer: some View {
        VStack(spacing: 0) {
            if let r = replyTo {
                contextBar(icon: "arrowshape.turn.up.left.fill", title: "Ответ", text: r.text) { replyTo = nil }
            }
            if let e = editing {
                contextBar(icon: "pencil", title: "Редактирование", text: e.text) { editing = nil; input = "" }
            }
            if canPost {
                HStack(alignment: .bottom, spacing: 8) {
                    TextField("Сообщение", text: $input, axis: .vertical)
                        .lineLimit(1...5)
                        .padding(.horizontal, 14).padding(.vertical, 10)
                        .glass(20)
                    Button(action: send) {
                        Image(systemName: "arrow.up.circle.fill").font(.system(size: 34))
                            .foregroundColor(input.trimmed.isEmpty ? Theme.muted : Theme.accent)
                    }
                    .disabled(input.trimmed.isEmpty)
                }
                .padding(.horizontal, 10).padding(.vertical, 8)
            } else {
                Text("Публиковать может только владелец канала")
                    .font(.footnote).foregroundColor(Theme.muted).padding(14)
            }
        }
        .background(.ultraThinMaterial)
    }

    private func contextBar(icon: String, title: String, text: String, close: @escaping () -> Void) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon).foregroundColor(Theme.accent)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.caption.bold()).foregroundColor(Theme.accent)
                Text(text).font(.caption).lineLimit(1).foregroundColor(Theme.muted)
            }
            Spacer()
            Button(action: close) { Image(systemName: "xmark.circle.fill").foregroundColor(Theme.muted) }
        }
        .padding(.horizontal, 14).padding(.top, 8)
    }

    // MARK: Actions

    private func send() {
        let text = input.trimmed
        guard !text.isEmpty, let uid = session.uid else { return }
        let reply = replyTo
        let edit = editing
        input = ""
        replyTo = nil
        editing = nil
        let chat = vm.chat
        let name = session.profile.name.isEmpty ? session.profile.username : session.profile.name
        run {
            if let e = edit {
                try await ChatService.edit(chatId: chat.id, messageId: e.id, text: text)
            } else {
                try await ChatService.send(chat: chat, uid: uid, senderName: name, text: text, replyTo: reply)
            }
        }
    }

    private func run(_ work: @escaping () async throws -> Void) {
        Task {
            do { try await work() } catch { errorText = friendlyError(error) }
        }
    }

    private func flash(_ text: String) {
        withAnimation { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { withAnimation { toast = nil } }
    }

    private func scrollToEnd(_ proxy: ScrollViewProxy) {
        guard let last = vm.messages.last else { return }
        withAnimation(.easeOut(duration: 0.2)) { proxy.scrollTo(last.id, anchor: .bottom) }
    }

    private func reactionSummary(_ m: Message) -> String {
        let groups = Dictionary(grouping: m.reactions.values, by: { $0 })
        return groups.map { "\($0.key) \($0.value.count)" }.sorted().joined(separator: "  ")
    }
}
