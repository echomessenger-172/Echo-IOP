import SwiftUI

enum Theme {
    static let bg = Color(red: 8 / 255, green: 26 / 255, blue: 23 / 255)
    static let card = Color(red: 14 / 255, green: 40 / 255, blue: 36 / 255)
    static let card2 = Color(red: 20 / 255, green: 54 / 255, blue: 48 / 255)
    static let text = Color(red: 245 / 255, green: 247 / 255, blue: 249 / 255)
    static let muted = Color(red: 130 / 255, green: 158 / 255, blue: 152 / 255)
    static let accent = Color(red: 28 / 255, green: 168 / 255, blue: 94 / 255)
}

/// Animated "aurora" background (counterpart of AuroraDrawable on Android).
struct AuroraBackground: View {
    @State private var phase = false

    var body: some View {
        ZStack {
            Theme.bg
            Circle().fill(Theme.accent.opacity(0.32))
                .frame(width: 340, height: 340).blur(radius: 90)
                .offset(x: phase ? -110 : 100, y: phase ? -240 : -130)
            Circle().fill(Color.green.opacity(0.18))
                .frame(width: 300, height: 300).blur(radius: 90)
                .offset(x: phase ? 120 : -80, y: phase ? 260 : 150)
            Circle().fill(Color.purple.opacity(0.18))
                .frame(width: 260, height: 260).blur(radius: 90)
                .offset(x: phase ? 60 : -120, y: phase ? 20 : 120)
            SnowView()
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 10).repeatForever(autoreverses: true)) { phase = true }
        }
    }
}

/// "Liquid glass" card (counterpart of LiquidGlassDrawable on Android).
struct GlassModifier: ViewModifier {
    var radius: CGFloat
    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6)
            )
    }
}

extension View {
    func glass(_ radius: CGFloat = 16) -> some View { modifier(GlassModifier(radius: radius)) }
}

struct AvatarView: View {
    let name: String
    var size: CGFloat = 48

    private var initial: String {
        let t = name.trimmingCharacters(in: .whitespaces)
        return t.isEmpty ? "?" : String(t.prefix(1)).uppercased()
    }

    private var color: Color {
        let palette: [Color] = [.blue, .green, .orange, .pink, .purple, .teal, .indigo, .red]
        let h = name.unicodeScalars.reduce(0) { ($0 &* 31 &+ Int($1.value)) % 1000 }
        return palette[h % palette.count]
    }

    var body: some View {
        ZStack {
            Circle().fill(LinearGradient(colors: [color, color.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing))
            Text(initial).font(.system(size: size * 0.42, weight: .semibold)).foregroundColor(.white)
        }
        .frame(width: size, height: size)
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 16, weight: .semibold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Theme.accent.opacity(configuration.isPressed ? 0.7 : 1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .foregroundColor(.white)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}

/// Зимний снегопад на заднем плане (включается в профиле, уважает «Уменьшение движения»).
struct SnowView: View {
    @AppStorage("winterSnow") private var enabled = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private struct Flake {
        let x: Double, speed: Double, off: Double, phase: Double
        let freq: Double, sway: Double, size: Double, alpha: Double
    }

    private static let flakes: [Flake] = {
        var g = SeededGenerator(seed: 2026)
        return (0..<70).map { _ in
            let depth = Double.random(in: 0...1, using: &g)
            return Flake(
                x: Double.random(in: 0...1, using: &g),
                speed: 0.035 + depth * 0.075 + Double.random(in: 0...0.02, using: &g),
                off: Double.random(in: 0...1, using: &g),
                phase: Double.random(in: 0...(2 * .pi), using: &g),
                freq: 0.35 + Double.random(in: 0...0.8, using: &g),
                sway: 6 + Double.random(in: 0...18, using: &g),
                size: 0.9 + depth * depth * 2.6,
                alpha: 0.35 + depth * 0.6)
        }
    }()

    var body: some View {
        Group {
            if enabled && !reduceMotion {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
                    Canvas { ctx, size in
                        let t = timeline.date.timeIntervalSinceReferenceDate
                        for f in SnowView.flakes {
                            let r = f.size
                            let travel = Double(size.height) + 4 * r
                            let y = ((t * f.speed + f.off).truncatingRemainder(dividingBy: 1)) * travel - 2 * r
                            let x = f.x * Double(size.width) + sin(t * f.freq + f.phase) * f.sway
                            let halo = CGRect(x: x - r * 2.2, y: y - r * 2.2, width: r * 4.4, height: r * 4.4)
                            ctx.fill(Path(ellipseIn: halo), with: .color(Color(red: 0.81, green: 0.9, blue: 1).opacity(f.alpha * 0.2)))
                            let core = CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)
                            ctx.fill(Path(ellipseIn: core), with: .color(.white.opacity(f.alpha)))
                        }
                    }
                }
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

/// Детерминированный генератор, чтобы снежинки не менялись при перерисовке.
struct SeededGenerator: RandomNumberGenerator {
    private var state: UInt64
    init(seed: UInt64) { state = seed &+ 0x9E3779B97F4A7C15 }
    mutating func next() -> UInt64 {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }
}
