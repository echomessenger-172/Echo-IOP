import Foundation
import SwiftUI
import FirebaseAuth
import FirebaseFirestore

@MainActor
final class Session: ObservableObject {
    enum State: Equatable {
        case loading
        case signedOut
        case needsVerification(String)
        case onboarding
        case ready
    }

    @Published var state: State = .loading
    @Published var uid: String?
    @Published var profile = Profile()
    @Published var userNames: [String: String] = [:]
    @Published var notice: String?

    var stateKey: String { "\(state)" }

    private let db = Firestore.firestore()
    private var handle: AuthStateDidChangeListenerHandle?
    private var requested = Set<String>()

    init() {
        handle = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            Task { @MainActor in await self?.refresh(user) }
        }
    }

    // MARK: State

    func refresh(_ user: User?) async {
        guard let user = user, !user.isAnonymous else {
            if let u = user, u.isAnonymous { try? Auth.auth().signOut() }
            uid = nil
            profile = Profile()
            state = .signedOut
            return
        }
        if let email = user.email, !email.isEmpty, !user.isEmailVerified {
            uid = nil
            state = .needsVerification(email)
            return
        }
        uid = user.uid
        do {
            let doc = try await db.collection("users").document(user.uid).getDocument()
            let data = doc.data() ?? [:]
            if data["banned"] as? Bool == true {
                try? Auth.auth().signOut()
                notice = "Доступ к Echo Messenger заблокирован владельцем проекта"
                return
            }
            profile = Profile(data: data)
            state = profile.username.isEmpty ? .onboarding : .ready
        } catch {
            // Offline / rules problem: let the user in, profile will refresh later.
            state = profile.username.isEmpty ? .onboarding : .ready
        }
    }

    func setPresence(online: Bool) {
        guard let uid = uid, state == .ready else { return }
        db.collection("users").document(uid).setData([
            "online": online,
            "lastSeen": FieldValue.serverTimestamp()
        ], merge: true)
    }

    // MARK: Auth actions

    func signIn(email: String, password: String) async throws {
        _ = try await Auth.auth().signIn(withEmail: email, password: password)
    }

    func register(email: String, password: String) async throws {
        let result = try await Auth.auth().createUser(withEmail: email, password: password)
        try await result.user.sendEmailVerification()
    }

    func resetPassword(email: String) async throws {
        try await Auth.auth().sendPasswordReset(withEmail: email)
    }

    func resendVerification() async throws {
        try await Auth.auth().currentUser?.sendEmailVerification()
    }

    func recheckVerification() async throws {
        guard let user = Auth.auth().currentUser else { return }
        try await user.reload()
        await refresh(Auth.auth().currentUser)
    }

    func signOut() {
        setPresence(online: false)
        try? Auth.auth().signOut()
    }

    // MARK: Profile

    func claimUsername(_ raw: String) async throws {
        let name = raw.trimmed.lowercased()
        guard let uid = uid else { return }
        let ok = name.range(of: "^[a-z0-9_]{3,24}$", options: .regularExpression) != nil
        if !ok { throw EchoError.message("Имя: 3–24 символа, a–z, 0–9 и _") }
        let nameRef = db.collection("usernames").document(name)
        let userRef = db.collection("users").document(uid)
        _ = try await db.runTransaction({ (tx, errorPointer) -> Any? in
            let snap: DocumentSnapshot
            do { snap = try tx.getDocument(nameRef) } catch let e as NSError {
                errorPointer?.pointee = e
                return nil
            }
            if snap.exists {
                let d = snap.data() ?? [:]
                if (d["uid"] as? String) != uid || d["kind"] != nil {
                    errorPointer?.pointee = NSError(domain: "echo", code: 1,
                        userInfo: [NSLocalizedDescriptionKey: "Это имя уже занято"])
                    return nil
                }
            }
            tx.setData(["uid": uid], forDocument: nameRef)
            tx.setData(["username": name, "name": name], forDocument: userRef, merge: true)
            return nil
        })
        profile.username = name
        if profile.name.isEmpty { profile.name = name }
        state = .ready
    }

    func updateProfile(name: String, about: String) async throws {
        guard let uid = uid else { return }
        try await db.collection("users").document(uid).setData([
            "name": name.trimmed,
            "about": about.trimmed
        ], merge: true)
        profile.name = name.trimmed
        profile.about = about.trimmed
    }

    func unblock(_ otherUid: String) async throws {
        guard let uid = uid else { return }
        try await db.collection("users").document(uid).updateData([
            "blockedUsers": FieldValue.arrayRemove([otherUid])
        ])
        profile.blocked.removeAll { $0 == otherUid }
    }

    // MARK: User name cache

    func loadName(_ otherUid: String) async {
        if userNames[otherUid] != nil || requested.contains(otherUid) { return }
        requested.insert(otherUid)
        if let doc = try? await db.collection("users").document(otherUid).getDocument(),
           let n = doc.data()?["name"] as? String, !n.isEmpty {
            userNames[otherUid] = n
        }
    }

    func title(for chat: Chat) -> String {
        if let other = chat.otherMember(me: uid), let n = userNames[other] { return n }
        return chat.name
    }
}
