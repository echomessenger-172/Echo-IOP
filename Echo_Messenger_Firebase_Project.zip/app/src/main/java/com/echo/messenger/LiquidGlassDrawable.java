package com.echo.messenger;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Полупрозрачное «жидкое стекло»: светлая заливка, переливающийся ободок,
 * верхний блик и (для полной версии) подсветка, которая следует за пальцем.
 * Шейдеры пересоздаются только при смене размеров, поэтому рисование дешёвое.
 */
public class LiquidGlassDrawable extends Drawable {
    private final float radius, stroke;
    private final boolean full;
    private final int tint;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint touch = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final RectF inner = new RectF();
    private final Path clip = new Path();
    private float lightX = -1f, lightY = -1f, lightAmount = 0f;
    private RadialGradient touchShader;
    private final android.graphics.Matrix touchMatrix = new android.graphics.Matrix();
    private final Paint backing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean hasBacking = false;
    private int alpha = 255;

    /** radiusPx — радиус углов; full — с бликом и подсветкой; tint — оттенок стекла (0 = белый). */
    public LiquidGlassDrawable(float radiusPx, float strokePx, boolean full, int tint) {
        this.radius = radiusPx;
        this.stroke = strokePx;
        this.full = full;
        this.tint = tint == 0 ? Color.WHITE : tint;
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(strokePx);
    }

    /** Тёмная «матовая» подложка под стеклом — держит текст читаемым, когда под панелью прокручивается контент. */
    public LiquidGlassDrawable backing(int argb) {
        backing.setColor(argb);
        hasBacking = Color.alpha(argb) > 0;
        return this;
    }

    @Override protected void onBoundsChange(Rect b) {
        box.set(b);
        float half = stroke / 2f;
        box.inset(half, half);
        inner.set(box);
        inner.inset(half + 0.5f, half + 0.5f);
        float h = Math.max(1f, b.height());
        int base = Color.rgb(Color.red(tint), Color.green(tint), Color.blue(tint));
        fill.setShader(new LinearGradient(0, b.top, 0, b.bottom,
                withAlpha(base, 46), withAlpha(base, 16), Shader.TileMode.CLAMP));
        // Ободок: яркий сверху-слева, прозрачный в середине, мягкий снизу-справа + цветная «рефракция»
        rim.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                new int[]{withAlpha(Color.WHITE, 210), withAlpha(Color.rgb(170, 225, 255), 80),
                        withAlpha(Color.rgb(150, 255, 205), 60), withAlpha(Color.WHITE, 120)},
                new float[]{0f, .38f, .68f, 1f}, Shader.TileMode.CLAMP));
        if (full) {
            gloss.setShader(new LinearGradient(0, b.top, 0, b.top + h * .55f,
                    withAlpha(Color.WHITE, 78), withAlpha(Color.WHITE, 0), Shader.TileMode.CLAMP));
            clip.reset();
            clip.addRoundRect(inner, Math.max(0, radius - stroke), Math.max(0, radius - stroke), Path.Direction.CW);
            float r = Math.max(b.width(), b.height()) * .55f;
            touchShader = new RadialGradient(0, 0, Math.max(r, 1f),
                    new int[]{withAlpha(Color.WHITE, 120), withAlpha(Color.WHITE, 0)}, null, Shader.TileMode.CLAMP);
            touch.setShader(touchShader);
        }
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        float r = Math.min(radius, Math.min(box.width(), box.height()) / 2f);
        if (hasBacking) c.drawRoundRect(box, r, r, backing);
        fill.setAlpha(alpha);
        c.drawRoundRect(box, r, r, fill);
        if (full) {
            int save = c.save();
            c.clipPath(clip);
            // верхний блик, как у выпуклой линзы
            gloss.setAlpha(alpha);
            c.drawRect(b.left, b.top, b.right, b.top + b.height() * .55f, gloss);
            if (lightAmount > 0.01f && touchShader != null) {
                touchMatrix.setTranslate(lightX, lightY);
                touchShader.setLocalMatrix(touchMatrix);
                touch.setAlpha((int) (alpha * Math.min(1f, lightAmount)));
                c.drawRect(b, touch);
            }
            c.restoreToCount(save);
        }
        rim.setAlpha(alpha);
        c.drawRoundRect(box, r, r, rim);
    }

    /** Подсветка под пальцем (x,y в координатах drawable); amount 0..1. */
    public void setLight(float x, float y, float amount) {
        lightX = x;
        lightY = y;
        lightAmount = amount;
        invalidateSelf();
    }

    public float getLightAmount() { return lightAmount; }

    private static int withAlpha(int c, int a) { return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)); }

    @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { fill.setColorFilter(cf); rim.setColorFilter(cf); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
