package com.echo.messenger;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import java.util.concurrent.TimeUnit;
import com.google.firebase.firestore.*;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    final int BG=Color.rgb(8,26,23), CARD=Color.rgb(14,40,36), CARD2=Color.rgb(20,54,48), TEXT=Color.rgb(245,250,248), MUTED=Color.rgb(130,158,152), BLUE=Color.rgb(28,168,94);
    final int ACCENT=Color.rgb(56,214,122), DEEP=Color.rgb(20,150,80);
    LinearLayout navBar; ImageView[] navIcons=new ImageView[4]; TextView[] navLabels=new TextView[4]; TextView fab, headerAvatar, navBadge; ImageView miniFab; LinearLayout avatarStack; final HashMap<String,Integer> unread=new HashMap<>(); String pendingGift; int pendingGiftCost; long pendingGiftAt, generalAt;
    ListenerRegistration listener2; java.util.ArrayList<ChatItem> myChats=new java.util.ArrayList<>(), findResults=new java.util.ArrayList<>();
    int chatTab=0; String chatQuery="", generalLast="Пока нет сообщений — напиши первым", generalTime="";
    LinearLayout content; TextView title; FirebaseFirestore db; FirebaseAuth auth; String uid; ListenerRegistration listener;
    String lastEmailPw=null,prefillEmail="";boolean emailRegister=false; String profileName="ляля ❤️", profileUsername="zuhede", profileAbout="О Echo", profileBirthday="01 нояб.", profileLocation="Не указано", profileMusic="cachalot — ONDA ANDAR"; Uri profilePhotoUri; String verificationId; PhoneAuthProvider.ForceResendingToken resendToken; EditText phoneInput, codeInput; Button phoneAction;
    Uri onboardPhoto; Runnable onPhotoPicked; LinearLayout appHeader; boolean startOnPhone; int netState=0; boolean hasNet=true,inShell; String titleBase="Echo",chatSubBase=""; TextView chatSub,statusDot; long updatingSince; final android.os.Handler ui=new android.os.Handler(android.os.Looper.getMainLooper()); android.net.ConnectivityManager.NetworkCallback netCallback; final HashMap<String,Boolean> verifiedCache=new HashMap<>();
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(CharSequence s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    ImageView dockIcon(int res){ImageView v=new ImageView(this);v.setImageResource(res);v.setColorFilter(MUTED);v.setScaleType(ImageView.ScaleType.CENTER_INSIDE);v.setPadding(dp(10),dp(10),dp(10),dp(10));return v;}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    Button btn(CharSequence s){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setBackground(glass(18));pressable(b,.96f);return b;}

    // ===== Vector icons instead of emoji: glyph in text -> tinted vector drawable =====
    int icoRes(int cp){
        switch(cp){
            case 0x2709: return R.drawable.ic_mail;
            case 0x260E: case 0x1F4F1: return R.drawable.ic_mobile;
            case 0x1F4DE: return R.drawable.ic_call;
            case 0x1F511: return R.drawable.ic_key;
            case 0x1F510: return R.drawable.ic_lock;
            case 0x2764: return R.drawable.ic_heart;
            case 0x22EE: return R.drawable.ic_bar_more;
            case 0x270E: return R.drawable.ic_edit;
            case 0x2715: return R.drawable.ic_close;
            case 0x1F552: return R.drawable.ic_clock;
            case 0x1F4CE: return R.drawable.ic_dock_attach;
            case 0x1F451: return R.drawable.ic_crown;
            case 0xFF0B: return R.drawable.ic_add;
            case 0x2190: return R.drawable.ic_bar_back;
            case 0x25A6: return R.drawable.ic_qr;
            case 0x1F535: return R.drawable.ic_verified;
            case 0x2728: case 0x2726: return R.drawable.ic_sparkle;
            case 0x1F3A8: return R.drawable.ic_palette;
            case 0x1F680: return R.drawable.ic_zap;
            case 0x1F48E: return R.drawable.ic_gem;
            case 0x1F6E1: return R.drawable.ic_shield;
            case 0x26D4: return R.drawable.ic_block;
            case 0x2605: return R.drawable.ic_star;
            case 0x1F381: return R.drawable.ic_gift;
            case 0x1F339: return R.drawable.ic_rose;
            case 0x1F9F8: return R.drawable.ic_teddy;
            case 0x1F3C6: return R.drawable.ic_trophy;
            case 0x2139: return R.drawable.ic_info;
            case 0x2316: return R.drawable.ic_pin;
            case 0x266B: return R.drawable.ic_music;
            case 0x1F382: return R.drawable.ic_cake;
            case 0x203A: return R.drawable.ic_settings_chevron;
            case 0x1F4E2: return R.drawable.ic_megaphone;
            case 0x1F310: return R.drawable.ic_globe;
            case 0x1F465: return R.drawable.ic_group;
            case 0x1F916: return R.drawable.ic_bot;
            case 0x1F501: return R.drawable.ic_switch;
            case 0x1F524: return R.drawable.ic_translate;
            case 0x1F464: return R.drawable.ic_user_add;
            case 0x1F95A: return R.drawable.ic_egg;
            default: return 0;
        }
    }
    int icoColor(int cp){
        switch(cp){
            case 0x1F535: return -1;
            case 0x2605: case 0x1F3C6: return Color.rgb(255,196,60);
            case 0x1F381: return Color.rgb(236,100,150);
            case 0x1F339: return Color.rgb(232,70,90);
            case 0x1F9F8: return Color.rgb(205,145,95);
            case 0x1F48E: return Color.rgb(80,200,235);
            default: return 0;
        }
    }
    class IconSpan extends android.text.style.ReplacementSpan{
        final android.graphics.drawable.Drawable d; final int color;
        IconSpan(int res,int color){d=getResources().getDrawable(res,getTheme()).mutate();this.color=color;}
        @Override public int getSize(android.graphics.Paint p,CharSequence t,int st,int en,android.graphics.Paint.FontMetricsInt fm){return (int)(p.getTextSize()*1.2f);}
        @Override public void draw(android.graphics.Canvas c,CharSequence t,int st,int en,float x,int top,int y,int bottom,android.graphics.Paint p){
            int sz=(int)(p.getTextSize()*1.12f);
            if(color==-1)d.setTintList(null);else d.setTint(color!=0?color:p.getColor());
            int cy=(int)(y+(p.ascent()+p.descent())/2f);
            int left=(int)x+(int)((p.getTextSize()*1.2f-sz)/2f);
            d.setBounds(left,cy-sz/2,left+sz,cy+sz/2);
            d.draw(c);
        }
    }
    CharSequence ico(CharSequence in){
        if(in==null)return in;
        String src=in.toString();
        android.text.SpannableStringBuilder out=null;
        int i=0;
        while(i<src.length()){
            int cp=src.codePointAt(i);int n=Character.charCount(cp);
            int res=icoRes(cp);
            if(res!=0){
                if(out==null){out=new android.text.SpannableStringBuilder();out.append(src,0,i);}
                int at=out.length();out.append('\uFFFC');
                out.setSpan(new IconSpan(res,icoColor(cp)),at,at+1,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                i+=n;
                if(i<src.length()&&src.charAt(i)=='\uFE0F')i++;
            }else{
                if(out!=null)out.append(src,i,i+n);
                i+=n;
            }
        }
        return out==null?in:out;
    }
    // gift messages are stored as "<emoji> Подарок: <name>"; draw them with vector icons
    CharSequence giftText(String t){
        if(t==null||!t.contains(" Подарок: "))return t==null?"":t;
        return ico(t);
    }
    String plural(int n,String one,String few,String many){
        int a=Math.abs(n)%100,b=a%10;
        if(a>10&&a<20)return many;
        if(b>1&&b<5)return few;
        if(b==1)return one;
        return many;
    }
    LinearLayout.LayoutParams wrapMargins(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    LinearLayout.LayoutParams margins(int l,int t,int r,int b,int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(h));p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}

    // ===== Username validation + live availability check (users and channels share one namespace: usernames/{name}) =====
    static final java.util.Set<String> RESERVED_NAMES=new java.util.HashSet<>(java.util.Arrays.asList("admin","administrator","echo","echo_support","support","help","settings","general","system","root","moderator","official","staff","null","undefined","api","www","channel","group","bot","news","security"));
    /** null = valid, otherwise a human-readable reason */
    String usernameError(String u){
        if(u==null||u.isEmpty())return "Введи username";
        if(u.length()<3)return "Минимум 3 символа";
        if(u.length()>24)return "Максимум 24 символа";
        if(!u.matches("[a-z0-9_]+"))return "Только латинские a-z, цифры 0-9 и _";
        char f=u.charAt(0);
        if(!(f>='a'&&f<='z'))return "Должен начинаться с буквы";
        if(u.endsWith("_"))return "Не может заканчиваться на _";
        if(u.contains("__"))return "Нельзя два _ подряд";
        if(RESERVED_NAMES.contains(u))return "Это имя зарезервировано";
        return null;
    }
    String cleanUsername(CharSequence raw){return raw==null?"":raw.toString().trim().replace("@","").toLowerCase(java.util.Locale.ROOT);}
    android.text.InputFilter[] usernameFilters(){
        return new android.text.InputFilter[]{(src,st,en,dst,ds,de)->{StringBuilder sb=new StringBuilder();for(int i=st;i<en;i++){char c=Character.toLowerCase(src.charAt(i));if((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_')sb.append(c);}return sb.toString();},new android.text.InputFilter.LengthFilter(24)};
    }
    /** "@ username" input in a glass row with a status line below; statusOut[0] receives the status TextView */
    EditText usernameRow(LinearLayout parent,TextView[] statusOut,String hintText){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(glass(16));
        row.setPadding(dp(16),0,dp(16),0);
        TextView at=tv("@",18,BLUE);
        EditText f=new EditText(this);
        f.setHint("username канала (необязательно)");f.setHintTextColor(MUTED);f.setTextColor(TEXT);f.setTextSize(16);f.setBackground(null);f.setSingleLine(true);
        f.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        f.setFilters(usernameFilters());
        row.addView(at,new LinearLayout.LayoutParams(-2,-2));
        row.addView(f,new LinearLayout.LayoutParams(0,dp(52),1));
        parent.addView(row,margins(0,5,0,4,52));
        TextView st=tv(hintText,12,MUTED);
        st.setGravity(Gravity.CENTER_VERTICAL);
        parent.addView(st,wrapMargins(4,0,4,8));
        statusOut[0]=st;
        return f;
    }
    /**
     * Debounced live check while typing. Returns state[0]: 0 = checking/unknown, 1 = free (or yours), 2 = invalid/taken, 3 = empty.
     * own[0] = the name that already belongs to the edited object; forChannel/ownChatId decide what counts as "yours".
     */
    int[] attachUsernameChecker(EditText f,TextView status,String defaultHint,String[] own,boolean forChannel,String ownChatId){
        final int[] state={3},seq={0};
        final Runnable[] pend={null};
        final int GREEN=Color.rgb(70,210,135),RED=Color.rgb(255,107,107);
        f.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int a,int b,int c){}
            public void onTextChanged(CharSequence cs,int a,int b,int c){}
            public void afterTextChanged(android.text.Editable ed){
                final String u=cleanUsername(ed);
                if(pend[0]!=null)ui.removeCallbacks(pend[0]);
                final int my=++seq[0];
                if(u.isEmpty()){state[0]=3;status.setTextColor(MUTED);status.setText(defaultHint);return;}
                String ownName=own[0]==null?"":own[0];
                if(u.equals(ownName)){state[0]=1;status.setTextColor(GREEN);status.setText("✓ Это текущее имя");return;}
                String er=usernameError(u);
                if(er!=null){state[0]=2;status.setTextColor(RED);status.setText(er);return;}
                state[0]=0;status.setTextColor(MUTED);status.setText("Проверяем @"+u+"…");
                pend[0]=()->db.collection("usernames").document(u).get().addOnSuccessListener(d->{
                    if(seq[0]!=my)return;
                    boolean mine=d.exists()&&uid!=null&&uid.equals(d.getString("uid"))&&(forChannel?(ownChatId!=null&&ownChatId.equals(d.getString("chatId"))):!"channel".equals(d.getString("kind")));
                    if(!d.exists()||mine){state[0]=1;status.setTextColor(GREEN);status.setText("✓ @"+u+" свободно");}
                    else{state[0]=2;status.setTextColor(RED);status.setText("✗ @"+u+" уже занято");}
                }).addOnFailureListener(e->{if(seq[0]!=my)return;state[0]=0;status.setTextColor(MUTED);status.setText("Не удалось проверить сейчас — проверим при сохранении");});
                ui.postDelayed(pend[0],450);
            }
        });
        return state;
    }
    void copyText(String label,String text){
        android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if(cm!=null){cm.setPrimaryClip(android.content.ClipData.newPlainText(label,text));toast("Скопировано: "+text);}
    }
    boolean isCode(Exception e,FirebaseFirestoreException.Code c){return e instanceof FirebaseFirestoreException&&((FirebaseFirestoreException)e).getCode()==c;}
    // ===== Liquid glass + motion helpers =====
    AuroraDrawable aurora; android.animation.ValueAnimator auroraAnim, navAnim; boolean resumed, inChatMode, renderPending;
    int curLevel=0, curTab=-1; LiquidGlassDrawable navIndicator; float navIndLeft, navIndWidth; int navIndTop, navIndBottom;
    LinearLayout pendingRenderList; final HashMap<String,Long> unreadChecked=new HashMap<>();
    static final int[] AVATAR_PALETTE={Color.rgb(139,92,246),Color.rgb(236,96,144),Color.rgb(45,170,150),Color.rgb(240,150,60),Color.rgb(70,140,235)};
    float dpf(float v){return v*getResources().getDisplayMetrics().density;}
    boolean animsCache=true, frostCache=true; SnowDrawable windowSnow; WinterDecor.FrostEdge frost; android.view.View frostView; WinterDecor.SnowCap navCap; android.animation.ValueAnimator titleAnim; android.graphics.LinearGradient titleShader; final android.graphics.Matrix titleMatrix=new android.graphics.Matrix(); android.content.SharedPreferences.OnSharedPreferenceChangeListener prefListener;
    boolean animsOn(){return animsCache;}
    // настройки читаются один раз и обновляются слушателем — а не на каждое касание
    void cachePrefs(){
        android.content.SharedPreferences sp=getSharedPreferences("echo_settings",MODE_PRIVATE);
        animsCache=sp.getBoolean("chat_animations",true)&&!sp.getBoolean("battery_saver",false)&&!SnowDrawable.systemReduceMotion;
        boolean oldFrost=frostCache;
        frostCache=sp.getBoolean("winter_frost",true);
        if(oldFrost!=frostCache&&aurora!=null)buildWindowBg();
        applyFrost();
    }
    void applyFrost(){if(frostView!=null)frostView.setVisibility(frostCache&&!inChatMode?android.view.View.VISIBLE:android.view.View.GONE);if(navBar!=null)navBar.invalidate();}
    void refreshSystemMotion(){
        try{float sc=android.provider.Settings.Global.getFloat(getContentResolver(),android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,1f);SnowDrawable.systemReduceMotion=sc==0f;}catch(Exception ignored){}
        try{android.os.PowerManager pm=(android.os.PowerManager)getSystemService(POWER_SERVICE);SnowDrawable.powerSaving=pm!=null&&pm.isPowerSaveMode();}catch(Exception ignored){}
        cachePrefs();
    }
    // light glass: cards, chips, received bubbles (cheap to draw)
    android.graphics.drawable.Drawable glass(float r){return new LiquidGlassDrawable(dpf(r),dpf(.9f),false,0);}
    // full glass: panels, nav bar, dock, header pills (gloss + touch light + frosted backing)
    LiquidGlassDrawable glassFull(float r){return new LiquidGlassDrawable(dpf(r),dpf(1.1f),true,0).backing(Color.argb(104,10,15,28));}
    android.graphics.drawable.Drawable glassAccent(int color,float r){return glassAccent(color,r,true);}
    android.graphics.drawable.Drawable glassAccent(int color,float r,boolean full){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dpf(r));g.setAlpha(200);
        android.graphics.drawable.Drawable top=full?new LiquidGlassDrawable(dpf(r),dpf(1.1f),true,0):glass(r);
        return new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{g,top});
    }
    LiquidGlassDrawable findGlass(android.graphics.drawable.Drawable d){
        if(d instanceof LiquidGlassDrawable)return (LiquidGlassDrawable)d;
        if(d instanceof android.graphics.drawable.LayerDrawable){android.graphics.drawable.LayerDrawable ld=(android.graphics.drawable.LayerDrawable)d;for(int i=0;i<ld.getNumberOfLayers();i++){if(ld.getDrawable(i) instanceof LiquidGlassDrawable)return (LiquidGlassDrawable)ld.getDrawable(i);}}
        return null;
    }
    // "liquid" press: the view squishes, then springs back; glass catches light under the finger
    void pressable(final android.view.View v,final float pressedScale){
        v.setOnTouchListener((x,e)->{
            int a=e.getActionMasked();
            LiquidGlassDrawable g=findGlass(x.getBackground());
            if(a==android.view.MotionEvent.ACTION_DOWN){
                if(animsOn())x.animate().cancel();
                if(animsOn())x.animate().scaleX(pressedScale).scaleY(pressedScale).setDuration(110).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                if(g!=null)g.setLight(e.getX(),e.getY(),1f);
            }else if(a==android.view.MotionEvent.ACTION_MOVE){
                if(g!=null)g.setLight(e.getX(),e.getY(),1f);
            }else if(a==android.view.MotionEvent.ACTION_UP||a==android.view.MotionEvent.ACTION_CANCEL){
                if(animsOn())x.animate().scaleX(1f).scaleY(1f).setDuration(340).setInterpolator(new android.view.animation.OvershootInterpolator(2.4f)).start();
                else{x.setScaleX(1f);x.setScaleY(1f);}
                if(g!=null){final float lx=e.getX(),ly=e.getY();android.animation.ValueAnimator va=android.animation.ValueAnimator.ofFloat(1f,0f);va.setDuration(300);va.addUpdateListener(u->g.setLight(lx,ly,(Float)u.getAnimatedValue()));va.start();}
            }
            return false;
        });
    }
    // Screen transition: new page slides in from the side it logically comes from (dir>0 forward, <0 back)
    void pageIn(int dir){
        if(content==null)return;
        content.animate().cancel();
        if(dir==0||!animsOn()){content.setAlpha(1f);content.setTranslationX(0f);content.setScaleX(1f);content.setScaleY(1f);return;}
        content.setLayerType(android.view.View.LAYER_TYPE_HARDWARE,null);
        content.setAlpha(0f);
        content.setTranslationX(dir*dpf(56));
        content.setScaleX(.96f);content.setScaleY(.96f);
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f).setDuration(340)
            .setInterpolator(new android.view.animation.PathInterpolator(.2f,.8f,.2f,1f))
            .withEndAction(()->content.setLayerType(android.view.View.LAYER_TYPE_NONE,null)).start();
    }
    void buildWindowBg(){
        float dn=getResources().getDisplayMetrics().density;
        windowSnow=new SnowDrawable(dn,getSharedPreferences("echo_settings",MODE_PRIVATE));
        java.util.ArrayList<android.graphics.drawable.Drawable> ls=new java.util.ArrayList<>();
        ls.add(aurora);
        if(frostCache)ls.add(new WinterDecor.Drift(dn));
        ls.add(windowSnow);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.LayerDrawable(ls.toArray(new android.graphics.drawable.Drawable[0])));
    }
    void setupWindow(){
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if(android.os.Build.VERSION.SDK_INT>=29){getWindow().setNavigationBarContrastEnforced(false);getWindow().setStatusBarContrastEnforced(false);}
        aurora=new AuroraDrawable(Color.rgb(4,15,13));
        buildWindowBg();
        // иней с сосульками у верхнего края: отдельный слой поверх всего интерфейса, нажатия не перехватывает
        frost=new WinterDecor.FrostEdge(getResources().getDisplayMetrics().density);
        frostView=new android.view.View(this);
        frostView.setBackground(frost);
        frostView.setClickable(false);
        frostView.setImportantForAccessibility(android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        ((ViewGroup)getWindow().getDecorView()).addView(frostView,new FrameLayout.LayoutParams(-1,dp(60),Gravity.TOP));
        applyFrost();
    }
    void startAurora(){
        if(aurora==null||inChatMode||!animsOn()||!resumed)return;
        if(auroraAnim!=null&&auroraAnim.isRunning())return;
        auroraAnim=android.animation.ValueAnimator.ofFloat(0f,1f);
        auroraAnim.setDuration(45000);
        auroraAnim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        auroraAnim.setInterpolator(new android.view.animation.LinearInterpolator());
        auroraAnim.addUpdateListener(a->aurora.setPhase((Float)a.getAnimatedValue()));
        auroraAnim.start();
        startTitleShimmer();
    }
    void stopAurora(){if(auroraAnim!=null){auroraAnim.cancel();auroraAnim=null;}if(titleAnim!=null){titleAnim.cancel();titleAnim=null;}}
    // ледяной блик пробегает по заголовку «Echo»
    void startTitleShimmer(){
        if(title==null||titleShader==null||!inShell||SnowDrawable.powerSaving)return;
        if(titleAnim!=null&&titleAnim.isRunning())return;
        titleAnim=android.animation.ValueAnimator.ofFloat(0f,1f);
        titleAnim.setDuration(5200);
        titleAnim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        titleAnim.setInterpolator(new android.view.animation.LinearInterpolator());
        titleAnim.addUpdateListener(a->{if(title==null)return;titleMatrix.setTranslate((Float)a.getAnimatedValue()*dpf(240),0f);titleShader.setLocalMatrix(titleMatrix);title.invalidate();});
        titleAnim.start();
    }
    // Liquid indicator under the active nav item: slides, stretches mid-flight, overshoots and settles
    void moveNavIndicator(final int idx,final int tries){
        if(navBar==null||idx<0||idx>=navBar.getChildCount()||tries>6)return;
        final android.view.View item=navBar.getChildAt(idx);
        if(item.getWidth()==0){navBar.post(()->moveNavIndicator(idx,tries+1));return;}
        final float toLeft=item.getLeft()+dpf(4),toW=item.getWidth()-dpf(8);
        navIndTop=item.getTop()-dp(2);navIndBottom=item.getBottom()+dp(2);
        if(navAnim!=null)navAnim.cancel();
        if(navIndWidth<=0||!animsOn()){navIndLeft=toLeft;navIndWidth=toW;navBar.invalidate();return;}
        final float fromLeft=navIndLeft,fromW=navIndWidth;
        final float reach=Math.min(1f,Math.abs(toLeft-fromLeft)/dpf(40));
        navAnim=android.animation.ValueAnimator.ofFloat(0f,1f);
        navAnim.setDuration(420);
        navAnim.setInterpolator(new android.view.animation.OvershootInterpolator(1.05f));
        navAnim.addUpdateListener(a->{
            float f=(Float)a.getAnimatedValue();
            float stretch=(float)Math.sin(Math.PI*Math.max(0f,Math.min(1f,f)))*dpf(22)*reach;
            navIndLeft=fromLeft+(toLeft-fromLeft)*f-stretch/2f;
            navIndWidth=fromW+(toW-fromW)*f+stretch;
            navBar.invalidate();
        });
        navAnim.start();
    }
    // Coalesce bursts of Firestore snapshots / unread counters into a single rebuild
    void requestRender(LinearLayout list){
        pendingRenderList=list;
        if(renderPending)return;
        renderPending=true;
        ui.postDelayed(()->{renderPending=false;if(pendingRenderList!=null)renderChatRows(pendingRenderList);},60);
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);prefListener=(sp0,k0)->cachePrefs();getSharedPreferences("echo_settings",MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefListener);refreshSystemMotion();setupWindow();setupInsets();startNetworkWatch();auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();android.content.SharedPreferences pp=getSharedPreferences("echo_profile",MODE_PRIVATE);profileName=pp.getString("name",profileName);profileUsername=pp.getString("username",profileUsername);profileAbout=pp.getString("about",profileAbout);profileLocation=pp.getString("location",profileLocation);profileBirthday=pp.getString("birthday",profileBirthday);profileMusic=pp.getString("music",profileMusic);String savedPhoto=pp.getString("photo",null);if(savedPhoto!=null)try{profilePhotoUri=Uri.parse(savedPhoto);}catch(Exception ignored){}FirebaseUser current=auth.getCurrentUser();boolean needsVerify=current!=null&&current.getEmail()!=null&&!current.getEmail().isEmpty()&&!current.isEmailVerified();if(current!=null&&!current.isAnonymous()&&!needsVerify){uid=current.getUid();registerPushAndSession();db.collection("users").document(uid).get().addOnSuccessListener(profile->{if(Boolean.TRUE.equals(profile.getBoolean("banned"))){auth.signOut();uid=null;showAuth();toast("Доступ к Echo Messenger заблокирован владельцем проекта");}else if(isOnboardingPending(uid))showOnboarding();else{if(profile.exists())restoreProfileFrom(profile);buildShell();showChats();}}).addOnFailureListener(err->{if(isOnboardingPending(uid))showOnboarding();else{buildShell();showChats();}});}else{if(current!=null)auth.signOut();showAuth();}}
    EditText edit(String hint, boolean phone){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setTextSize(16);e.setSingleLine(true);e.setPadding(dp(16),dp(8),dp(16),dp(8));e.setBackground(glass(16));if(phone)e.setInputType(android.text.InputType.TYPE_CLASS_PHONE);return e;}
    void showAuth(){
        emailRegister=false;
        inShell=false;
        final boolean authReuse=content!=null;
        if(content==null){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(24),dp(22),dp(20));root.setBackgroundColor(Color.TRANSPARENT);title=tv("Echo",32,TEXT);title.setTypeface(null,Typeface.BOLD);root.addView(title,new LinearLayout.LayoutParams(-1,dp(58)));content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView scroll=new ScrollView(this);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}else{content.removeAllViews();title.setText("Echo");}
        content.setPadding(dp(2),dp(30),dp(2),dp(12));TextView heading=tv("Добро пожаловать",27,TEXT);heading.setTypeface(null,Typeface.BOLD);heading.setGravity(Gravity.CENTER);content.addView(heading,margins(0,10,0,4,48));TextView sub=tv("Войди или создай аккаунт Echo",14,MUTED);sub.setGravity(Gravity.CENTER);content.addView(sub,margins(0,0,0,24,32));
        LinearLayout modes=new LinearLayout(this);Button emailTab=btn(ico("✉  По почте")),phoneTab=btn(ico("☎  По телефону"));modes.addView(emailTab,new LinearLayout.LayoutParams(0,dp(50),1));modes.addView(phoneTab,new LinearLayout.LayoutParams(0,dp(50),1));content.addView(modes,margins(0,0,0,18,50));
        LinearLayout emailPanel=new LinearLayout(this);emailPanel.setOrientation(LinearLayout.VERTICAL);EditText email=edit("Электронная почта",false);email.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);EditText pass=edit("Пароль (минимум 6 символов)",false);pass.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);emailPanel.addView(email,margins(0,5,0,10,56));emailPanel.addView(pass,margins(0,5,0,10,56));Button submit=btn("Войти");submit.setBackground(glassAccent(BLUE,18));emailPanel.addView(submit,margins(0,12,0,8,54));Button toggle=btn("Нет аккаунта? Зарегистрироваться");emailPanel.addView(toggle,margins(0,0,0,8,48));Button forgot=btn("Забыли пароль?");forgot.setBackground(null);forgot.setTextColor(BLUE);emailPanel.addView(forgot,margins(0,0,0,8,44));if(prefillEmail!=null&&!prefillEmail.isEmpty()){email.setText(prefillEmail);prefillEmail="";}content.addView(emailPanel);
        LinearLayout phonePanel=new LinearLayout(this);phonePanel.setOrientation(LinearLayout.VERTICAL);phoneInput=edit("Телефон с кодом страны, например +447700900123",true);phonePanel.addView(phoneInput,margins(0,5,0,10,56));codeInput=edit("Код из SMS",true);codeInput.setVisibility(android.view.View.GONE);phonePanel.addView(codeInput,margins(0,5,0,10,56));phoneAction=btn("Отправить код по SMS");phoneAction.setBackground(glassAccent(BLUE,18));phonePanel.addView(phoneAction,margins(0,12,0,8,54));TextView hint=tv("Для входа по телефону включи Phone в Firebase Authentication. Для SMS может потребоваться проверка приложения.",12,MUTED);hint.setGravity(Gravity.CENTER);phonePanel.addView(hint,margins(0,8,0,0,60));phonePanel.setVisibility(android.view.View.GONE);content.addView(phonePanel);
        emailTab.setOnClickListener(v->{emailPanel.setVisibility(android.view.View.VISIBLE);phonePanel.setVisibility(android.view.View.GONE);});phoneTab.setOnClickListener(v->{emailPanel.setVisibility(android.view.View.GONE);phonePanel.setVisibility(android.view.View.VISIBLE);});toggle.setOnClickListener(v->{emailRegister=!emailRegister;submit.setText(emailRegister?"Создать аккаунт":"Войти");toggle.setText(emailRegister?"Уже есть аккаунт? Войти":"Нет аккаунта? Зарегистрироваться");forgot.setVisibility(emailRegister?android.view.View.GONE:android.view.View.VISIBLE);});forgot.setOnClickListener(v->showPasswordReset(email.getText().toString().trim()));
        submit.setOnClickListener(v->{String em=email.getText().toString().trim(),pw=pass.getText().toString();if(!android.util.Patterns.EMAIL_ADDRESS.matcher(em).matches()){toast("Введи корректный адрес электронной почты");email.setError("Проверь email");email.requestFocus();return;}if(pw.length()<6){toast("Пароль должен содержать минимум 6 символов");pass.setError("Минимум 6 символов");pass.requestFocus();return;}submit.setEnabled(false);if(emailRegister){auth.createUserWithEmailAndPassword(em,pw).addOnCompleteListener(t->{if(!t.isSuccessful()){submit.setEnabled(true);toast(authMessage(t.getException()));return;}FirebaseUser created=auth.getCurrentUser();if(created==null){submit.setEnabled(true);toast("Аккаунт создан, но не удалось получить пользователя");return;}getSharedPreferences("echo_onboarding",MODE_PRIVATE).edit().putBoolean("pending_"+created.getUid(),true).apply();created.sendEmailVerification().addOnCompleteListener(mail->{submit.setEnabled(true);showVerifyEmail(em,pw,mail.isSuccessful()?"":"Аккаунт создан, но письмо не отправилось: "+authMessage(mail.getException())+". Нажми «Отправить письмо ещё раз».");});});}else{lastEmailPw=pw;auth.signInWithEmailAndPassword(em,pw).addOnCompleteListener(t->{if(!t.isSuccessful()){submit.setEnabled(true);toast(authMessage(t.getException()));return;}FirebaseUser signed=auth.getCurrentUser();if(signed!=null&&!signed.isEmailVerified()){submit.setEnabled(true);showVerifyEmail(em,pw,"Почта ещё не подтверждена. Подтверди её по письму или отправь письмо заново.");return;}submit.setEnabled(true);authDone();});}});
        phoneAction.setOnClickListener(v->{if(verificationId==null){String number=phoneInput.getText().toString().trim();if(!number.startsWith("+")||number.length()<8){toast("Введи номер в международном формате, например +447700900123");return;}phoneAction.setEnabled(false);PhoneAuthOptions options=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(number).setTimeout(60L,TimeUnit.SECONDS).setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){@Override public void onVerificationCompleted(PhoneAuthCredential credential){auth.signInWithCredential(credential).addOnCompleteListener(t->{phoneAction.setEnabled(true);if(t.isSuccessful())authDone();else toast(authMessage(t.getException()));});}@Override public void onVerificationFailed(com.google.firebase.FirebaseException e){phoneAction.setEnabled(true);toast("Не удалось отправить SMS: "+e.getMessage());}@Override public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken token){verificationId=id;resendToken=token;phoneAction.setEnabled(true);codeInput.setVisibility(android.view.View.VISIBLE);phoneAction.setText("Подтвердить код");toast("Код отправлен по SMS");}}).build();PhoneAuthProvider.verifyPhoneNumber(options);}else{String code=codeInput.getText().toString().trim();if(code.isEmpty()){toast("Введи код из SMS");return;}PhoneAuthCredential credential=PhoneAuthProvider.getCredential(verificationId,code);phoneAction.setEnabled(false);auth.signInWithCredential(credential).addOnCompleteListener(t->{phoneAction.setEnabled(true);if(t.isSuccessful())authDone();else toast(authMessage(t.getException()));});}});
        addSavedAccountsToAuth();
        if(startOnPhone){startOnPhone=false;emailPanel.setVisibility(android.view.View.GONE);phonePanel.setVisibility(android.view.View.VISIBLE);}
        pageIn(authReuse?-1:1);
    }
    // Password recovery: sends Firebase's reset link to the account e-mail
    void showPasswordReset(String prefill){
        if(content==null||title==null){showAuth();return;}
        content.removeAllViews();
        pageIn(1);
        title.setText("Echo");
        content.setPadding(dp(2),dp(30),dp(2),dp(12));
        TextView icon=tv(ico("🔑"),52,BLUE);
        icon.setGravity(Gravity.CENTER);
        content.addView(icon,margins(0,10,0,6,76));
        TextView heading=tv("Восстановление доступа",25,TEXT);
        heading.setTypeface(null,Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        content.addView(heading,margins(0,0,0,8,44));
        TextView sub=tv("Укажи почту аккаунта — мы отправим письмо со ссылкой, по которой можно задать новый пароль.",14,MUTED);
        sub.setGravity(Gravity.CENTER);
        content.addView(sub,wrapMargins(8,0,8,16));
        EditText mail=edit("Электронная почта",false);
        mail.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        mail.setText(prefill);
        content.addView(mail,margins(0,0,0,10,56));
        TextView status=tv("",13,MUTED);
        status.setGravity(Gravity.CENTER);
        content.addView(status,wrapMargins(8,0,8,8));
        Button send=btn("Отправить ссылку");
        send.setBackground(glassAccent(BLUE,18));
        content.addView(send,margins(0,4,0,14,54));
        TextView tip=tv("Входил по номеру телефона? Пароль не нужен: войди по SMS-коду.",12,MUTED);
        tip.setGravity(Gravity.CENTER);
        content.addView(tip,wrapMargins(8,0,8,10));
        Button phone=btn(ico("☎  Войти по телефону"));
        content.addView(phone,margins(0,0,0,10,50));
        Button back=btn("‹  Назад ко входу");
        back.setBackground(null);
        back.setTextColor(MUTED);
        content.addView(back,margins(0,0,0,0,48));
        send.setOnClickListener(x->{
            String address=mail.getText().toString().trim();
            if(!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()){
                status.setTextColor(Color.rgb(255,107,107));
                status.setText("Введи корректный адрес почты");
                return;
            }
            send.setEnabled(false);
            status.setTextColor(MUTED);
            status.setText("Отправляем…");
            auth.sendPasswordResetEmail(address).addOnCompleteListener(t->{
                if(t.isSuccessful()){
                    status.setTextColor(Color.rgb(70,210,135));
                    status.setText("Готово! Если аккаунт с адресом "+address+" существует, на него отправлено письмо. Проверь «Спам», перейди по ссылке, задай новый пароль и вернись ко входу.");
                    send.setText("Отправить ещё раз");
                    send.postDelayed(()->send.setEnabled(true),30000);
                }else{
                    send.setEnabled(true);
                    status.setTextColor(Color.rgb(255,107,107));
                    status.setText(authMessage(t.getException()));
                }
            });
        });
        phone.setOnClickListener(x->{startOnPhone=true;showAuth();});
        back.setOnClickListener(x->showAuth());
    }
    // Shown after sign-up (and when logging in with an unconfirmed address)
    void showVerifyEmail(String em,String pw,String note){
        if(content==null||title==null){showAuth();return;}
        content.removeAllViews();
        pageIn(1);
        title.setText("Echo");
        content.setPadding(dp(2),dp(30),dp(2),dp(12));
        TextView icon=tv(ico("✉"),56,BLUE);
        icon.setGravity(Gravity.CENTER);
        content.addView(icon,margins(0,10,0,6,80));
        TextView heading=tv("Подтверди почту",27,TEXT);
        heading.setTypeface(null,Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        content.addView(heading,margins(0,0,0,10,48));
        TextView sub=tv("Мы отправили письмо на\n"+em+"\n\nОткрой его, нажми на ссылку и вернись сюда. Если письма нет, загляни в папку «Спам».",14,MUTED);
        sub.setGravity(Gravity.CENTER);
        content.addView(sub,wrapMargins(8,0,8,14));
        TextView status=tv(note,13,Color.rgb(255,107,107));
        status.setGravity(Gravity.CENTER);
        content.addView(status,wrapMargins(8,0,8,10));
        Button done=btn("Я подтвердил(а) почту");
        done.setBackground(glassAccent(BLUE,18));
        content.addView(done,margins(0,4,0,10,54));
        Button resend=btn("Отправить письмо ещё раз");
        content.addView(resend,margins(0,0,0,10,50));
        Button back=btn("‹  Назад ко входу");
        back.setBackground(null);
        back.setTextColor(MUTED);
        content.addView(back,margins(0,0,0,0,48));
        done.setOnClickListener(x->{
            done.setEnabled(false);
            status.setTextColor(MUTED);
            status.setText("Проверяем…");
            FirebaseUser cu=auth.getCurrentUser();
            if(cu!=null){
                cu.reload().addOnCompleteListener(t->{
                    done.setEnabled(true);
                    FirebaseUser fresh=auth.getCurrentUser();
                    if(t.isSuccessful()&&fresh!=null&&fresh.isEmailVerified())authDone();
                    else{
                        status.setTextColor(Color.rgb(255,107,107));
                        status.setText(t.isSuccessful()?"Почта ещё не подтверждена. Нажми на ссылку в письме и повтори.":authMessage(t.getException()));
                    }
                });
            }else{
                lastEmailPw=pw;auth.signInWithEmailAndPassword(em,pw).addOnCompleteListener(t->{
                    done.setEnabled(true);
                    FirebaseUser f=auth.getCurrentUser();
                    if(t.isSuccessful()&&f!=null&&f.isEmailVerified())authDone();
                    else{
                        status.setTextColor(Color.rgb(255,107,107));
                        status.setText(t.isSuccessful()?"Почта ещё не подтверждена. Нажми на ссылку в письме и повтори.":authMessage(t.getException()));
                    }
                });
            }
        });
        resend.setOnClickListener(x->{
            FirebaseUser cu=auth.getCurrentUser();
            if(cu==null){
                status.setTextColor(Color.rgb(255,107,107));
                status.setText("Нажми «Я подтвердил(а) почту» или вернись ко входу.");
                return;
            }
            resend.setEnabled(false);
            cu.sendEmailVerification().addOnCompleteListener(mail->{
                if(mail.isSuccessful()){
                    status.setTextColor(Color.rgb(70,210,135));
                    status.setText("Письмо отправлено повторно");
                }else{
                    status.setTextColor(Color.rgb(255,107,107));
                    status.setText("Не удалось отправить: "+authMessage(mail.getException()));
                }
                resend.postDelayed(()->resend.setEnabled(true),30000);
            });
        });
        back.setOnClickListener(x->{auth.signOut();showAuth();});
    }
    void authDone(){
        FirebaseUser u=auth.getCurrentUser();
        if(u==null){toast("Не удалось получить аккаунт");return;}
        uid=u.getUid();
        registerPushAndSession();
        // local profile data belongs to one account: wipe it when another account signs in on this device
        android.content.SharedPreferences pp=getSharedPreferences("echo_profile",MODE_PRIVATE);
        String owner=pp.getString("owner",null);
        if(owner!=null&&!owner.equals(uid)){
            pp.edit().clear().apply();
            String em=u.getEmail();
            profileName=em!=null&&em.contains("@")?em.substring(0,em.indexOf('@')):"Пользователь";
            profileUsername="";profileAbout="Расскажи о себе";profileLocation="Не указано";profileBirthday="Не указан";profileMusic="Не выбрано";
            profilePhotoUri=null;
            verifiedCache.clear();
        }
        pp.edit().putString("owner",uid).apply();
        rememberAccount();
        // restore the profile from Firestore (works on a new phone / after reinstall)
        db.collection("users").document(uid).get().addOnCompleteListener(t->{
            DocumentSnapshot d=t.isSuccessful()?t.getResult():null;
            if(d!=null&&d.exists()&&Boolean.TRUE.equals(d.getBoolean("banned"))){auth.signOut();uid=null;toast("Доступ к Echo Messenger заблокирован владельцем проекта");showAuth();return;}
            String remoteUsername=d!=null&&d.exists()?d.getString("username"):null;
            if(remoteUsername!=null&&!remoteUsername.isEmpty()){
                restoreProfileFrom(d);
                rememberAccount();
                getSharedPreferences("echo_onboarding",MODE_PRIVATE).edit().remove("pending_"+uid).apply();
                buildShell();showChats();
                return;
            }
            long created=u.getMetadata()!=null?u.getMetadata().getCreationTimestamp():0;
            boolean fresh=System.currentTimeMillis()-created<3L*24*3600*1000;
            if(isOnboardingPending(uid)||(t.isSuccessful()&&fresh))showOnboarding();
            else{buildShell();showChats();}
        });
    }
    void restoreProfileFrom(DocumentSnapshot d){
        String v;
        v=d.getString("name");if(v!=null&&!v.isEmpty())profileName=v;
        v=d.getString("username");if(v!=null&&!v.isEmpty())profileUsername=v;
        v=d.getString("about");if(v!=null&&!v.isEmpty())profileAbout=v;
        v=d.getString("location");if(v!=null&&!v.isEmpty())profileLocation=v;
        v=d.getString("birthday");if(v!=null&&!v.isEmpty())profileBirthday=v;
        v=d.getString("music");if(v!=null&&!v.isEmpty())profileMusic=v;
        getSharedPreferences("echo_profile",MODE_PRIVATE).edit().putString("name",profileName).putString("username",profileUsername).putString("about",profileAbout).putString("location",profileLocation).putString("birthday",profileBirthday).putString("music",profileMusic).putString("owner",uid).apply();
    }
    final java.util.concurrent.ExecutorService io=java.util.concurrent.Executors.newSingleThreadExecutor();
    // decodes a downsampled bitmap on a background thread so big photos never block the UI or run out of memory
    void loadPhoto(ImageView iv,Uri uri,int px){
        io.execute(()->{
            try{
                android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds=true;
                try(java.io.InputStream in=getContentResolver().openInputStream(uri)){android.graphics.BitmapFactory.decodeStream(in,null,o);}
                int sample=1;
                while(o.outWidth/(sample*2)>=px&&o.outHeight/(sample*2)>=px)sample*=2;
                android.graphics.BitmapFactory.Options o2=new android.graphics.BitmapFactory.Options();
                o2.inSampleSize=sample;
                android.graphics.Bitmap decoded;
                try(java.io.InputStream in=getContentResolver().openInputStream(uri)){decoded=android.graphics.BitmapFactory.decodeStream(in,null,o2);}
                final android.graphics.Bitmap bmp=decoded;
                if(bmp!=null)runOnUiThread(()->iv.setImageBitmap(bmp));
            }catch(Exception ignored){}
        });
    }
    @Override protected void onDestroy(){
        stopAurora();if(navAnim!=null)navAnim.cancel();
        if(listener!=null){listener.remove();listener=null;}
        if(listener2!=null){listener2.remove();listener2=null;}
        io.shutdownNow();
        ui.removeCallbacksAndMessages(null);
        if(netCallback!=null){try{((android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCallback);}catch(Exception ignored){}}
        super.onDestroy();
    }
    // Android 15+ draws apps edge-to-edge: pad the content for the status bar, nav bar and keyboard
    void setupInsets(){
        android.view.View frame=getWindow().getDecorView().findViewById(android.R.id.content);
        frame.setOnApplyWindowInsetsListener((v,ins)->{
            int l,t,r,b;
            if(android.os.Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=ins.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
                android.graphics.Insets ime=ins.getInsets(android.view.WindowInsets.Type.ime());
                l=bars.left;t=bars.top;r=bars.right;b=Math.max(bars.bottom,ime.bottom);
            }else{
                l=ins.getSystemWindowInsetLeft();t=ins.getSystemWindowInsetTop();r=ins.getSystemWindowInsetRight();b=ins.getSystemWindowInsetBottom();
            }
            v.setPadding(l,t,r,b);
            if(frost!=null&&frostView!=null){frost.setInset(t);android.view.ViewGroup.LayoutParams lp=frostView.getLayoutParams();int hh=t+dp(30);if(lp.height!=hh){lp.height=hh;frostView.setLayoutParams(lp);}}
            return ins;
        });
        frame.requestApplyInsets();
    }
    android.graphics.drawable.Drawable barBg(float r){return glassFull(r);}
    ImageView barButton(int res){ImageView v=new ImageView(this);v.setImageResource(res);v.setColorFilter(TEXT);v.setScaleType(ImageView.ScaleType.CENTER_INSIDE);v.setPadding(dp(14),dp(14),dp(14),dp(14));v.setBackground(barBg(26));pressable(v,.88f);return v;}
    // Telegram-style blue seal with a white check, shown at the end of a name
    void setVerified(TextView t,boolean on,int sizeDp){
        if(!on){t.setCompoundDrawablesRelative(null,null,null,null);return;}
        android.graphics.drawable.Drawable d=getResources().getDrawable(R.drawable.ic_verified,getTheme());
        d.setBounds(0,0,dp(sizeDp),dp(sizeDp));
        t.setCompoundDrawablesRelative(null,null,d,null);
        t.setCompoundDrawablePadding(dp(5));
    }
    // ===== Network status: "Подключение…" while offline, "Обновление…" until fresh data arrives =====
    void applyNetStatus(){
        String label=netState==1?"Подключение…":netState==2?"Обновление…":null;
        if(inShell&&title!=null)title.setText(label!=null?label:titleBase);
        if(chatSub!=null)chatSub.setText(label!=null?label:chatSubBase);
        if(statusDot!=null)statusDot.setTextColor(netState==0?Color.rgb(50,210,120):Color.rgb(255,170,60));
    }
    void setNet(boolean connected){
        if(!connected){hasNet=false;netState=1;applyNetStatus();return;}
        boolean wasOffline=!hasNet;
        hasNet=true;
        if(!wasOffline&&netState!=1)return;
        netState=2;
        updatingSince=System.currentTimeMillis();
        applyNetStatus();
        Runnable finish=()->{
            if(hasNet&&netState==2){netState=0;applyNetStatus();}
        };
        // ask the server for fresh data; realtime listeners resume on their own, this tells us when we are in sync
        Runnable done=()->{
            long wait=Math.max(0,800-(System.currentTimeMillis()-updatingSince));
            ui.postDelayed(finish,wait);
        };
        if(uid!=null)db.collection("users").document(uid).get(Source.SERVER).addOnCompleteListener(t->done.run());
        else done.run();
        ui.postDelayed(finish,10000);
    }
    void startNetworkWatch(){
        android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if(cm==null)return;
        android.net.Network active=cm.getActiveNetwork();
        android.net.NetworkCapabilities nc=active==null?null:cm.getNetworkCapabilities(active);
        boolean start=nc!=null&&nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
        hasNet=start;
        netState=start?0:1;
        netCallback=new android.net.ConnectivityManager.NetworkCallback(){
            @Override public void onCapabilitiesChanged(android.net.Network n,android.net.NetworkCapabilities c){
                boolean ok=c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)&&c.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                runOnUiThread(()->setNet(ok));
            }
            @Override public void onLost(android.net.Network n){runOnUiThread(()->setNet(false));}
        };
        try{cm.registerDefaultNetworkCallback(netCallback);}catch(Exception ignored){netCallback=null;}
    }
    boolean isOnboardingPending(String id){return id!=null&&getSharedPreferences("echo_onboarding",MODE_PRIVATE).getBoolean("pending_"+id,false);}
    android.view.View profileAvatarView(){
        if(profilePhotoUri!=null){
            try{
                java.io.InputStream in=getContentResolver().openInputStream(profilePhotoUri);
                if(in!=null)in.close();
                ImageView iv=new ImageView(this);
                iv.setBackground(glassAccent(BLUE,100));
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
                iv.setClipToOutline(true);
                loadPhoto(iv,profilePhotoUri,dp(224));
                return iv;
            }catch(Exception ignored){}
        }
        TextView a=tv(ico("❤"),42,TEXT);a.setGravity(Gravity.CENTER);a.setBackground(glassAccent(BLUE,100));return a;
    }
    // Onboarding: shown once after a new account confirms email and signs in for the first time
    void showOnboarding(){
        if(listener!=null){listener.remove();listener=null;}
        onboardPhoto=null;
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root=new LinearLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        ScrollView sv=new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(24),dp(56),dp(24),dp(24));
        sv.addView(page,new ViewGroup.LayoutParams(-1,-2));
        root.addView(sv,new LinearLayout.LayoutParams(-1,-1));
        TextView heading=tv("Почти готово",28,TEXT);
        heading.setTypeface(null,Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        page.addView(heading,margins(0,0,0,6,48));
        TextView sub=tv("Придумай имя пользователя и добавь фото — так тебя смогут найти друзья",14,MUTED);
        sub.setGravity(Gravity.CENTER);
        page.addView(sub,margins(0,0,0,28,44));
        ImageView photoView=new ImageView(this);
        photoView.setBackground(glass(60));
        photoView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        photoView.setImageResource(R.drawable.ic_onb_camera);
        photoView.setColorFilter(BLUE);
        photoView.setPadding(dp(36),dp(36),dp(36),dp(36));
        photoView.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        photoView.setClipToOutline(true);
        LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(dp(120),dp(120));
        plp.gravity=Gravity.CENTER_HORIZONTAL;
        page.addView(photoView,plp);
        TextView photoHint=tv("Нажми на кружок, чтобы выбрать фото (можно и позже)",12,MUTED);
        photoHint.setGravity(Gravity.CENTER);
        page.addView(photoHint,margins(0,10,0,24,28));
        onPhotoPicked=()->{
            photoView.clearColorFilter();
            photoView.setPadding(0,0,0,0);
            photoView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            loadPhoto(photoView,onboardPhoto,dp(240));
        };
        photoView.setOnClickListener(x->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            startActivityForResult(i,402);
        });
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(glass(16));
        row.setPadding(dp(16),0,dp(16),0);
        TextView at=tv("@",18,BLUE);
        EditText uname=new EditText(this);
        uname.setHint("username");
        uname.setHintTextColor(MUTED);
        uname.setTextColor(TEXT);
        uname.setTextSize(17);
        uname.setBackground(null);
        uname.setSingleLine(true);
        uname.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        uname.setFilters(new android.text.InputFilter[]{
            (src,st,en,dst,ds,de)->{
                StringBuilder sb=new StringBuilder();
                for(int i=st;i<en;i++){
                    char c=Character.toLowerCase(src.charAt(i));
                    if((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_')sb.append(c);
                }
                return sb.toString();
            },
            new android.text.InputFilter.LengthFilter(24)
        });
        row.addView(at,new LinearLayout.LayoutParams(-2,-2));
        row.addView(uname,new LinearLayout.LayoutParams(0,dp(56),1));
        page.addView(row,margins(0,0,0,6,56));
        TextView status=tv("От 3 до 24 символов: латинские буквы, цифры и _",12,MUTED);
        status.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(status,margins(4,0,4,16,40));
        final int[] unameState=attachUsernameChecker(uname,status,"От 3 до 24 символов: латинские буквы, цифры и _; начинается с буквы",new String[]{""},false,null);
        Button go=btn("Продолжить");
        go.setBackground(glassAccent(BLUE,18));
        page.addView(go,margins(0,4,0,10,54));
        Button logout=btn("Выйти из аккаунта");
        logout.setBackground(null);
        logout.setTextColor(MUTED);
        page.addView(logout,margins(0,0,0,0,48));
        logout.setOnClickListener(x->{
            auth.signOut();uid=null;content=null;showAuth();
        });
        go.setOnClickListener(x->{
            String name=uname.getText().toString().trim().replace("@", "").toLowerCase(java.util.Locale.ROOT);
            String nameErr=usernameError(name);
            if(nameErr!=null){
                status.setTextColor(Color.rgb(255,107,107));
                status.setText(nameErr);
                uname.requestFocus();
                return;
            }
            if(uid==null)return;
            go.setEnabled(false);
            status.setTextColor(MUTED);
            status.setText("Проверяем, свободно ли имя…");
            db.runTransaction(tr->{
                DocumentReference nameRef=db.collection("usernames").document(name);
                DocumentSnapshot snap=tr.get(nameRef);
                if(snap.exists()&&(!uid.equals(snap.getString("uid"))||"channel".equals(snap.getString("kind"))))
                    throw new FirebaseFirestoreException("taken",FirebaseFirestoreException.Code.ALREADY_EXISTS);
                Map<String,Object> claim=new HashMap<>();
                claim.put("uid",uid);
                tr.set(nameRef,claim);
                Map<String,Object> user=new HashMap<>();
                user.put("username",name);
                user.put("name",name);
                tr.set(db.collection("users").document(uid),user,SetOptions.merge());
                return null;
            }).addOnCompleteListener(t->{
                if(t.isSuccessful()){finishOnboarding(name);return;}
                Exception ex=t.getException();
                FirebaseFirestoreException.Code code=ex instanceof FirebaseFirestoreException?((FirebaseFirestoreException)ex).getCode():null;
                if(code==FirebaseFirestoreException.Code.ALREADY_EXISTS){
                    go.setEnabled(true);
                    status.setTextColor(Color.rgb(255,107,107));
                    status.setText("Имя @"+name+" уже занято — попробуй другое");
                }else if(code==FirebaseFirestoreException.Code.PERMISSION_DENIED){
                    go.setEnabled(true);
                    status.setTextColor(Color.rgb(255,107,107));
                    status.setText("Firestore запретил проверку username. Опубликуй новые firestore.rules и повтори.");
                }else{
                    go.setEnabled(true);
                    status.setTextColor(Color.rgb(255,107,107));
                    status.setText("Не удалось сохранить имя: "+authMessage(ex));
                }
            });
        });
        setContentView(root);
    }
    void finishOnboarding(String name){
        profileUsername=name;
        profileName=name;
        profileAbout="Расскажи о себе";profileLocation="Не указано";profileBirthday="Не указан";profileMusic="Не выбрано";
        android.content.SharedPreferences.Editor ed=getSharedPreferences("echo_profile",MODE_PRIVATE).edit().putString("username",name).putString("name",name).putString("about",profileAbout).putString("location",profileLocation).putString("birthday",profileBirthday).putString("music",profileMusic).putString("owner",uid);
        if(onboardPhoto!=null){profilePhotoUri=onboardPhoto;ed.putString("photo",onboardPhoto.toString());}
        else{profilePhotoUri=null;ed.remove("photo");}
        ed.apply();
        getSharedPreferences("echo_onboarding",MODE_PRIVATE).edit().remove("pending_"+uid).apply();
        onboardPhoto=null;onPhotoPicked=null;
        buildShell();
        showChats();
    }
    String authMessage(Exception e){
        if(e==null)return "Неизвестная ошибка";
        if(e instanceof com.google.firebase.FirebaseNetworkException)return "Нет соединения с интернетом";
        if(e instanceof com.google.firebase.FirebaseTooManyRequestsException)return "Слишком много попыток. Подожди немного и повтори";
        if(e instanceof com.google.firebase.auth.FirebaseAuthException){
            String code=((com.google.firebase.auth.FirebaseAuthException)e).getErrorCode();
            switch(code){
                case "ERROR_INVALID_EMAIL":return "Некорректный адрес почты";
                case "ERROR_WRONG_PASSWORD":
                case "ERROR_INVALID_CREDENTIAL":return "Неверная почта или пароль. Забыли пароль? Нажми «Забыли пароль?»";
                case "ERROR_USER_NOT_FOUND":return "Аккаунт с такой почтой не найден";
                case "ERROR_USER_DISABLED":return "Этот аккаунт отключён";
                case "ERROR_EMAIL_ALREADY_IN_USE":return "Эта почта уже зарегистрирована. Войди или восстанови пароль";
                case "ERROR_WEAK_PASSWORD":return "Слишком простой пароль, придумай подлиннее";
                case "ERROR_TOO_MANY_REQUESTS":return "Слишком много попыток. Подожди немного и повтори";
                case "ERROR_OPERATION_NOT_ALLOWED":return "Этот способ входа выключен в Firebase Authentication";
                case "ERROR_REQUIRES_RECENT_LOGIN":return "Войди заново и повтори действие";
                default:break;
            }
        }
        if(e instanceof com.google.firebase.auth.FirebaseAuthUserCollisionException)return "Эта почта уже зарегистрирована. Войди или восстанови пароль";
        if(e instanceof com.google.firebase.auth.FirebaseAuthInvalidCredentialsException)return "Неверная почта или пароль. Забыли пароль? Нажми «Забыли пароль?»";
        return e.getMessage()==null?"Ошибка авторизации":e.getMessage();
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void buildShell(){
        inChatMode=false;
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout column=new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        LinearLayout header=new LinearLayout(this);
        appHeader=header;
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14),dp(6),dp(6),dp(4));
        headerAvatar=avatar(profileName,dp(36));
        headerAvatar.setOnClickListener(x->showProfile());
        avatarStack=new LinearLayout(this);
        avatarStack.addView(headerAvatar,new LinearLayout.LayoutParams(dp(36),dp(36)));
        header.addView(avatarStack,new LinearLayout.LayoutParams(-2,dp(36)));
        title=tv("Echo",21,TEXT);
        title.setTypeface(null,Typeface.BOLD);
        title.setPadding(dp(14),0,0,0);
        titleShader=new android.graphics.LinearGradient(0,0,dpf(120),0,new int[]{Color.WHITE,Color.rgb(160,255,200),Color.rgb(190,228,255),Color.WHITE},new float[]{0f,.35f,.65f,1f},android.graphics.Shader.TileMode.MIRROR);
        title.getPaint().setShader(titleShader);
        title.setOnClickListener(x->{if(windowSnow!=null&&animsOn())windowSnow.gust();});
        header.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        inShell=true;
        statusDot=new TextView(this);
        TextView moreBtn=tv(ico("⋮"),24,TEXT);
        moreBtn.setGravity(Gravity.CENTER);
        moreBtn.setOnClickListener(x->showMainMenu(x));
        header.addView(moreBtn,new LinearLayout.LayoutParams(dp(44),dp(48)));
        column.addView(header);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        // lists scroll *under* the floating glass nav bar instead of stopping above it
        content.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener(){
            public void onChildViewAdded(android.view.View parent,android.view.View child){
                if(!inChatMode&&child instanceof ScrollView){ScrollView sv=(ScrollView)child;sv.setClipToPadding(false);sv.setPadding(sv.getPaddingLeft(),sv.getPaddingTop(),sv.getPaddingRight(),dp(104));content.setPadding(0,0,0,0);}
            }
            public void onChildViewRemoved(android.view.View parent,android.view.View child){}
        });
        column.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(column,new FrameLayout.LayoutParams(-1,-1));

        fab=tv(ico("✎"),24,Color.WHITE);
        fab.setGravity(Gravity.CENTER);
        fab.setBackground(glassAccent(DEEP,29));
        pressable(fab,.9f);
        fab.setElevation(dp(6));
        fab.setOnClickListener(x->showNewChatMenu());
        FrameLayout.LayoutParams fabParams=new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.BOTTOM|Gravity.RIGHT);
        fabParams.setMargins(0,0,dp(20),dp(104));
        root.addView(fab,fabParams);
        miniFab=new ImageView(this);
        miniFab.setImageResource(R.drawable.ic_onb_camera);
        miniFab.setColorFilter(Color.rgb(200,214,228));
        miniFab.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        miniFab.setPadding(dp(11),dp(11),dp(11),dp(11));
        miniFab.setBackground(glassFull(22));
        pressable(miniFab,.9f);
        miniFab.setElevation(dp(5));
        miniFab.setOnClickListener(x->newStoryDialog());
        FrameLayout.LayoutParams miniParams=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.BOTTOM|Gravity.RIGHT);
        miniParams.setMargins(0,0,dp(27),dp(172));
        root.addView(miniFab,miniParams);

        navIndicator=new LiquidGlassDrawable(dpf(24),dpf(1.1f),true,ACCENT);
        navIndWidth=0;
        navBar=new LinearLayout(this){
            @Override protected void dispatchDraw(android.graphics.Canvas c){
                if(navIndicator!=null&&navIndWidth>0){navIndicator.setBounds((int)navIndLeft,navIndTop,(int)(navIndLeft+navIndWidth),navIndBottom);navIndicator.draw(c);}
                super.dispatchDraw(c);
                if(frostCache&&navCap!=null){navCap.setBounds(dp(30),dp(1),getWidth()-dp(30),dp(12));navCap.draw(c);}
            }
        };
        navCap=new WinterDecor.SnowCap(getResources().getDisplayMetrics().density,11);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER);
        navBar.setPadding(dp(10),dp(6),dp(10),dp(6));
        navBar.setBackground(new LiquidGlassDrawable(dpf(32),dpf(1.1f),true,0).backing(Color.argb(240,15,21,42)));
        navBar.setElevation(dp(10));
        int[] navIconRes={R.drawable.ic_nav_chats,R.drawable.ic_nav_contacts,R.drawable.ic_nav_settings,R.drawable.ic_nav_profile};
        String[] navLabelText={"Чаты","Контакты","Настройки","Профиль"};
        for(int i=0;i<4;i++){
            final int idx=i;
            LinearLayout item=new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            navIcons[i]=new ImageView(this);
            navIcons[i].setImageResource(navIconRes[i]);
            navIcons[i].setColorFilter(TEXT);
            navIcons[i].setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            navLabels[i]=tv(navLabelText[i],11,MUTED);
            navLabels[i].setGravity(Gravity.CENTER);
            FrameLayout iconHolder=new FrameLayout(this);
            iconHolder.addView(navIcons[i],new FrameLayout.LayoutParams(dp(24),dp(26),Gravity.CENTER));
            if(i==0){
                navBadge=tv("",10,Color.WHITE);
                navBadge.setGravity(Gravity.CENTER);
                navBadge.setTypeface(null,Typeface.BOLD);
                navBadge.setBackground(bg(DEEP,9));
                navBadge.setPadding(dp(4),0,dp(4),0);
                navBadge.setMinWidth(dp(16));
                navBadge.setVisibility(android.view.View.GONE);
                iconHolder.addView(navBadge,new FrameLayout.LayoutParams(-2,dp(16),Gravity.TOP|Gravity.RIGHT));
            }
            item.addView(iconHolder,new LinearLayout.LayoutParams(dp(36),dp(26)));
            item.addView(navLabels[i],new LinearLayout.LayoutParams(-2,dp(16)));
            pressable(item,.9f);
            item.setOnClickListener(x->{
                if(idx==0)showChats();
                else if(idx==1)showContacts();
                else if(idx==2)showSettings();
                else showProfile();
            });
            navBar.addView(item,new LinearLayout.LayoutParams(0,dp(54),1));
        }
        FrameLayout.LayoutParams navParams=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        navParams.setMargins(dp(22),0,dp(22),dp(16));
        root.addView(navBar,navParams);
        setContentView(root);
        if(animsOn()){root.setAlpha(0f);root.animate().alpha(1f).setDuration(380).start();}
        ui.postDelayed(this::maybeShowWinterNews,1100);
    }
    // один раз после обновления рассказываем, что изменилось
    void maybeShowWinterNews(){
        android.content.SharedPreferences sp=getSharedPreferences("echo_settings",MODE_PRIVATE);
        if(isFinishing()||sp.getBoolean("winter_news_120",false))return;
        sp.edit().putBoolean("winter_news_120",true).apply();
        new android.app.AlertDialog.Builder(this).setTitle("❄ Зимнее обновление 1.1")
            .setMessage("• Новая иконка и изумрудно-ледяная тема\n• Снег 2.0: кристаллы, порывы ветра, три уровня — тапни по «Echo», чтобы подул ветер\n• Иней, сосульки, сугробы и снежная шапка на панели\n• Зимние обои чата и ледяной блик на заголовке\n• Быстрее: настройки кэшируются, снег рисуется спрайтами, авто-экономия при режиме энергосбережения\n\nВсё настраивается: Настройки → Чаты.")
            .setPositiveButton("Круто!",null)
            .setNeutralButton("Метель!",(d,w)->{sp.edit().putInt("snow_level",2).apply();if(windowSnow!=null)windowSnow.gust();})
            .show();
    }

    @Override protected void onResume(){super.onResume();resumed=true;refreshSystemMotion();startAurora();maybeAutoLock();if(uid!=null&&db!=null){Map<String,Object> state=new HashMap<>();state.put("online",true);state.put("lastSeen",FieldValue.serverTimestamp());db.collection("users").document(uid).set(state,SetOptions.merge());}}
    @Override protected void onPause(){super.onPause();resumed=false;if(!lockShowing)pausedAt=android.os.SystemClock.elapsedRealtime();stopAurora();if(uid!=null&&db!=null){Map<String,Object> state=new HashMap<>();state.put("online",false);state.put("lastSeen",FieldValue.serverTimestamp());db.collection("users").document(uid).set(state,SetOptions.merge());}}
    void clear(String h){
        int newTab=h.equals("Чаты")?0:h.equals("Контакты")?1:h.equals("Настройки")?2:h.equals("Профиль")?3:-1;
        int newLevel=newTab>=0?0:1;
        int dir=newLevel!=curLevel?(newLevel>curLevel?1:-1):(newTab>=0&&curTab>=0?(newTab==curTab?0:(newTab>curTab?1:-1)):1);
        curLevel=newLevel;if(newTab>=0)curTab=newTab;
        if(listener!=null){listener.remove();listener=null;}
        if(listener2!=null){listener2.remove();listener2=null;}
        content.removeAllViews();
        titleBase=h;
        chatSub=null;
        if(!inShell&&title!=null)title.setText(h);
        applyNetStatus();
        chatMode(false);
        if(appHeader!=null)appHeader.setVisibility(android.view.View.VISIBLE);
        if(headerAvatar!=null)headerAvatar.setText(firstLetter(profileName));
        if(fab!=null)fab.setVisibility(android.view.View.GONE);
        if(miniFab!=null)miniFab.setVisibility(android.view.View.GONE);
        if(avatarStack!=null)while(avatarStack.getChildCount()>1)avatarStack.removeViewAt(1);
        if(h.equals("Чаты"))highlightNav(0);
        else if(h.equals("Контакты"))highlightNav(1);
        else if(h.equals("Настройки"))highlightNav(2);
        else if(h.equals("Профиль"))highlightNav(3);
        pageIn(dir);
    }
    void chatMode(boolean on){
        if(navBar==null)return;
        content.setPadding(0,0,0,on?0:dp(92));
        if(on==inChatMode)return;
        inChatMode=on;
        applyFrost();
        navBar.animate().cancel();
        if(on){
            stopAurora();
            if(!animsOn()){navBar.setVisibility(android.view.View.GONE);return;}
            navBar.animate().translationY(dp(120)).alpha(0f).setDuration(220).setInterpolator(new android.view.animation.AccelerateInterpolator())
                .withEndAction(()->{if(inChatMode)navBar.setVisibility(android.view.View.GONE);}).start();
        }else{
            startAurora();
            navBar.setVisibility(android.view.View.VISIBLE);
            if(animsOn()){
                navBar.setTranslationY(dp(120));navBar.setAlpha(0f);
                navBar.animate().translationY(0f).alpha(1f).setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(.9f)).start();
            }else{navBar.setTranslationY(0f);navBar.setAlpha(1f);}
        }
    }
    void highlightNav(int active){
        for(int i=0;i<4;i++){
            if(navLabels[i]==null)continue;
            navLabels[i].setTextColor(i==active?ACCENT:MUTED);
            navIcons[i].setAlpha(i==active?1f:0.55f);
            if(animsOn())navIcons[i].animate().scaleX(i==active?1.14f:1f).scaleY(i==active?1.14f:1f).setDuration(260).setInterpolator(new android.view.animation.OvershootInterpolator(2f)).start();
        }
        moveNavIndicator(active,0);
    }
    GradientDrawable oval(int c){GradientDrawable g=new GradientDrawable();g.setShape(GradientDrawable.OVAL);g.setColor(c);return g;}
    String firstLetter(String name){
        if(name==null||name.trim().isEmpty())return "?";
        String t=name.trim();
        return new String(Character.toChars(t.codePointAt(0))).toUpperCase();
    }
    TextView avatar(String name,int size){
        int color=AVATAR_PALETTE[Math.abs(name==null?0:name.hashCode())%AVATAR_PALETTE.length];
        TextView a=tv(firstLetter(name),size/getResources().getDisplayMetrics().density*0.42f,Color.WHITE);
        a.setGravity(Gravity.CENTER);
        a.setTypeface(null,Typeface.BOLD);
        a.setBackground(oval(color));
        return a;
    }
    void showError(String e){clear("Echo");TextView x=tv("Ошибка подключения\n\n"+e+"\n\nПроверь Firebase, Auth и Firestore.",16,TEXT);x.setGravity(Gravity.CENTER);content.addView(x,new LinearLayout.LayoutParams(-1,-1));}
    static class ChatItem{boolean verified;String id="",name="",type="group",owner="",username="",last="",lastSender="",time="";int members;long at;boolean mine;}
    String nz(String s){return s==null?"":s;}
    String fmtTime(java.util.Date dt){
        java.text.SimpleDateFormat day=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.getDefault());
        boolean today=day.format(dt).equals(day.format(new java.util.Date()));
        return new java.text.SimpleDateFormat(today?"HH:mm":"dd.MM",java.util.Locale.getDefault()).format(dt);
    }
    ChatItem chatFrom(DocumentSnapshot d){
        ChatItem c=new ChatItem();
        c.id=d.getId();
        c.name=nz(d.getString("name"));
        String storedType=d.getString("type");
        c.type="direct".equals(storedType)?"direct":("channel".equals(storedType)?"channel":"group");
        c.owner=nz(d.getString("owner"));
        c.username=nz(d.getString("username"));
        c.verified=Boolean.TRUE.equals(d.getBoolean("verified"));
        verifiedCache.put("c:"+d.getId(),c.verified);
        c.last=nz(d.getString("lastText"));
        c.lastSender=nz(d.getString("lastSender"));
        java.util.List<?> mem=(java.util.List<?>)d.get("members");
        c.members=mem==null?0:mem.size();
        c.mine=mem!=null&&uid!=null&&mem.contains(uid);
        java.util.Date at=d.getDate("lastAt");
        c.at=at==null?System.currentTimeMillis():at.getTime();
        c.time=at==null?"":fmtTime(at);
        return c;
    }
    CollectionReference messagesOf(String chatId){
        if(chatId.equals("general"))return db.collection("rooms").document("general").collection("messages");
        return db.collection("chats").document(chatId).collection("messages");
    }
    void showChats(){
        clear("Чаты");
        fab.setVisibility(android.view.View.VISIBLE);
        if(miniFab!=null)miniFab.setVisibility(android.view.View.VISIBLE);
        chatQuery="";
        chatTab=0;
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(page);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        HorizontalScrollView hs=new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout storiesRow=new LinearLayout(this);
        storiesRow.setPadding(dp(8),dp(2),dp(8),0);
        hs.addView(storiesRow);
        page.addView(hs,new LinearLayout.LayoutParams(-1,dp(88)));
        addStoryBubble(storiesRow,"Моя история",true,false,()->showStories());

        EditText search=new EditText(this);
        search.setHint("Поиск чатов");
        search.setHintTextColor(MUTED);
        search.setTextColor(TEXT);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setPadding(dp(16),0,dp(18),0);
        search.setCompoundDrawablePadding(dp(10));
        android.graphics.drawable.Drawable sIcon=getResources().getDrawable(android.R.drawable.ic_menu_search,getTheme()).mutate();
        sIcon.setColorFilter(MUTED,android.graphics.PorterDuff.Mode.SRC_IN);
        sIcon.setBounds(0,0,dp(20),dp(20));
        search.setCompoundDrawables(sIcon,null,null,null);
        search.setBackground(glass(24));
        page.addView(search,margins(14,2,14,6,46));

        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout contactsBox=new LinearLayout(this);
        contactsBox.setOrientation(LinearLayout.VERTICAL);
        page.addView(contactsBox,new LinearLayout.LayoutParams(-1,-2));
        renderChatRows(list);

        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int a,int b,int c){}
            public void onTextChanged(CharSequence cs,int a,int b,int c){chatQuery=cs.toString();renderChatRows(list);}
            public void afterTextChanged(android.text.Editable ed){}
        });

        listener=db.collection("rooms").document("general").collection("messages").orderBy("createdAt",Query.Direction.DESCENDING).limit(1).addSnapshotListener((snap,err)->{
            if(err!=null||snap==null)return;
            if(snap.isEmpty()){
                generalLast="Пока нет сообщений — напиши первым";
                generalTime="";
                generalAt=0;
            }else{
                DocumentSnapshot last=snap.getDocuments().get(0);
                String text=last.getString("text");
                String sender=last.getString("sender");
                generalLast=(uid!=null&&uid.equals(sender)?"Вы: ":"")+(text==null?"":text);
                java.util.Date when=last.getDate("createdAt");
                generalTime=when==null?"":fmtTime(when);
                generalAt=when==null?0:when.getTime();
            }
            requestRender(list);
            refreshUnread("general",generalAt,()->requestRender(list));
        });
        if(uid!=null){
            listener2=db.collection("chats").whereArrayContains("members",uid).addSnapshotListener((snap,err)->{
                if(err!=null||snap==null)return;
                myChats.clear();
                for(DocumentSnapshot d:snap.getDocuments())myChats.add(chatFrom(d));
                java.util.Collections.sort(myChats,(p,q)->Long.compare(q.at,p.at));
                requestRender(list);
                for(ChatItem uc:myChats)refreshUnread(uc.id,uc.at,()->requestRender(list));
            });
        }
        loadContactsSection(contactsBox,storiesRow);
    }
    // ===== Stories row + contacts section (data comes only from this app's Firestore) =====
    void addStoryBubble(LinearLayout row,String label,boolean mine,boolean hasStory,Runnable click){
        LinearLayout col=new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout holder=new FrameLayout(this);
        if(hasStory){
            TextView ring=new TextView(this);
            GradientDrawable rg=new GradientDrawable();
            rg.setShape(GradientDrawable.OVAL);
            rg.setColor(Color.TRANSPARENT);
            rg.setStroke(dp(2),Color.rgb(76,200,100));
            ring.setBackground(rg);
            holder.addView(ring,new FrameLayout.LayoutParams(dp(62),dp(62),Gravity.CENTER));
        }
        holder.addView(avatar(mine?profileName:label,dp(52)),new FrameLayout.LayoutParams(dp(52),dp(52),Gravity.CENTER));
        if(mine){
            TextView plus=tv("+",14,Color.WHITE);
            plus.setGravity(Gravity.CENTER);
            GradientDrawable pb=oval(DEEP);
            pb.setStroke(dp(2),BG);
            plus.setBackground(pb);
            holder.addView(plus,new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.BOTTOM|Gravity.RIGHT));
        }
        col.addView(holder,new LinearLayout.LayoutParams(dp(62),dp(62)));
        TextView nm=tv(label,11,TEXT);
        nm.setSingleLine(true);
        nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nm.setGravity(Gravity.CENTER);
        col.addView(nm,new LinearLayout.LayoutParams(dp(66),dp(20)));
        col.setOnClickListener(v->click.run());
        row.addView(col,new LinearLayout.LayoutParams(dp(72),-2));
    }
    void loadStoryBubble(LinearLayout row,String userId,String name){
        db.collection("users").document(userId).collection("stories").orderBy("createdAt",Query.Direction.DESCENDING).limit(1).get().addOnSuccessListener(ss->{
            if(ss.isEmpty())return;
            DocumentSnapshot sd=ss.getDocuments().get(0);
            Long expiry=sd.getLong("expiresAt");
            if(expiry!=null&&expiry<System.currentTimeMillis())return;
            final String body=nz(sd.getString("text"));
            Long stored=sd.getLong("backgroundColor");
            final int color=stored==null?CARD2:stored.intValue();
            addStoryBubble(row,name,false,true,()->showStoryDialog(name,body,color));
            addHeaderStackAvatar(name);
        }).addOnFailureListener(e->{});
    }
    void showStoryDialog(String author,String body,int color){
        TextView t=tv(body.isEmpty()?"История":body,20,Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(24),dp(56),dp(24),dp(56));
        t.setBackground(bg(color,0));
        new android.app.AlertDialog.Builder(this).setTitle(author).setView(t).setPositiveButton("Закрыть",null).show();
    }
    void loadContactsSection(LinearLayout box,LinearLayout storiesRow){
        if(uid==null)return;
        db.collection("users").limit(40).get().addOnSuccessListener(snap->{
            box.removeAllViews();
            int count=0,storyChecks=0;
            for(DocumentSnapshot u:snap.getDocuments()){
                if(u.getId().equals(uid))continue;
                final String id=u.getId();
                String n=u.getString("name");
                if(n==null||n.trim().isEmpty())n=u.getString("username");
                if(n==null||n.trim().isEmpty())n="Пользователь";
                final String name=n;
                if(count==0){
                    TextView head=tv("Ваши контакты в Echo",14,Color.rgb(98,170,235));
                    head.setTypeface(null,Typeface.BOLD);
                    head.setPadding(dp(16),0,dp(16),0);
                    box.addView(head,new LinearLayout.LayoutParams(-1,dp(40)));
                }
                boolean online=Boolean.TRUE.equals(u.getBoolean("online"));
                java.util.Date seen=u.getDate("lastSeen");
                String status;
                if(online)status="в сети";
                else if(seen==null)status="был(а) давно";
                else{String t=fmtTime(seen);status=t.contains(":")?"был(а) в "+t:"был(а) "+t;}
                addContactRow(box,name,status,online,Boolean.TRUE.equals(u.getBoolean("verified")),()->contactActions(id,name));
                if(storyChecks<12){storyChecks++;loadStoryBubble(storiesRow,id,name);}
                count++;
            }
        }).addOnFailureListener(e->{});
    }
    void addContactRow(LinearLayout list,String name,String status,boolean online,boolean verified,Runnable click){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14),dp(6),dp(14),dp(6));
        row.addView(avatar(name,dp(48)),new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(dp(14),0,0,0);
        TextView n=tv(name,16,TEXT);
        n.setTypeface(null,Typeface.BOLD);
        n.setSingleLine(true);
        setVerified(n,verified,15);
        TextView s=tv(status,14,online?Color.rgb(98,170,235):MUTED);
        s.setSingleLine(true);
        mid.addView(n,new LinearLayout.LayoutParams(-2,dp(22)));
        mid.addView(s,new LinearLayout.LayoutParams(-1,dp(20)));
        row.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        pressable(row,.975f);
        row.setOnClickListener(x->click.run());
        list.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }
    void contactActions(String id,String name){
        new android.app.AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"Открыть профиль","Написать сообщение"},(d,w)->{if(w==0)showUserProfile(id,name,()->showChats());else openDirectChat(id,name);}).show();
    }
    void renderChatRows(LinearLayout list){
        StringBuilder sg=new StringBuilder(chatQuery).append('|').append(generalLast).append('|').append(generalTime).append('|').append(unread.get("general"));
        for(ChatItem c:myChats)sg.append('|').append(c.id).append(c.name).append(c.type).append(c.last).append(c.lastSender).append(c.time).append(c.verified).append(c.members).append(unread.get(c.id));
        String sig=sg.toString();
        if(list.getChildCount()>0&&sig.equals(list.getTag()))return; // nothing visible changed: skip the rebuild
        list.setTag(sig);
        list.removeAllViews();
        String q=chatQuery.toLowerCase();
        int shown=0;
        if(q.isEmpty()||"echo messenger".contains(q)){
            addChatRow(list,"Echo Messenger","","Версия 0.9.0 Beta · новости и обновления","",()->simpleInfo("Echo Messenger","Echo Messenger\nВерсия 0.9.0 Beta\nМессенджер находится в разработке."),true,"");
            shown++;
        }
        if(q.isEmpty()||"общий чат".contains(q)){
            addChatRow(list,"Общий чат","",generalLast,generalTime,()->showChat(),false,"ГРУППА",unread.getOrDefault("general",0));
            shown++;
        }
        for(ChatItem c:myChats){
            boolean channel=c.type.equals("channel");
            if(!q.isEmpty()&&!c.name.toLowerCase().contains(q))continue;
            String sub;
            if(c.last.isEmpty())sub=c.type.equals("direct")?"Личные сообщения":(channel?"Канал · ":"Группа · ")+c.members+(channel?" подписч.":" участн.");
            else sub=(!channel&&!c.type.equals("direct")&&!c.lastSender.isEmpty()?c.lastSender+": ":"")+c.last;
            String tag=channel?"КАНАЛ":(c.type.equals("direct")?"":"ГРУППА");
            addChatRow(list,c.name,"",sub,c.time,()->openChat(c.id,c.name,c.type,c.owner),c.verified,tag,unread.getOrDefault(c.id,0));
            shown++;
        }
        if(q.isEmpty()||"избранное".contains(q)){
            addChatRow(list,"Избранное","","Сохранённые сообщения и заметки","",()->showFavorites());
            shown++;
        }
        if(shown==0){
            TextView empty=tv("Ничего не найдено",14,MUTED);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty,new LinearLayout.LayoutParams(-1,dp(120)));
        }
    }
    void addChatRow(LinearLayout list,String name,String prefix,String sub,String time,Runnable click){addChatRow(list,name,prefix,sub,time,click,false,"");}
    void addChatRow(LinearLayout list,String name,String prefix,String sub,String time,Runnable click,boolean verified){addChatRow(list,name,prefix,sub,time,click,verified,"");}
    void addChatRow(LinearLayout list,String name,String prefix,String sub,String time,Runnable click,boolean verified,String tag){addChatRow(list,name,prefix,sub,time,click,verified,tag,0);}
    void addChatRow(LinearLayout list,String name,String prefix,String sub,String time,Runnable click,boolean verified,String tag,int unreadCount){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14),dp(7),dp(14),dp(7));
        row.addView(avatar(name,dp(56)),new LinearLayout.LayoutParams(dp(56),dp(56)));
        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(dp(12),0,dp(8),0);
        LinearLayout nameLine=new LinearLayout(this);
        nameLine.setGravity(Gravity.CENTER_VERTICAL);
        TextView nameView=tv(prefix+name,16,TEXT);
        nameView.setTypeface(null,Typeface.BOLD);
        nameView.setSingleLine(true);
        nameView.setMaxWidth(dp(190));
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        setVerified(nameView,verified,16);
        nameLine.addView(nameView,new LinearLayout.LayoutParams(-2,dp(24)));
        if(tag!=null&&!tag.isEmpty()){
            TextView chip=tv(tag,9,MUTED);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(5),0,dp(5),0);
            chip.setBackground(glass(6));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(15));
            cp.leftMargin=dp(6);
            nameLine.addView(chip,cp);
        }
        TextView subView=tv(giftText(sub),14,MUTED);
        subView.setSingleLine(true);
        subView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mid.addView(nameLine,new LinearLayout.LayoutParams(-1,dp(24)));
        mid.addView(subView,new LinearLayout.LayoutParams(-1,dp(22)));
        row.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        TextView timeView=tv(time,12,unreadCount>0?Color.rgb(98,170,235):MUTED);
        LinearLayout.LayoutParams tvp=new LinearLayout.LayoutParams(-2,dp(24));
        tvp.gravity=Gravity.END;
        right.addView(timeView,tvp);
        if(unreadCount>0){
            TextView badge=tv(unreadCount>99?"99+":String.valueOf(unreadCount),12,Color.WHITE);
            badge.setGravity(Gravity.CENTER);
            badge.setTypeface(null,Typeface.BOLD);
            badge.setPadding(dp(7),0,dp(7),0);
            badge.setMinWidth(dp(22));
            badge.setBackground(bg(DEEP,11));
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,dp(22));
            bp.gravity=Gravity.END;
            right.addView(badge,bp);
        }
        row.addView(right,new LinearLayout.LayoutParams(-2,-2));
        pressable(row,.975f);
        row.setOnClickListener(x->click.run());
        list.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }
    void showNewChatMenu(){
        String[] opts={"Новая группа","Новый канал","Новое сообщество","Найти и вступить","Общий чат"};
        new android.app.AlertDialog.Builder(this).setTitle("Создать или найти").setItems(opts,(dlg,which)->{
            if(which==0)showCreateChat("group");
            else if(which==1)showCreateChat("channel");
            else if(which==2)showCreateChat("community");
            else if(which==3)showFindChats();
            else showChat();
        }).show();
    }
    void showCreateChat(String type){
        boolean channel=type.equals("channel"); boolean community=type.equals("community");
        clear(channel?"Новый канал":(community?"Новое сообщество":"Новая группа"));
        chatMode(true);
        Button back=btn("‹  Назад");
        back.setOnClickListener(x->showChats());
        content.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
        ScrollView scroll=new ScrollView(this);
        LinearLayout form=new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18),dp(10),dp(18),dp(20));
        scroll.addView(form);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView icon=tv(ico(channel?"📢":(community?"🌐":"👥")),44,TEXT);
        icon.setGravity(Gravity.CENTER);
        form.addView(icon,new LinearLayout.LayoutParams(-1,dp(80)));
        EditText nameInput=edit(channel?"Название канала":(community?"Название сообщества":"Название группы"),false);
        form.addView(nameInput,margins(0,5,0,10,56));
        EditText descInput=edit("Описание (необязательно)",false);
        form.addView(descInput,margins(0,5,0,10,56));
        final EditText[] chUser={null};
        final int[][] chState={{3}};
        if(channel){
            TextView[] stOut=new TextView[1];
            String defHint="Публичная ссылка: по @username канал можно найти в поиске. Можно задать позже.";
            chUser[0]=usernameRow(form,stOut,defHint);
            chState[0]=attachUsernameChecker(chUser[0],stOut[0],defHint,new String[]{""},true,null);
        }
        TextView hint=tv(channel?"В канале публикует только владелец, остальные читают. Найти канал можно через поиск.":(community?"Сообщество — пространство для участников. На старте доступен общий чат сообщества.":"В группе пишут все участники. Найти группу можно через поиск."),13,MUTED);
        form.addView(hint,new LinearLayout.LayoutParams(-1,-2));
        Button create=btn("Создать");
        create.setBackground(bg(DEEP,18));
        form.addView(create,margins(0,18,0,0,56));
        create.setOnClickListener(x->{
            String nm=nameInput.getText().toString().trim();
            if(nm.isEmpty()){toast("Введи название");return;}
            if(uid==null)return;
            final String chName=channel&&chUser[0]!=null?cleanUsername(chUser[0].getText()):"";
            if(!chName.isEmpty()){String chErr=usernameError(chName);if(chErr!=null){toast(chErr);return;}if(chState[0][0]==2){toast("Этот username недоступен");return;}}
            create.setEnabled(false);
            Map<String,Object> m=new HashMap<>();
            m.put("name",nm);
            m.put("description",descInput.getText().toString().trim());
            m.put("type",community?"group":type);
            if(community){m.put("isCommunity",true);m.put("communityDescription",descInput.getText().toString().trim());}
            m.put("owner",uid);
            m.put("ownerName",profileName);
            java.util.ArrayList<String> mem=new java.util.ArrayList<>();
            mem.add(uid);
            m.put("members",mem);
            m.put("createdAt",FieldValue.serverTimestamp());
            m.put("lastAt",FieldValue.serverTimestamp());
            m.put("lastText","");
            m.put("lastSender","");
            final DocumentReference newChat=db.collection("chats").document();
            if(chName.isEmpty()){
                newChat.set(m).addOnSuccessListener(r->openChat(newChat.getId(),nm,community?"group":type,uid)).addOnFailureListener(err->{create.setEnabled(true);toast("Не удалось создать: "+authMessage(err));});
                return;
            }
            m.put("username",chName);
            // claim the username and create the channel atomically, so two people can never get the same @name
            db.runTransaction(tr->{
                DocumentReference nameRef=db.collection("usernames").document(chName);
                if(tr.get(nameRef).exists())throw new FirebaseFirestoreException("taken",FirebaseFirestoreException.Code.ALREADY_EXISTS);
                Map<String,Object> claim=new HashMap<>();
                claim.put("uid",uid);claim.put("kind","channel");claim.put("chatId",newChat.getId());
                tr.set(nameRef,claim);
                tr.set(newChat,m);
                return null;
            }).addOnSuccessListener(r->openChat(newChat.getId(),nm,type,uid)).addOnFailureListener(err->{
                create.setEnabled(true);
                if(isCode(err,FirebaseFirestoreException.Code.ALREADY_EXISTS))toast("@"+chName+" уже занято — выбери другое");
                else if(isCode(err,FirebaseFirestoreException.Code.PERMISSION_DENIED))toast("Нет доступа. Опубликуй обновлённые firestore.rules и повтори.");
                else toast("Не удалось создать: "+authMessage(err));
            });
        });
    }
    void showFindChats(){
        clear("Найти чат");
        chatMode(true);
        Button back=btn("‹  Назад");
        back.setOnClickListener(x->showChats());
        content.addView(back,new LinearLayout.LayoutParams(-1,dp(52)));
        EditText search=edit("Название или @username",false);
        content.addView(search,margins(14,4,14,8,52));
        ScrollView scroll=new ScrollView(this);
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView loading=tv("Загрузка…",14,MUTED);
        loading.setGravity(Gravity.CENTER);
        list.addView(loading,new LinearLayout.LayoutParams(-1,dp(120)));
        findResults.clear();
        db.collection("chats").limit(100).get().addOnSuccessListener(snap->{
            findResults.clear();
            for(DocumentSnapshot d:snap.getDocuments())findResults.add(chatFrom(d));
            renderFindRows(list,search.getText().toString());
        }).addOnFailureListener(err->toast("Не удалось загрузить: "+authMessage(err)));
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int a,int b,int c){}
            public void onTextChanged(CharSequence cs,int a,int b,int c){renderFindRows(list,cs.toString());lookupChannelByUsername(cs.toString(),list,search);}
            public void afterTextChanged(android.text.Editable ed){}
        });
    }
    // The list above only holds the first 100 chats: resolve an exact @username through the usernames index
    Runnable pendingLookup;
    void lookupChannelByUsername(String raw,LinearLayout list,EditText search){
        if(pendingLookup!=null)ui.removeCallbacks(pendingLookup);
        final String u=cleanUsername(raw);
        if(usernameError(u)!=null)return;
        for(ChatItem c:findResults)if(c.username.equals(u))return;
        pendingLookup=()->db.collection("usernames").document(u).get().addOnSuccessListener(d->{
            String cid=d.exists()?d.getString("chatId"):null;
            if(cid==null)return;
            db.collection("chats").document(cid).get().addOnSuccessListener(cd->{
                if(!cd.exists())return;
                for(ChatItem c:findResults)if(c.id.equals(cd.getId()))return;
                findResults.add(chatFrom(cd));
                if(cleanUsername(search.getText()).equals(u))renderFindRows(list,search.getText().toString());
            });
        });
        ui.postDelayed(pendingLookup,400);
    }
    void renderFindRows(LinearLayout list,String query){
        list.removeAllViews();
        String q=query.toLowerCase().trim();
        int shown=0;
        for(ChatItem c:findResults){
            String qn=q.startsWith("@")?q.substring(1):q;
            if(!q.isEmpty()&&!c.name.toLowerCase().contains(q)&&!(!qn.isEmpty()&&c.username.contains(qn)))continue;
            boolean channel=c.type.equals("channel");
            String sub=(!c.username.isEmpty()?"@"+c.username+" · ":"")+(channel?"Канал · ":"Группа · ")+c.members+(channel?" подписч.":" участн.");
            addChatRow(list,c.name,"",sub,c.mine?"Открыть":"Вступить",()->joinAndOpen(c),c.verified);
            shown++;
        }
        if(shown==0){
            TextView empty=tv(findResults.isEmpty()?"Пока нет групп и каналов.\nСоздай первый!":"Ничего не найдено",14,MUTED);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty,new LinearLayout.LayoutParams(-1,dp(120)));
        }
    }
    void joinAndOpen(ChatItem c){
        if(c.mine||uid==null){openChat(c.id,c.name,c.type,c.owner);return;}
        db.collection("chats").document(c.id).update("members",FieldValue.arrayUnion(uid)).addOnSuccessListener(r->openChat(c.id,c.name,c.type,c.owner)).addOnFailureListener(err->toast("Не удалось вступить: "+authMessage(err)));
    }
    void showChat(){openChat("general","Общий чат","general","");}
    void openChat(String chatId,String name,String type,String owner){
        boolean general=chatId.equals("general");
        boolean canPost=!type.equals("channel")||(uid!=null&&uid.equals(owner));
        clear(name);
        markChatRead(chatId);
        if(pendingGift!=null&&type.equals("direct")&&System.currentTimeMillis()-pendingGiftAt<30000){
            final String giftText=pendingGift;
            final int giftCost=pendingGiftCost;
            pendingGift=null;
            pendingGiftCost=0;
            sendChatMessage(chatId,general,giftText,()->{setStarBalance(Math.max(0,starBalance()-giftCost));toast("Подарок отправлен");});
        }
        chatMode(true);
        // chat header: round back button, pill with avatar + title + subtitle, round menu button
        if(appHeader!=null)appHeader.setVisibility(android.view.View.GONE);
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(10),dp(8),dp(10),dp(6));
        ImageView back=barButton(R.drawable.ic_bar_back);
        back.setOnClickListener(x->showChats());
        LinearLayout pill=new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(6),dp(6),dp(16),dp(6));
        pill.setBackground(barBg(28));
        TextView av=avatar(name,dp(44));
        LinearLayout names=new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.setPadding(dp(12),0,0,0);
        TextView nm=tv(name,19,TEXT);
        nm.setTypeface(null,Typeface.BOLD);
        nm.setSingleLine(true);
        nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView sub=tv(general?"Общий чат":type.equals("channel")?"Канал":type.equals("direct")?"Личные сообщения":"Группа",13,MUTED);
        sub.setSingleLine(true);
        chatSub=sub;
        chatSubBase=sub.getText().toString();
        applyNetStatus();
        setVerified(nm,Boolean.TRUE.equals(verifiedCache.get("c:"+chatId)),18);
        if(!general&&!verifiedCache.containsKey("c:"+chatId))db.collection("chats").document(chatId).get().addOnSuccessListener(cd->{boolean vv=Boolean.TRUE.equals(cd.getBoolean("verified"));verifiedCache.put("c:"+chatId,vv);setVerified(nm,vv,18);});
        names.addView(nm);
        names.addView(sub);
        pill.addView(av,new LinearLayout.LayoutParams(dp(44),dp(44)));
        pill.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        ImageView more=barButton(R.drawable.ic_bar_more);
        Runnable openInfo=()->showChatProfile(chatId,name,type,owner);
        more.setOnClickListener(x->openInfo.run());
        pill.setOnClickListener(x->openInfo.run());
        top.addView(back,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout.LayoutParams pillLp=new LinearLayout.LayoutParams(0,dp(56),1);
        pillLp.setMargins(dp(8),0,dp(8),0);
        top.addView(pill,pillLp);
        top.addView(more,new LinearLayout.LayoutParams(dp(52),dp(52)));
        content.addView(top,new LinearLayout.LayoutParams(-1,-2));
        final LinearLayout pinBar=new LinearLayout(this);
        pinBar.setGravity(Gravity.CENTER_VERTICAL);
        pinBar.setPadding(dp(14),dp(6),dp(6),dp(6));
        pinBar.setBackground(glass(14));
        pinBar.setVisibility(android.view.View.GONE);
        android.view.View pinLine=new android.view.View(this);
        pinLine.setBackgroundColor(ACCENT);
        pinBar.addView(pinLine,new LinearLayout.LayoutParams(dp(3),dp(34)));
        LinearLayout pinTexts=new LinearLayout(this);
        pinTexts.setOrientation(LinearLayout.VERTICAL);
        pinTexts.setPadding(dp(10),0,0,0);
        TextView pinTitle=tv("Закреплённое сообщение",12,Color.rgb(98,170,235));
        pinTitle.setTypeface(null,Typeface.BOLD);
        TextView pinText=tv("",14,TEXT);
        pinText.setSingleLine(true);
        pinText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pinTexts.addView(pinTitle,new LinearLayout.LayoutParams(-1,dp(18)));
        pinTexts.addView(pinText,new LinearLayout.LayoutParams(-1,dp(20)));
        pinBar.addView(pinTexts,new LinearLayout.LayoutParams(0,-2,1));
        TextView pinClose=tv(ico("✕"),16,MUTED);
        pinClose.setGravity(Gravity.CENTER);
        pinBar.addView(pinClose,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout.LayoutParams pinLp=new LinearLayout.LayoutParams(-1,-2);
        pinLp.setMargins(dp(10),0,dp(10),dp(4));
        content.addView(pinBar,pinLp);
        if(!general){
            listener2=db.collection("chats").document(chatId).addSnapshotListener((cs,cerr)->{
                if(cerr!=null||cs==null||!cs.exists())return;
                String pt=cs.getString("pinnedMessageText");
                String pid=cs.getString("pinnedMessageId");
                if(pid==null||pid.isEmpty()||pt==null){pinBar.setVisibility(android.view.View.GONE);return;}
                pinText.setText(pt);
                pinBar.setVisibility(android.view.View.VISIBLE);
                pinBar.setOnClickListener(x->new android.app.AlertDialog.Builder(this).setTitle("Закреплённое сообщение").setMessage(pt).setPositiveButton("Закрыть",null).show());
            });
            pinClose.setOnClickListener(x->{
                if(uid!=null&&uid.equals(owner))db.collection("chats").document(chatId).update("pinnedMessageId",FieldValue.delete(),"pinnedMessageText",FieldValue.delete());
                else pinBar.setVisibility(android.view.View.GONE);
            });
        }
        ScrollView scroll=new ScrollView(this);
        scroll.setBackground(chatBackground());
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12),dp(8),dp(12),dp(8));
        scroll.addView(list);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        java.util.HashMap<String,android.view.View> bubbles=new java.util.HashMap<>();
        final String[] replyTargetId={null}, replyTargetText={null};
        final EditText[] composerInput={null};
        boolean[] loaded={false};
        // only the latest 100 messages are listened to, and only changed messages are drawn
        final int PAGE=40;final int[] winLimit={PAGE};final int[] lastSize={0};final boolean[] olderLoad={false},scrollReady={false};final int[] prevH={0};
        com.google.firebase.firestore.EventListener<QuerySnapshot> msgListener=(snap,err)->{
            if(err!=null||snap==null)return;
            boolean firstLoad=!loaded[0];
            boolean added=false,needRead=false;
            for(DocumentChange ch:snap.getDocumentChanges()){
                DocumentSnapshot d=ch.getDocument();
                if(ch.getType()==DocumentChange.Type.REMOVED){
                    android.view.View old=bubbles.remove(d.getId());
                    if(old!=null)list.removeView(old);
                    continue;
                }
                if(bubbles.containsKey(d.getId()))continue;
                String text=d.getString("text");
                String sender=d.getString("sender");
                if(text==null)continue;
                boolean mine=uid!=null&&uid.equals(sender);
                String who=(!type.equals("channel")&&!mine)?d.getString("senderName"):null;
                String replyText=d.getString("replyText");
                TextView bubble=addBubble(list,(replyText==null||replyText.isEmpty()?"":"↪ "+replyText+"\n────────\n")+text,mine,who);
                Object reactionsObj=d.get("reactions");
                if(reactionsObj instanceof Map && !((Map<?,?>)reactionsObj).isEmpty()){
                    StringBuilder reactionLabel=new StringBuilder();
                    for(Object rv:((Map<?,?>)reactionsObj).values()) if(rv instanceof String) reactionLabel.append(rv).append(' ');
                    if(reactionLabel.length()>0) bubble.setText(bubble.getText()+"\n"+reactionLabel.toString().trim());
                }
                if(!mine){Object rbo=d.get("readBy");boolean seen=rbo instanceof java.util.List&&uid!=null&&((java.util.List<?>)rbo).contains(uid);if(!seen&&uid!=null)messagesOf(chatId).document(d.getId()).update("readBy",FieldValue.arrayUnion(uid));needRead=true;}
                final String msgId=d.getId();final String msgText=text;
                bubble.setOnLongClickListener(v->{java.util.ArrayList<String> actions=new java.util.ArrayList<>();actions.add("Ответить");actions.add("Реакция");actions.add("Копировать");actions.add("⭐ В избранное");actions.add("Закрепить");if(mine){actions.add("Изменить");actions.add("Удалить");}new android.app.AlertDialog.Builder(this).setTitle("Сообщение").setItems(actions.toArray(new String[0]),(dlg,which)->{String a=actions.get(which);if(a.equals("Копировать")){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("Echo",msgText));toast("Скопировано");}else if(a.equals("⭐ В избранное")){if(uid==null){toast("Войди в аккаунт");return;}Map<String,Object> fav=new HashMap<>();fav.put("text",msgText);fav.put("chatId",chatId);fav.put("chatName",name);fav.put("messageId",msgId);fav.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(uid).collection("favorites").document(chatId+"_"+msgId).set(fav).addOnSuccessListener(z->toast("Добавлено в Избранное ⭐")).addOnFailureListener(e->toast("Не удалось сохранить: "+authMessage(e)));}else if(a.equals("Ответить")){replyTargetId[0]=msgId;replyTargetText[0]=msgText;EditText ci=composerInput[0];if(ci!=null){ci.setHint("Ответ на: "+(msgText.length()>24?msgText.substring(0,24)+"…":msgText));ci.requestFocus();((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(ci,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);}}else if(a.equals("Реакция")){String[] emojis={"👍","❤️","😂","😮","😢","🔥"};new android.app.AlertDialog.Builder(this).setTitle("Выбери реакцию").setItems(emojis,(ed,ei)->messagesOf(chatId).document(msgId).update("reactions."+uid,emojis[ei]).addOnSuccessListener(x->{toast("Реакция добавлена");openChat(chatId,name,type,owner);}).addOnFailureListener(e->toast("Не удалось поставить реакцию: "+authMessage(e)))).show();}else if(a.equals("Закрепить")){db.collection("chats").document(chatId).update("pinnedMessageId",msgId,"pinnedMessageText",msgText).addOnSuccessListener(x->toast("Сообщение закреплено")).addOnFailureListener(e->toast("Не удалось закрепить: "+authMessage(e)));}else if(a.equals("Изменить")){EditText editText=edit("Текст сообщения",false);editText.setText(msgText);new android.app.AlertDialog.Builder(this).setTitle("Изменить сообщение").setView(editText).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(ed,ei)->{String updated=editText.getText().toString().trim();if(updated.isEmpty()){toast("Сообщение не может быть пустым");return;}messagesOf(chatId).document(msgId).update("text",updated).addOnSuccessListener(x->{toast("Сообщение изменено");openChat(chatId,name,type,owner);}).addOnFailureListener(e->toast("Не удалось изменить: "+authMessage(e)));}).show();}else if(a.equals("Удалить")){new android.app.AlertDialog.Builder(this).setMessage("Удалить это сообщение?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(dd,ww)->messagesOf(chatId).document(msgId).delete().addOnFailureListener(e->toast(authMessage(e)))).show();}}).show();return true;});
                if(!mine&&sender!=null){
                    String senderName=d.getString("senderName");
                    bubble.setOnClickListener(x->showUserProfile(sender,senderName!=null?senderName:"Пользователь",()->openChat(chatId,name,type,owner)));
                }
                bindMedia(bubble,d);
                int pos=Math.min(ch.getNewIndex(),list.getChildCount()-1);
                if(pos>=0&&pos<list.getChildCount()-1){
                    list.removeView(bubble);
                    list.addView(bubble,pos,bubble.getLayoutParams());
                }
                bubbles.put(d.getId(),bubble);
                if(!firstLoad&&!olderLoad[0])animateIn(bubble,mine);
                added=true;
            }
            lastSize[0]=snap.size();
            if(needRead)markChatRead(chatId);
            loaded[0]=true;
            if(olderLoad[0]){olderLoad[0]=false;final int ph=prevH[0];list.post(()->scroll.scrollTo(0,Math.max(0,list.getHeight()-ph)));return;}
            if(!added&&!firstLoad)return;
            scroll.post(()->{
                if(firstLoad){scroll.fullScroll(ScrollView.FOCUS_DOWN);scroll.postDelayed(()->scrollReady[0]=true,500);}
                else scroll.smoothScrollTo(0,list.getHeight());
            });
        };
        final Runnable[] register=new Runnable[1];
        register[0]=()->{if(listener!=null)listener.remove();listener=messagesOf(chatId).orderBy("createdAt",Query.Direction.ASCENDING).limitToLast(winLimit[0]).addSnapshotListener(msgListener);};
        register[0].run();
        // infinite scroll upwards: when the user reaches the top, widen the window by one page
        scroll.getViewTreeObserver().addOnScrollChangedListener(()->{
            if(scroll.getScrollY()==0&&scrollReady[0]&&loaded[0]&&!olderLoad[0]&&lastSize[0]>=winLimit[0]&&winLimit[0]<2000){
                olderLoad[0]=true;prevH[0]=list.getHeight();winLimit[0]+=PAGE;toast("Загружаю более ранние сообщения…");register[0].run();
            }
        });
        if(!canPost){
            TextView readOnly=tv("Писать в канал может только владелец",13,MUTED);
            readOnly.setGravity(Gravity.CENTER);
            content.addView(readOnly,new LinearLayout.LayoutParams(-1,dp(56)));
            return;
        }
        // Dock bar: pill with emoji, input, attach and a round action button (mic <-> send)
        LinearLayout composer=new LinearLayout(this);
        composer.setPadding(dp(10),dp(6),dp(10),dp(10));
        composer.setGravity(Gravity.BOTTOM);
        LinearLayout dock=new LinearLayout(this);
        dock.setGravity(Gravity.BOTTOM);
        dock.setMinimumHeight(dp(56));
        dock.setBackground(glassFull(28));
        ImageView emoji=dockIcon(R.drawable.ic_dock_emoji);
        EditText input=new EditText(this);
        composerInput[0]=input;
        input.setHint("Сообщение");
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(17);
        input.setBackground(null);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHorizontallyScrolling(false);
        input.setMaxLines(5);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setMinHeight(dp(56));
        input.setPadding(dp(4),dp(14),dp(4),dp(14));
        ImageView attach=dockIcon(R.drawable.ic_dock_attach);
        ImageView action=new ImageView(this);
        action.setImageResource(R.drawable.ic_dock_mic);
        action.setColorFilter(Color.WHITE);
        action.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        action.setPadding(dp(11),dp(11),dp(11),dp(11));
        action.setBackground(glassAccent(BLUE,22));
        int[] lastLines={1};
        input.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence cs,int a,int b,int c){}
            public void onTextChanged(CharSequence cs,int a,int b,int c){
                action.setImageResource(cs.toString().trim().isEmpty()?R.drawable.ic_dock_mic:R.drawable.ic_dock_send);
            }
            public void afterTextChanged(android.text.Editable ed){
                input.post(()->{
                    int lines=input.getLineCount();
                    if(lines!=lastLines[0]){
                        lastLines[0]=lines;
                        scroll.post(()->scroll.fullScroll(ScrollView.FOCUS_DOWN));
                    }
                });
            }
        });
        LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(44),dp(44));
        iconLp.setMargins(dp(6),dp(6),0,dp(6));
        LinearLayout.LayoutParams attachLp=new LinearLayout.LayoutParams(dp(44),dp(44));
        attachLp.setMargins(0,dp(6),0,dp(6));
        LinearLayout.LayoutParams actionLp=new LinearLayout.LayoutParams(dp(44),dp(44));
        actionLp.setMargins(dp(2),dp(6),dp(6),dp(6));
        dock.addView(emoji,iconLp);
        dock.addView(input,new LinearLayout.LayoutParams(0,-2,1));
        dock.addView(attach,attachLp);
        dock.addView(action,actionLp);
        composer.addView(dock,new LinearLayout.LayoutParams(-1,-2));
        emoji.setOnClickListener(x->{
            input.requestFocus();
            android.view.inputmethod.InputMethodManager imm=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(imm!=null)imm.showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
        });
        attach.setOnClickListener(x->new android.app.AlertDialog.Builder(this).setTitle("Действия").setItems(new CharSequence[]{ico("🕒  Отложить сообщение"),ico("🕒  Отложенные сообщения"),ico("✨  Echo Assist Beta"),ico("🤖  Echo Bots"),ico("📎  Фото или файл"),ico("🔍  Поиск по чату")},(d,w)->{if(w==0)scheduleMessageDialog(chatId,name,type,owner,general,input,replyTargetId[0],replyTargetText[0]);else if(w==1)showScheduledMessages();else if(w==2)showEchoAssist();else if(w==3)showEchoBots();else if(w==4)pickMedia(chatId,general,name,input.getText().toString().trim());else searchInChat(chatId);}).show());
        action.setOnClickListener(x->{
            String text=input.getText().toString().trim();
            if(text.isEmpty()){toast("Голосовые сообщения скоро появятся");return;}
            if(uid==null)return;
            action.animate().scaleX(.8f).scaleY(.8f).setDuration(90).withEndAction(()->action.animate().scaleX(1f).scaleY(1f).setDuration(150).start()).start();
            Map<String,Object> m=new HashMap<>();
            m.put("text",text);
            m.put("sender",uid);
            m.put("senderName",profileName);
            m.put("createdAt",FieldValue.serverTimestamp());
            m.put("readBy",java.util.Arrays.asList(uid));
            if(replyTargetId[0]!=null&&replyTargetText[0]!=null){m.put("replyTo",replyTargetId[0]);m.put("replyText",replyTargetText[0]);}
            messagesOf(chatId).add(m).addOnSuccessListener(r->{
                input.setText("");input.setHint("Сообщение");replyTargetId[0]=null;replyTargetText[0]=null;
                if(!general){
                    Map<String,Object> up=new HashMap<>();
                    up.put("lastText",text);
                    up.put("lastSender",profileName);
                    up.put("lastAt",FieldValue.serverTimestamp());
                    db.collection("chats").document(chatId).update(up);
                }
            });
        });
        content.addView(composer);
    }

    // ---- In-chat search (client-side over the latest 500 messages; Firestore has no full-text search) ----
    void searchInChat(String chatId){
        EditText q=edit("Что искать?",false);
        new android.app.AlertDialog.Builder(this).setTitle("Поиск по чату").setView(q).setNegativeButton("Отмена",null)
          .setPositiveButton("Искать",(d,w)->{
            final String needle=q.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
            if(needle.length()<2){toast("Введи минимум 2 символа");return;}
            messagesOf(chatId).orderBy("createdAt",Query.Direction.DESCENDING).limit(500).get().addOnSuccessListener(snap->{
                java.util.ArrayList<String> rows=new java.util.ArrayList<>(),full=new java.util.ArrayList<>();
                java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("d MMM HH:mm",new java.util.Locale("ru"));
                for(DocumentSnapshot m:snap.getDocuments()){
                    String text=m.getString("text");if(text==null)continue;
                    if(!text.toLowerCase(java.util.Locale.ROOT).contains(needle))continue;
                    java.util.Date at=m.getDate("createdAt");String who=m.getString("senderName");
                    String head=(at==null?"":f.format(at))+(who==null?"":" · "+who);
                    rows.add(head+"\n"+(text.length()>80?text.substring(0,80)+"…":text));full.add(head+"\n\n"+text);
                    if(rows.size()>=50)break;
                }
                if(rows.isEmpty()){toast("Ничего не найдено в последних 500 сообщениях");return;}
                new android.app.AlertDialog.Builder(this).setTitle("Найдено: "+rows.size()).setItems(rows.toArray(new String[0]),(dd,i)->
                    new android.app.AlertDialog.Builder(this).setMessage(full.get(i)).setPositiveButton("Закрыть",null).show()).setNegativeButton("Закрыть",null).show();
            }).addOnFailureListener(e->toast("Поиск не удался: "+authMessage(e)));
          }).show();
    }

    // ---- Media upload via external S3-compatible storage (Cloudflare R2) with presigned URLs from Cloud Function `getUploadUrl` ----
    static final int REQ_MEDIA=403;static final long MAX_MEDIA=25L*1024*1024;
    String mediaChatId,mediaChatName,mediaCaption;boolean mediaGeneral;
    final android.util.LruCache<String,android.graphics.Bitmap> imageCache=new android.util.LruCache<String,android.graphics.Bitmap>(24*1024*1024){@Override protected int sizeOf(String k,android.graphics.Bitmap b){return b.getByteCount();}};
    void pickMedia(String chatId,boolean general,String chatName,String caption){
        if(uid==null){toast("Войди в аккаунт");return;}
        mediaChatId=chatId;mediaGeneral=general;mediaChatName=chatName;mediaCaption=caption;
        Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        startActivityForResult(Intent.createChooser(i,"Выбери фото или файл"),REQ_MEDIA);
    }
    void uploadAndSend(Uri uri){
        final String chatId=mediaChatId;final boolean general=mediaGeneral;final String caption=mediaCaption==null?"":mediaCaption;
        if(chatId==null||uid==null)return;
        String n="file";long sz=-1;
        try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)){
            if(c!=null&&c.moveToFirst()){int ni=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME),si=c.getColumnIndex(android.provider.OpenableColumns.SIZE);if(ni>=0)n=c.getString(ni);if(si>=0&&!c.isNull(si))sz=c.getLong(si);}
        }catch(Exception ignored){}
        String mt=getContentResolver().getType(uri);if(mt==null)mt="application/octet-stream";
        if(sz<=0){toast("Не удалось определить размер файла");return;}
        if(sz>MAX_MEDIA){toast("Файл больше 25 МБ");return;}
        final String name=n,mime=mt;final long size=sz;
        toast("Загрузка: "+name);
        Map<String,Object> data=new HashMap<>();data.put("name",name);data.put("contentType",mime);data.put("size",size);data.put("chatId",chatId);data.put("general",general);
        com.google.firebase.functions.FirebaseFunctions.getInstance().getHttpsCallable("getUploadUrl").call(data).addOnSuccessListener(res->{
            Object ro=res.getData();if(!(ro instanceof Map)){toast("Сервер вернул неверный ответ");return;}
            Map<?,?> r=(Map<?,?>)ro;final String upUrl=String.valueOf(r.get("uploadUrl")),pubUrl=String.valueOf(r.get("publicUrl"));
            new Thread(()->{
                try{
                    java.net.HttpURLConnection con=(java.net.HttpURLConnection)new java.net.URL(upUrl).openConnection();
                    con.setRequestMethod("PUT");con.setDoOutput(true);con.setRequestProperty("Content-Type",mime);con.setFixedLengthStreamingMode(size);con.setConnectTimeout(15000);con.setReadTimeout(60000);
                    try(java.io.InputStream in=getContentResolver().openInputStream(uri);java.io.OutputStream out=con.getOutputStream()){byte[] buf=new byte[16384];int k;while((k=in.read(buf))>0)out.write(buf,0,k);}
                    int code=con.getResponseCode();con.disconnect();
                    if(code<200||code>=300){runOnUiThread(()->toast("Хранилище отклонило файл ("+code+")"));return;}
                    runOnUiThread(()->sendMediaMessage(chatId,general,caption,name,mime,size,pubUrl));
                }catch(Exception e){runOnUiThread(()->toast("Не удалось загрузить: "+e.getMessage()));}
            }).start();
        }).addOnFailureListener(e->toast("Не удалось получить ссылку загрузки: "+authMessage(e)));
    }
    void sendMediaMessage(String chatId,boolean general,String caption,String name,String mime,long size,String url){
        boolean image=mime.startsWith("image/");
        String text=caption.isEmpty()?(image?"Фото: ":"Файл: ")+name:caption;
        Map<String,Object> m=new HashMap<>();
        m.put("text",text);m.put("sender",uid);m.put("senderName",profileName);m.put("createdAt",FieldValue.serverTimestamp());m.put("readBy",java.util.Arrays.asList(uid));
        m.put("mediaUrl",url);m.put("mediaType",image?"image":"file");m.put("mime",mime);m.put("fileName",name);m.put("fileSize",size);
        messagesOf(chatId).add(m).addOnSuccessListener(r->{
            toast("Отправлено");
            if(!general){Map<String,Object> up=new HashMap<>();up.put("lastText",(image?"Фото":"Файл")+": "+name);up.put("lastSender",profileName);up.put("lastAt",FieldValue.serverTimestamp());db.collection("chats").document(chatId).update(up);}
        }).addOnFailureListener(e->toast("Не отправлено: "+authMessage(e)));
    }
    // Draw an image attachment above the bubble text; any attachment opens in the system viewer on tap.
    void bindMedia(TextView bubble,DocumentSnapshot d){
        final String url=d.getString("mediaUrl");if(url==null||url.isEmpty())return;
        final boolean image="image".equals(d.getString("mediaType"));
        bubble.setOnClickListener(x->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("Нет приложения для открытия файла");}});
        if(!image)return;
        android.graphics.Bitmap cached=imageCache.get(url);
        if(cached!=null){setBubbleImage(bubble,cached);return;}
        new Thread(()->{
            try{
                java.net.HttpURLConnection con=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();con.setConnectTimeout(15000);con.setReadTimeout(30000);
                java.io.ByteArrayOutputStream bo=new java.io.ByteArrayOutputStream();
                try(java.io.InputStream in=con.getInputStream()){byte[] buf=new byte[16384];int k;long tot=0;while((k=in.read(buf))>0){tot+=k;if(tot>MAX_MEDIA)return;bo.write(buf,0,k);}}
                byte[] raw=bo.toByteArray();
                android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();o.inJustDecodeBounds=true;android.graphics.BitmapFactory.decodeByteArray(raw,0,raw.length,o);
                int target=dp(260),s=1;while(o.outWidth/(s*2)>=target)s*=2;
                o=new android.graphics.BitmapFactory.Options();o.inSampleSize=s;
                final android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeByteArray(raw,0,raw.length,o);
                if(bm!=null){imageCache.put(url,bm);runOnUiThread(()->setBubbleImage(bubble,bm));}
            }catch(Exception ignored){}
        }).start();
    }
    void setBubbleImage(TextView bubble,android.graphics.Bitmap bm){
        int w=Math.min(dp(260),bm.getWidth()),h=Math.max(1,bm.getHeight()*w/Math.max(1,bm.getWidth()));
        android.graphics.drawable.BitmapDrawable dr=new android.graphics.drawable.BitmapDrawable(getResources(),bm);dr.setBounds(0,0,w,h);
        bubble.setCompoundDrawables(null,dr,null,null);bubble.setCompoundDrawablePadding(dp(6));
    }
    void scheduleMessageDialog(String chatId,String chatName,String type,String owner,boolean general,EditText input,String replyId,String replyText){
        if(uid==null){toast("Войди в аккаунт");return;}
        String message=input.getText().toString().trim();
        if(message.isEmpty()){toast("Сначала напиши сообщение");input.requestFocus();return;}
        java.util.Calendar now=java.util.Calendar.getInstance();
        new android.app.DatePickerDialog(this,(view,year,month,day)->{
            java.util.Calendar selected=java.util.Calendar.getInstance(); selected.set(year,month,day);
            new android.app.TimePickerDialog(this,(tv,hour,minute)->{
                selected.set(java.util.Calendar.HOUR_OF_DAY,hour); selected.set(java.util.Calendar.MINUTE,minute); selected.set(java.util.Calendar.SECOND,0); selected.set(java.util.Calendar.MILLISECOND,0);
                if(selected.getTimeInMillis()<System.currentTimeMillis()+60000){toast("Выбери время хотя бы на минуту позже");return;}
                Map<String,Object> scheduled=new HashMap<>(); scheduled.put("text",message); scheduled.put("sender",uid); scheduled.put("senderName",profileName); scheduled.put("chatId",chatId); scheduled.put("chatName",chatName); scheduled.put("chatType",type); scheduled.put("owner",owner==null?"":owner); scheduled.put("general",general); scheduled.put("status","pending"); scheduled.put("dueAt",new com.google.firebase.Timestamp(selected.getTime())); scheduled.put("createdAt",FieldValue.serverTimestamp());
                if(replyId!=null&&replyText!=null){scheduled.put("replyTo",replyId);scheduled.put("replyText",replyText);}
                db.collection("scheduledMessages").add(scheduled).addOnSuccessListener(ref->{input.setText("");toast("Сообщение запланировано на "+new java.text.SimpleDateFormat("dd.MM HH:mm",java.util.Locale.getDefault()).format(selected.getTime()));}).addOnFailureListener(e->toast("Не удалось запланировать: "+authMessage(e)));
            },now.get(java.util.Calendar.HOUR_OF_DAY),now.get(java.util.Calendar.MINUTE),true).show();
        },now.get(java.util.Calendar.YEAR),now.get(java.util.Calendar.MONTH),now.get(java.util.Calendar.DAY_OF_MONTH)).show();
    }

    void showScheduledMessages(){
        clear("Отложенные сообщения"); addPageBack(()->showChats());
        if(uid==null){simpleInfo("Отложенные сообщения","Войди в аккаунт.");return;}
        TextView info=tv("Сообщения будут отправлены автоматически, когда серверная функция включена.",13,MUTED);content.addView(info,margins(14,4,14,12,-2));
        db.collection("scheduledMessages").whereEqualTo("sender",uid).whereEqualTo("status","pending").get().addOnSuccessListener(snap->{if(snap.isEmpty()){TextView empty=tv("Нет запланированных сообщений",14,MUTED);empty.setGravity(Gravity.CENTER);content.addView(empty,margins(12,24,12,0,60));return;}for(DocumentSnapshot d:snap.getDocuments()){String text=d.getString("text");String chat=d.getString("chatName");com.google.firebase.Timestamp due=d.getTimestamp("dueAt");String when=due==null?"Время не указано":new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",java.util.Locale.getDefault()).format(due.toDate());LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(glass(16));card.addView(tv(chat==null?"Чат":chat,15,TEXT));card.addView(tv(text==null?"":text,14,TEXT));card.addView(tv(ico("🕒 "+when),12,MUTED));Button cancel=btn("Отменить отправку");cancel.setOnClickListener(v->d.getReference().update("status","cancelled").addOnSuccessListener(x->{toast("Отложенное сообщение отменено");showScheduledMessages();}).addOnFailureListener(e->toast(authMessage(e))));card.addView(cancel);content.addView(card,margins(12,5,12,5,-2));}}).addOnFailureListener(e->toast("Не удалось загрузить сообщения: "+authMessage(e)));
    }

    // ===== Profile screens: group / channel / general chat and other users =====
    TextView[] addProfileHero(LinearLayout page,String name,String subtitle){
        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(14),dp(18),dp(14),dp(18));
        hero.setBackground(glass(24));
        TextView av=avatar(name,dp(112));
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(112),dp(112));
        avp.setMargins(0,0,0,dp(12));
        hero.addView(av,avp);
        TextView nm=tv(name,24,TEXT);
        nm.setTypeface(null,Typeface.BOLD);
        nm.setGravity(Gravity.CENTER);
        hero.addView(nm,new LinearLayout.LayoutParams(-2,-2));
        TextView sub=tv(subtitle,14,MUTED);
        sub.setGravity(Gravity.CENTER);
        hero.addView(sub,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);
        hp.setMargins(0,dp(4),0,dp(12));
        page.addView(hero,hp);
        return new TextView[]{nm,sub};
    }
    LinearLayout addCard(LinearLayout page){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(6),dp(14),dp(6));
        card.setBackground(glass(20));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.setMargins(0,0,0,dp(12));
        page.addView(card,cp);
        return card;
    }
    LinearLayout profilePage(Runnable back){
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14),dp(10),dp(14),dp(18));
        scroll.addView(page);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        Button b=btn("‹  Назад");
        b.setOnClickListener(x->back.run());
        page.addView(b,margins(0,0,0,10,48));
        return page;
    }
    void addPersonRow(LinearLayout parent,String personName,String tag,boolean verified,Runnable click){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4),dp(8),dp(4),dp(8));
        row.addView(avatar(personName,dp(42)),new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout col=new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12),0,0,0);
        TextView n=tv(personName,16,TEXT);
        n.setTypeface(null,Typeface.BOLD);
        setVerified(n,verified,15);
        col.addView(n);
        if(tag!=null&&!tag.isEmpty())col.addView(tv(tag,12,MUTED));
        row.addView(col,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(tv(ico("›"),24,MUTED));
        row.setOnClickListener(v->click.run());
        parent.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }
    String userLabel(DocumentSnapshot u,String fallback){
        if(u!=null&&u.exists()){
            String n=u.getString("name"),un=u.getString("username");
            if(n!=null&&!n.isEmpty())return n;
            if(un!=null&&!un.isEmpty())return un;
        }
        return fallback;
    }
    // a private chat opens the other person's profile, not a "group" card
    void openDirectInfo(String chatId,String name,String type,String owner){
        db.collection("chats").document(chatId).get().addOnSuccessListener(d->{
            java.util.List<?> raw=(java.util.List<?>)d.get("members");
            String other=null;
            if(raw!=null)for(Object o:raw)if(o instanceof String&&!o.equals(uid))other=(String)o;
            if(other==null){toast("Не удалось открыть профиль собеседника");return;}
            showUserProfile(other,name,()->openChat(chatId,name,type,owner));
        }).addOnFailureListener(e->toast("Не удалось загрузить профиль: "+authMessage(e)));
    }
    void showChatProfile(String chatId,String name,String type,String owner){
        if("direct".equals(type)){openDirectInfo(chatId,name,type,owner);return;}
        boolean general=chatId.equals("general");
        boolean channel=type.equals("channel");
        String kind=general?"Общий чат":channel?"Канал":"Группа";
        clear(kind);
        LinearLayout page=profilePage(()->openChat(chatId,name,type,owner));
        TextView[] hero=addProfileHero(page,name,kind);
        LinearLayout actions=new LinearLayout(this);
        Button open=btn("Открыть чат");
        open.setBackground(glassAccent(BLUE,18));
        open.setOnClickListener(x->openChat(chatId,name,type,owner));
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(48),1));
        boolean isOwner=uid!=null&&uid.equals(owner);
        if(!general){
            Button leave=btn(isOwner?"Удалить":"Покинуть");
            leave.setTextColor(Color.rgb(255,107,107));
            leave.setOnClickListener(x->confirmLeave(chatId,name,isOwner));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);
            lp.setMargins(dp(8),0,0,0);
            actions.addView(leave,lp);
        }
        if(!general&&isOwner){
            Button editBtn=btn("Изменить");
            editBtn.setOnClickListener(x->showEditChat(chatId,name,type,owner));
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(48),1);
            ep.setMargins(dp(8),0,0,0);
            actions.addView(editBtn,ep);
        }
        page.addView(actions,margins(0,0,0,12,48));
        LinearLayout details=addCard(page);
        if(general){
            addProfileDetail(details,"ℹ","Описание","Общая комната для всех пользователей Echo",()->{});
            return;
        }
        addProfileDetail(details,"ℹ","Описание","Загрузка…",()->{});
        TextView descView=(TextView)((LinearLayout)((LinearLayout)details.getChildAt(0)).getChildAt(1)).getChildAt(1);
        db.collection("chats").document(chatId).get().addOnSuccessListener(d->{
            String desc=d.getString("description");
            descView.setText(desc==null||desc.isEmpty()?"Без описания":desc);
            String chatUser=d.getString("username");
            if(chatUser!=null&&!chatUser.isEmpty())addProfileDetail(details,"@","Ссылка · нажми, чтобы скопировать","@"+chatUser,()->copyText("username","@"+chatUser));
            boolean chatVerified=Boolean.TRUE.equals(d.getBoolean("verified"));
            verifiedCache.put("c:"+chatId,chatVerified);
            setVerified(hero[0],chatVerified,22);
            java.util.List<?> raw=(java.util.List<?>)d.get("members");
            java.util.ArrayList<String> ids=new java.util.ArrayList<>();
            if(raw!=null)for(Object o:raw)if(o instanceof String)ids.add((String)o);
            hero[1].setText(kind+" · "+ids.size()+" "+(channel?plural(ids.size(),"подписчик","подписчика","подписчиков"):plural(ids.size(),"участник","участника","участников")));
            if(channel&&!isOwner)return;
            LinearLayout membersCard=addCard(page);
            TextView head=tv((channel?"Подписчики":"Участники")+" ("+ids.size()+")",13,MUTED);
            membersCard.addView(head,new LinearLayout.LayoutParams(-1,dp(36)));
            java.util.HashMap<String,String> names=new java.util.HashMap<>();
            java.util.HashSet<String> verifiedIds=new java.util.HashSet<>();
            java.util.ArrayList<String> shown=new java.util.ArrayList<>(ids.subList(0,Math.min(40,ids.size())));
            Runnable render=()->{
                for(String id:shown){
                    String label=names.containsKey(id)?names.get(id):"Пользователь "+id.substring(0,Math.min(5,id.length()));
                    String tag=id.equals(owner)?"Владелец":id.equals(uid)?"Это ты":"";
                    addPersonRow(membersCard,label,tag,verifiedIds.contains(id),()->showUserProfile(id,label,()->showChatProfile(chatId,name,type,owner)));
                }
            };
            if(shown.isEmpty()){render.run();return;}
            int chunks=(shown.size()+9)/10;
            int[] left={chunks};
            for(int i=0;i<shown.size();i+=10){
                java.util.List<String> part=shown.subList(i,Math.min(i+10,shown.size()));
                db.collection("users").whereIn(FieldPath.documentId(),new java.util.ArrayList<>(part)).get().addOnCompleteListener(t->{
                    if(t.isSuccessful()&&t.getResult()!=null)for(DocumentSnapshot u:t.getResult().getDocuments()){names.put(u.getId(),userLabel(u,"Пользователь"));if(Boolean.TRUE.equals(u.getBoolean("verified")))verifiedIds.add(u.getId());}
                    if(--left[0]==0)render.run();
                });
            }
        }).addOnFailureListener(e->descView.setText("Не удалось загрузить: "+authMessage(e)));
    }
    void confirmLeave(String chatId,String name,boolean isOwner){
        new android.app.AlertDialog.Builder(this)
            .setTitle((isOwner?"Удалить «":"Покинуть «")+name+"»?")
            .setMessage(isOwner?"Чат будет удалён для всех участников.":"Ты перестанешь получать сообщения этого чата.")
            .setNegativeButton("Отмена",null)
            .setPositiveButton(isOwner?"Удалить":"Покинуть",(dlg,w)->{
                if(isOwner)db.collection("chats").document(chatId).get().addOnSuccessListener(cd->{
                    String un=cd.getString("username");
                    WriteBatch wb=db.batch();
                    wb.delete(db.collection("chats").document(chatId));
                    if(un!=null&&!un.isEmpty())wb.delete(db.collection("usernames").document(un)); // free the @name for others
                    wb.commit().addOnSuccessListener(r->showChats()).addOnFailureListener(e->toast("Не удалось удалить: "+authMessage(e)));
                });
                else db.collection("chats").document(chatId).update("members",FieldValue.arrayRemove(uid)).addOnSuccessListener(r->showChats());
            }).show();
    }
    void showUserProfile(String userId,String fallbackName,Runnable back){
        if(userId!=null&&userId.equals(uid)){showProfile();return;}
        clear("Профиль");
        LinearLayout page=profilePage(back);
        TextView[] hero=addProfileHero(page,fallbackName,"Загрузка…");
        LinearLayout details=addCard(page);
        Button blockButton=btn("Заблокировать пользователя");page.addView(blockButton,margins(12,8,12,8,48));
        blockButton.setOnClickListener(v->{if(uid==null){toast("Войди в аккаунт");return;}db.collection("users").document(uid).update("blockedUsers",FieldValue.arrayUnion(userId)).addOnSuccessListener(x->{toast("Пользователь заблокирован");blockButton.setText("Пользователь заблокирован");}).addOnFailureListener(e->toast("Не удалось заблокировать: "+authMessage(e)));});
        db.collection("users").document(userId).get().addOnSuccessListener(u->{
            if(!u.exists()){
                hero[1].setText("Профиль не заполнен");
                return;
            }
            String shownName=userLabel(u,fallbackName);
            hero[0].setText(shownName);
            setVerified(hero[0],Boolean.TRUE.equals(u.getBoolean("verified")),22);
            String un=u.getString("username");
            hero[1].setText(un!=null&&!un.isEmpty()?"@"+un:"Пользователь Echo");
            String[][] rows={{"ℹ","О себе","about"},{"@","Имя пользователя","username"},{"⌖","Местоположение","location"},{"🎂","День рождения","birthday"},{"♫","Музыка профиля","music"}};
            int shown=0;
            for(String[] r:rows){
                String v=u.getString(r[2]);
                if(v==null||v.trim().isEmpty()||v.equals("Не указано"))continue;
                addProfileDetail(details,r[0],r[1],r[2].equals("username")?"@"+v:v,()->{});
                shown++;
            }
            if(shown==0)details.addView(tv("Пользователь пока ничего не рассказал о себе",14,MUTED),new LinearLayout.LayoutParams(-1,dp(56)));
        }).addOnFailureListener(e->hero[1].setText("Не удалось загрузить: "+authMessage(e)));
    }
    TextView addBubble(LinearLayout list,String text,boolean mine,String who){
        if(who==null||who.isEmpty())return addBubble(list,text,mine);
        android.text.SpannableStringBuilder sb=new android.text.SpannableStringBuilder(who+"\n").append(giftText(text));
        sb.setSpan(new android.text.style.ForegroundColorSpan(ACCENT),0,who.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new android.text.style.StyleSpan(Typeface.BOLD),0,who.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView b=tv("",15,TEXT);
        b.setText(sb);
        b.setPadding(dp(16),dp(10),dp(16),dp(10));
        b.setBackground(mine?glassAccent(Color.rgb(18,118,70),20,false):glass(20));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);
        p.setMargins(mine?dp(60):0,dp(5),mine?0:dp(60),dp(5));
        p.gravity=mine?Gravity.RIGHT:Gravity.LEFT;
        list.addView(b,p);
        return b;
    }
    void animateIn(android.view.View v,boolean mine){
        if(!animsOn())return;
        v.setAlpha(0f);
        v.setTranslationX(dp(mine?40:-40));
        v.setTranslationY(dp(14));
        v.setScaleX(.9f);
        v.setScaleY(.9f);
        v.animate().alpha(1f).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(320)
            .setInterpolator(mine?new android.view.animation.OvershootInterpolator(0.9f):new android.view.animation.DecelerateInterpolator()).start();
    }
    void showContacts(){
        clear("Контакты");
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(14),dp(8),dp(14),dp(12));content.addView(page,new LinearLayout.LayoutParams(-1,-1));
        EditText search=edit("Найти пользователя по имени или @username",false);page.addView(search,margins(0,0,0,10,52));
        ScrollView sv=new ScrollView(this);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);sv.addView(results);page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=tv("Поиск пользователей Echo",14,MUTED);hint.setGravity(Gravity.CENTER);results.addView(hint,margins(0,20,0,0,60));
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence a,int st,int c,int af){}public void onTextChanged(CharSequence a,int st,int before,int count){String q=a.toString().trim().toLowerCase(java.util.Locale.ROOT);results.removeAllViews();if(q.length()<2){TextView h=tv("Введи минимум 2 символа",14,MUTED);h.setGravity(Gravity.CENTER);results.addView(h,margins(0,20,0,0,60));return;}db.collection("users").limit(100).get().addOnSuccessListener(snap->{if(!search.getText().toString().trim().toLowerCase(java.util.Locale.ROOT).equals(q))return;results.removeAllViews();int countFound=0;for(DocumentSnapshot u:snap.getDocuments()){if(u.getId().equals(uid))continue;String n=u.getString("name");String un=u.getString("username");if(n==null)n="Пользователь";if((n.toLowerCase(java.util.Locale.ROOT).contains(q)||(un!=null&&un.toLowerCase(java.util.Locale.ROOT).contains(q)))){final String id=u.getId(),name=n;addPersonRow(results,name,un==null?"":"@"+un,Boolean.TRUE.equals(u.getBoolean("verified")),()->new android.app.AlertDialog.Builder(MainActivity.this).setTitle(name).setItems(new String[]{"Открыть профиль","Написать сообщение"},(d,w)->{if(w==0)showUserProfile(id,name,()->showContacts());else openDirectChat(id,name);}).show());countFound++;}}if(countFound==0){TextView none=tv("Пользователи не найдены",14,MUTED);none.setGravity(Gravity.CENTER);results.addView(none,margins(0,20,0,0,60));}}).addOnFailureListener(e->toast("Ошибка поиска: "+authMessage(e)));}public void afterTextChanged(android.text.Editable e){}});
    }
    void openDirectChat(String otherUid,String otherName){
        if(uid==null||otherUid==null||otherUid.trim().isEmpty()){toast("Не удалось определить пользователя");return;}
        db.collection("users").document(uid).get().addOnSuccessListener(me->{java.util.List<String> blocked=(java.util.List<String>)me.get("blockedUsers");if(blocked!=null&&blocked.contains(otherUid)){toast("Сначала разблокируй этого пользователя в настройках конфиденциальности");return;}openDirectChatUnchecked(otherUid,otherName);}).addOnFailureListener(e->toast("Не удалось проверить блокировки: "+authMessage(e)));
    }
    void openDirectChatUnchecked(String otherUid,String otherName){
        if(uid==null||otherUid==null||otherUid.trim().isEmpty()){toast("Не удалось определить пользователя");return;}
        if(uid.equals(otherUid)){toast("Нельзя начать диалог с самим собой");return;}
        String key=uid.compareTo(otherUid)<0?uid+"_"+otherUid:otherUid+"_"+uid;
        // Firestore Rules allow reading chats only when the current user is a member.
        // Therefore query by members first; querying directKey alone causes PERMISSION_DENIED.
        db.collection("chats").whereArrayContains("members",uid).get()
            .addOnSuccessListener(snap->{
                for(DocumentSnapshot d:snap.getDocuments()){
                    if(!"direct".equals(d.getString("type")))continue;
                    java.util.List<?> members=(java.util.List<?>)d.get("members");
                    boolean hasOther=members!=null&&members.contains(otherUid);
                    String existingKey=d.getString("directKey");
                    if(hasOther&&(key.equals(existingKey)||existingKey==null||existingKey.isEmpty())){
                        openChat(d.getId(),otherName,"direct",nz(d.getString("owner")));
                        return;
                    }
                }
                Map<String,Object> c=new HashMap<>();
                c.put("name",otherName);c.put("type","direct");c.put("owner",uid);
                c.put("members",java.util.Arrays.asList(uid,otherUid));c.put("directKey",key);
                c.put("createdAt",FieldValue.serverTimestamp());c.put("lastText","");
                db.collection("chats").add(c)
                    .addOnSuccessListener(ref->openChat(ref.getId(),otherName,"direct",uid))
                    .addOnFailureListener(e->toast("Не удалось создать диалог: "+authMessage(e)));
            })
            .addOnFailureListener(e->toast("Не удалось проверить диалоги: "+authMessage(e)));
    }
    @Override public void onBackPressed(){
        if(!inShell){super.onBackPressed();return;}
        if(navBar!=null&&inChatMode){showChats();return;}
        String t=titleBase==null?"":titleBase;
        java.util.List<String> toChats=java.util.Arrays.asList("Отложенные сообщения","Echo Assist Beta","Echo Stories 2.0","Echo Bots","Echo Calls","Избранное","Контакты","Профиль","Настройки");
        java.util.List<String> toChatSettings=java.util.Arrays.asList("Папки с чатами","Echo Translate");
        java.util.List<String> toPrivacy=java.util.Arrays.asList("Защита приложения","Заблокированные пользователи");
        java.util.List<String> toSettings=java.util.Arrays.asList("Настройки чатов","Аккаунт","Аккаунты","Конфиденциальность","Уведомления","Данные и память","Звёзды Echo","Echo для бизнеса","Пасхалки Echo");
        if(toChats.contains(t)){showChats();return;}
        if(toChatSettings.contains(t)){showChatSettings();return;}
        if(toPrivacy.contains(t)){showPrivacySettings();return;}
        if(toSettings.contains(t)){showSettings();return;}
        if("Устройства".equals(t)){showAccountSettings();return;}
        if("Энергосбережение".equals(t)){showDataSettings();return;}
        if("Отправка подарка".equals(t)){showStars();return;}
        new android.app.AlertDialog.Builder(this).setTitle("Выйти из Echo?").setMessage("Ты находишься на главном экране.").setNegativeButton("Остаться",null).setPositiveButton("Выйти",(d,w)->finish()).show();
    }
    TextView addBubble(LinearLayout list,String text,boolean mine){TextView b=tv(giftText(text),15,TEXT);b.setPadding(dp(16),dp(10),dp(16),dp(10));b.setBackground(mine?glassAccent(Color.rgb(18,118,70),20,false):glass(20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.setMargins(mine?dp(60):0,dp(5),mine?0:dp(60),dp(5));p.gravity=mine?Gravity.RIGHT:Gravity.LEFT;list.addView(b,p);return b;}

    // ===== Служебные уведомления: профиль в стиле Telegram + жидкое стекло и анимации =====
    static class ServiceAvatarView extends android.view.View {
        final android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final android.graphics.Path plane=new android.graphics.Path(), fold=new android.graphics.Path();
        float phase=0f; android.animation.ValueAnimator loop;
        ServiceAvatarView(android.content.Context c){super(c);}
        @Override protected void onAttachedToWindow(){
            super.onAttachedToWindow();
            loop=android.animation.ValueAnimator.ofFloat(0f,1f);loop.setDuration(3600);loop.setRepeatCount(android.animation.ValueAnimator.INFINITE);
            loop.setInterpolator(new android.view.animation.LinearInterpolator());
            loop.addUpdateListener(a->{phase=(Float)a.getAnimatedValue();setTranslationY((float)Math.sin(phase*Math.PI*2)*getHeight()*.025f);invalidate();});
            loop.start();
        }
        @Override protected void onDetachedFromWindow(){super.onDetachedFromWindow();if(loop!=null)loop.cancel();}
        @Override protected void onDraw(android.graphics.Canvas c){
            float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,r=Math.min(w,h)*.33f;
            // расходящиеся «эхо»-кольца
            p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(r*.035f);
            for(int i=0;i<3;i++){
                float t=(phase+i/3f)%1f;
                p.setColor(android.graphics.Color.argb((int)(110*(1f-t)),90,190,255));
                c.drawCircle(cx,cy,r*(1f+t*.62f),p);
            }
            // мягкое свечение
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setShader(new android.graphics.RadialGradient(cx,cy,r*1.5f,new int[]{android.graphics.Color.argb(120,60,170,255),0},null,android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r*1.5f,p);
            // стеклянный диск
            p.setShader(new android.graphics.LinearGradient(cx-r,cy-r,cx+r,cy+r,android.graphics.Color.rgb(66,196,255),android.graphics.Color.rgb(32,134,224),android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r,p);
            p.setShader(new android.graphics.LinearGradient(0,cy-r,0,cy,android.graphics.Color.argb(120,255,255,255),0,android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,r*.96f,p);
            p.setShader(null);
            p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(r*.03f);p.setColor(android.graphics.Color.argb(150,255,255,255));
            c.drawCircle(cx,cy,r*.985f,p);
            // бумажный самолётик, слегка покачивается
            int sv=c.save();
            c.translate(cx,cy);c.rotate((float)Math.sin(phase*Math.PI*2+1f)*4f);c.scale(r/50f,r/50f);c.translate(-50f,-50f);
            plane.reset();plane.moveTo(18,47);plane.lineTo(82,22);plane.lineTo(67,80);plane.lineTo(47,63);plane.lineTo(36,73);plane.lineTo(34,56);plane.close();
            p.setStyle(android.graphics.Paint.Style.FILL);p.setColor(android.graphics.Color.WHITE);c.drawPath(plane,p);
            fold.reset();fold.moveTo(34,56);fold.lineTo(70,32);fold.lineTo(47,63);fold.close();
            p.setColor(android.graphics.Color.argb(70,40,130,210));c.drawPath(fold,p);
            c.restoreToCount(sv);
        }
    }
    // световой блик плавно «гуляет» по стеклу, пока экран открыт
    void glassSweep(final android.view.View v,final long delayMs){
        if(!animsOn())return;
        final android.animation.ValueAnimator[] holder=new android.animation.ValueAnimator[1];
        v.addOnAttachStateChangeListener(new android.view.View.OnAttachStateChangeListener(){
            @Override public void onViewAttachedToWindow(android.view.View x){
                final LiquidGlassDrawable g=findGlass(x.getBackground());if(g==null)return;
                android.animation.ValueAnimator va=android.animation.ValueAnimator.ofFloat(0f,1f);
                va.setDuration(3400);va.setStartDelay(delayMs);va.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                va.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                va.addUpdateListener(a->{float t=(Float)a.getAnimatedValue();float amt=(float)Math.sin(t*Math.PI)*.55f;if(g.getLightAmount()<=.56f)g.setLight(x.getWidth()*t,x.getHeight()*.35f,amt);});
                holder[0]=va;va.start();
            }
            @Override public void onViewDetachedFromWindow(android.view.View x){if(holder[0]!=null)holder[0].cancel();}
        });
    }
    // появление: пружинистый «всплыв» со стеклянным масштабом
    void popIn(android.view.View v,int index){
        if(!animsOn())return;
        v.setAlpha(0f);v.setTranslationY(dp(46));v.setScaleX(.9f);v.setScaleY(.9f);
        v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(90L+index*85L).setDuration(620)
            .setInterpolator(new android.view.animation.OvershootInterpolator(1.5f)).start();
    }
    LinearLayout serviceAction(int iconRes,String label,final Runnable action,final ImageView[] iconOut){
        LinearLayout b=new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);b.setGravity(Gravity.CENTER);
        b.setBackground(glassFull(26));
        ImageView ic=new ImageView(this);ic.setImageResource(iconRes);ic.setColorFilter(TEXT);ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        b.addView(ic,new LinearLayout.LayoutParams(dp(28),dp(28)));
        TextView t=tv(label,14,TEXT);t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.CENTER);
        b.addView(t,new LinearLayout.LayoutParams(-2,dp(26)));
        b.setClickable(true);pressable(b,.92f);
        b.setOnClickListener(v->action.run());
        if(iconOut!=null)iconOut[0]=ic;
        return b;
    }
    void showServiceProfile(){
        clear("Служебные уведомления");
        if(appHeader!=null)appHeader.setVisibility(android.view.View.GONE);
        final android.content.SharedPreferences sp=getSharedPreferences("echo_settings",MODE_PRIVATE);
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14),dp(6),dp(14),dp(24));
        scroll.addView(page);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));

        // верхняя панель: стеклянные кнопки «назад» и «⋮»
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back=new ImageView(this);back.setImageResource(R.drawable.ic_bar_back);back.setColorFilter(TEXT);
        back.setPadding(dp(12),dp(12),dp(12),dp(12));back.setBackground(glassFull(24));pressable(back,.88f);
        back.setOnClickListener(x->showSettings());
        bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
        bar.addView(new android.view.View(this),new LinearLayout.LayoutParams(0,1,1));
        TextView more=tv(ico("⋮"),24,TEXT);more.setGravity(Gravity.CENTER);more.setBackground(glassFull(24));pressable(more,.88f);
        more.setOnClickListener(x->showMainMenu(x));
        bar.addView(more,new LinearLayout.LayoutParams(dp(48),dp(48)));
        page.addView(bar,new LinearLayout.LayoutParams(-1,dp(48)));
        popIn(bar,0);

        // герой: анимированный аватар, имя, галочка, подпись
        ServiceAvatarView av=new ServiceAvatarView(this);
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(250),dp(250));avp.gravity=Gravity.CENTER_HORIZONTAL;avp.setMargins(0,dp(-6),0,dp(-34));
        page.addView(av,avp);
        if(animsOn()){av.setAlpha(0f);av.setScaleX(.4f);av.setScaleY(.4f);av.setRotation(-24f);
            av.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(60).setDuration(900).setInterpolator(new android.view.animation.OvershootInterpolator(1.7f)).start();}

        TextView name=tv("Echo",30,TEXT);name.setTypeface(null,Typeface.BOLD);name.setGravity(Gravity.CENTER);
        setVerified(name,true,24);
        page.addView(name,margins(0,0,0,0,44));popIn(name,2);
        TextView sub=tv("Служебные уведомления",16,MUTED);sub.setGravity(Gravity.CENTER);
        page.addView(sub,margins(0,0,0,20,28));popIn(sub,3);

        // кнопки «Чат» и «Звук»
        LinearLayout actions=new LinearLayout(this);
        final ImageView[] bellRef=new ImageView[1];
        final boolean[] soundOn={sp.getBoolean("service_sound",true)};
        final TextView[] soundLabel=new TextView[1];
        LinearLayout chat=serviceAction(R.drawable.ic_settings_chat,"Чат",()->toast("Служебные сообщения Echo появятся здесь"),null);
        LinearLayout sound=serviceAction(soundOn[0]?R.drawable.ic_bell:R.drawable.ic_bell_off,"Звук",()->{},bellRef);
        soundLabel[0]=(TextView)sound.getChildAt(1);
        sound.setOnClickListener(v->{
            soundOn[0]=!soundOn[0];sp.edit().putBoolean("service_sound",soundOn[0]).apply();
            bellRef[0].setImageResource(soundOn[0]?R.drawable.ic_bell:R.drawable.ic_bell_off);
            soundLabel[0].setText(soundOn[0]?"Звук":"Без звука");
            if(animsOn()){bellRef[0].setPivotX(dp(14));bellRef[0].setPivotY(0f);
                android.animation.ObjectAnimator sw=android.animation.ObjectAnimator.ofFloat(bellRef[0],"rotation",0f,26f,-22f,16f,-10f,5f,0f);
                sw.setDuration(750);sw.start();}
            toast(soundOn[0]?"Звук уведомлений включён":"Звук уведомлений выключен");
        });
        if(!soundOn[0])soundLabel[0].setText("Без звука");
        LinearLayout.LayoutParams l1=new LinearLayout.LayoutParams(0,dp(76),1);l1.setMargins(0,0,dp(6),0);
        LinearLayout.LayoutParams l2=new LinearLayout.LayoutParams(0,dp(76),1);l2.setMargins(dp(6),0,0,0);
        actions.addView(chat,l1);actions.addView(sound,l2);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(76));ap.setMargins(0,0,0,dp(14));
        page.addView(actions,ap);
        popIn(chat,4);popIn(sound,5);glassSweep(chat,0);glassSweep(sound,900);

        // карточка с телефоном
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20),dp(14),dp(20),dp(14));card.setBackground(glassFull(24));
        TextView phone=tv("+42777",22,TEXT);phone.setTypeface(null,Typeface.BOLD);
        card.addView(phone,new LinearLayout.LayoutParams(-1,dp(32)));
        card.addView(tv("Телефон · нажми, чтобы скопировать",13,MUTED),new LinearLayout.LayoutParams(-1,dp(22)));
        card.setClickable(true);pressable(card,.97f);
        card.setOnClickListener(v->{copyText("phone","+42777");
            if(animsOn())phone.animate().scaleX(1.12f).scaleY(1.12f).setDuration(120).withEndAction(()->phone.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(new android.view.animation.OvershootInterpolator(3f)).start()).start();});
        phone.setPivotX(0f);
        page.addView(card,new LinearLayout.LayoutParams(-1,-2));
        popIn(card,6);glassSweep(card,1800);
    }
    void showProfile(){
        clear("Профиль");
        if(appHeader!=null)appHeader.setVisibility(android.view.View.GONE);
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12),0,dp(12),dp(18));
        scroll.addView(page);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        page.addView(topBar(true,""));
        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(0,dp(4),0,dp(14));
        LinearLayout.LayoutParams heroAv=new LinearLayout.LayoutParams(dp(112),dp(112));
        heroAv.gravity=Gravity.CENTER_HORIZONTAL;
        hero.addView(avatarWithCamera(112,()->chooseProfilePhoto()),heroAv);
        TextView name=tv(profileName,24,TEXT);
        name.setTypeface(null,Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        hero.addView(name,margins(0,10,0,0,38));
        if(uid!=null)db.collection("users").document(uid).get().addOnSuccessListener(vd->setVerified(name,Boolean.TRUE.equals(vd.getBoolean("verified")),22));
        TextView online=tv("в сети",14,MUTED);
        online.setGravity(Gravity.CENTER);
        hero.addView(online,new LinearLayout.LayoutParams(-1,dp(26)));
        page.addView(hero,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout actions=new LinearLayout(this);
        actions.addView(profileAction(R.drawable.ic_onb_camera,"Выбрать фото",()->chooseProfilePhoto()),profileActionParams());
        actions.addView(profileAction(R.drawable.ic_edit,"Изменить",()->editProfile()),profileActionParams());
        actions.addView(profileAction(R.drawable.ic_nav_settings,"Настройки",()->showSettings()),profileActionParams());
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(68));
        ap.setMargins(0,0,0,dp(12));
        page.addView(actions,ap);

        FirebaseUser user=auth.getCurrentUser();
        String phone=user!=null&&user.getPhoneNumber()!=null&&!user.getPhoneNumber().isEmpty()?user.getPhoneNumber():"Не указан";
        LinearLayout info=settingsCard(page);
        addInfoRow(info,phone,"Телефон",()->showAccountSettings());
        addInfoRow(info,"@"+profileUsername,"Имя пользователя",()->editProfile());
        addInfoRow(info,profileAbout,"О себе",()->editProfile());
        addInfoRow(info,user!=null&&user.getEmail()!=null?user.getEmail():"Не привязан","Email",()->showAccountSettings());
        addInfoRow(info,profileLocation,"Местоположение",()->editProfile());
        addInfoRow(info,profileBirthday,"День рождения",()->editProfile());
        addInfoRow(info,profileMusic,"Музыка профиля",()->editMusic());
        android.content.SharedPreferences bz=getSharedPreferences("echo_business",MODE_PRIVATE);
        if(!bz.getString("name","").isEmpty())addInfoRow(info,bz.getString("name",""),"Компания",()->showBusiness());
        if(!bz.getString("hours","").isEmpty())addInfoRow(info,bz.getString("hours",""),"Часы работы",()->showBusiness());
        if(user!=null)user.getIdToken(false).addOnSuccessListener(token->{if(Boolean.TRUE.equals(token.getClaims().get("owner"))){Button ownerPanel=btn(ico("👑  Панель владельца Echo"));ownerPanel.setBackground(bg(Color.rgb(58,42,90),18));page.addView(ownerPanel,margins(0,0,0,12,52));ownerPanel.setOnClickListener(v->showOwnerPanel());}});

        LinearLayout tabs=new LinearLayout(this);
        tabs.setPadding(dp(4),dp(4),dp(4),dp(4));
        tabs.setBackground(glass(22));
        TextView tPosts=tv("Публикации",14,MUTED),tArchive=tv("Архив публикаций",14,MUTED);
        tPosts.setGravity(Gravity.CENTER);
        tArchive.setGravity(Gravity.CENTER);
        tabs.addView(tPosts,new LinearLayout.LayoutParams(0,dp(38),1));
        tabs.addView(tArchive,new LinearLayout.LayoutParams(0,dp(38),1));
        page.addView(tabs,margins(20,0,20,6,46));
        LinearLayout tabContent=new LinearLayout(this);
        tabContent.setOrientation(LinearLayout.VERTICAL);
        page.addView(tabContent,new LinearLayout.LayoutParams(-1,-2));
        Runnable showPosts=()->{
            paintProfileTabs(tPosts,tArchive,0);
            profileEmpty(tabContent,"",false);
            if(uid==null){profileEmpty(tabContent,"Публикаций пока нет...",true);return;}
            db.collection("users").document(uid).collection("posts").orderBy("createdAt",Query.Direction.DESCENDING).limit(30).get().addOnSuccessListener(snap->{
                if(snap.isEmpty()){profileEmpty(tabContent,"Публикаций пока нет...",true);return;}
                tabContent.removeAllViews();
                for(DocumentSnapshot pd:snap.getDocuments()){
                    LinearLayout pc=new LinearLayout(this);
                    pc.setOrientation(LinearLayout.VERTICAL);
                    pc.setPadding(dp(14),dp(10),dp(14),dp(10));
                    pc.setBackground(glass(16));
                    TextView pt=tv(nz(pd.getString("text")),15,TEXT);
                    pt.setGravity(Gravity.START);
                    java.util.Date pdt=pd.getDate("createdAt");
                    TextView ptime=tv(pdt==null?"":fmtTime(pdt),11,MUTED);
                    ptime.setGravity(Gravity.END);
                    pc.addView(pt,new LinearLayout.LayoutParams(-1,-2));
                    pc.addView(ptime,new LinearLayout.LayoutParams(-1,dp(20)));
                    tabContent.addView(pc,wrapMargins(0,0,0,8));
                }
                addPostButton(tabContent);
            }).addOnFailureListener(e->profileEmpty(tabContent,"Публикаций пока нет...",true));
        };
        Runnable showArchive=()->{
            paintProfileTabs(tPosts,tArchive,1);
            profileEmpty(tabContent,"Архив публикаций пуст",false);
        };
        tPosts.setOnClickListener(v->showPosts.run());
        tArchive.setOnClickListener(v->showArchive.run());
        showPosts.run();
    }
    void paintProfileTabs(TextView a,TextView b,int active){
        a.setBackground(active==0?bg(Color.argb(70,51,144,236),18):null);
        b.setBackground(active==1?bg(Color.argb(70,51,144,236),18):null);
        a.setTextColor(active==0?Color.rgb(110,180,245):MUTED);
        b.setTextColor(active==1?Color.rgb(110,180,245):MUTED);
    }
    void profileEmpty(LinearLayout box,String title,boolean withButton){
        box.removeAllViews();
        if(title.isEmpty())return;
        TextView t=tv(title,17,TEXT);
        t.setTypeface(null,Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        box.addView(t,margins(0,40,0,0,30));
        TextView s=tv(withButton?"Публикуйте новости и мысли в своём профиле":"Здесь появятся скрытые публикации",13,MUTED);
        s.setGravity(Gravity.CENTER);
        box.addView(s,new LinearLayout.LayoutParams(-1,dp(26)));
        if(withButton)addPostButton(box);
    }
    void addPostButton(LinearLayout box){
        Button add=btn(ico("＋  Добавить"));
        add.setBackground(bg(DEEP,24));
        add.setTextColor(Color.WHITE);
        add.setTypeface(null,Typeface.BOLD);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(160),dp(46));
        p.gravity=Gravity.CENTER_HORIZONTAL;
        p.topMargin=dp(22);
        box.addView(add,p);
        add.setOnClickListener(v->createPost());
    }
    LinearLayout.LayoutParams profileActionParams(){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
        p.setMargins(dp(4),0,dp(4),0);
        return p;
    }
    LinearLayout profileAction(int iconRes,String label,Runnable action){
        LinearLayout b=new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setBackground(glass(16));
        ImageView ic=new ImageView(this);
        ic.setImageResource(iconRes);
        ic.setColorFilter(TEXT);
        ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        b.addView(ic,new LinearLayout.LayoutParams(dp(24),dp(24)));
        TextView t=tv(label,12,TEXT);
        t.setGravity(Gravity.CENTER);
        b.addView(t,new LinearLayout.LayoutParams(-2,dp(22)));
        b.setClickable(true);
        b.setOnClickListener(v->action.run());
        return b;
    }
    void addInfoRow(LinearLayout parent,String value,String label,Runnable action){
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView v1=tv(value==null||value.isEmpty()?"—":value,16,TEXT);
        v1.setGravity(Gravity.CENTER_VERTICAL);
        TextView l1=tv(label,12,MUTED);
        row.addView(v1,new LinearLayout.LayoutParams(-1,-2));
        row.addView(l1,new LinearLayout.LayoutParams(-1,-2));
        row.setClickable(true);
        row.setOnClickListener(x->action.run());
        parent.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }

    // ===== Telegram-style helpers: top bar, avatar with camera badge, QR, menu =====
    LinearLayout topBar(boolean qr,String centerTitle){
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        ImageView q=new ImageView(this);
        q.setImageResource(R.drawable.ic_qr);
        q.setColorFilter(TEXT);
        q.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        q.setPadding(dp(12),dp(12),dp(12),dp(12));
        if(qr)q.setOnClickListener(x->showQrCode());else q.setVisibility(android.view.View.INVISIBLE);
        bar.addView(q,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView t=tv(centerTitle,18,TEXT);
        t.setTypeface(null,Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        bar.addView(t,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView more=tv(ico("⋮"),24,TEXT);
        more.setGravity(Gravity.CENTER);
        more.setOnClickListener(x->showMainMenu(x));
        bar.addView(more,new LinearLayout.LayoutParams(dp(48),dp(48)));
        return bar;
    }
    FrameLayout avatarWithCamera(int sizeDp,Runnable click){
        FrameLayout f=new FrameLayout(this);
        android.view.View av=profilePhotoUri!=null?profileAvatarView():avatar(profileName,dp(sizeDp));
        f.addView(av,new FrameLayout.LayoutParams(dp(sizeDp),dp(sizeDp),Gravity.CENTER));
        ImageView cam=new ImageView(this);
        cam.setImageResource(R.drawable.ic_onb_camera);
        cam.setColorFilter(Color.WHITE);
        cam.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int cd=sizeDp>90?32:26;
        int pad=sizeDp>90?7:5;
        cam.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));
        GradientDrawable cb=oval(DEEP);
        cb.setStroke(dp(2),BG);
        cam.setBackground(cb);
        f.addView(cam,new FrameLayout.LayoutParams(dp(cd),dp(cd),Gravity.BOTTOM|Gravity.RIGHT));
        f.setOnClickListener(x->click.run());
        return f;
    }
    void showMainMenu(android.view.View anchor){
        PopupMenu m=new PopupMenu(this,anchor);
        m.getMenu().add(0,1,0,"Новая группа");
        m.getMenu().add(0,2,1,"Новый канал");
        m.getMenu().add(0,3,2,"Найти и вступить");
        m.getMenu().add(0,4,3,"Echo Stories");
        m.getMenu().add(0,9,4,"Echo Calls");
        m.getMenu().add(0,5,5,"Мой QR-код");
        m.getMenu().add(0,7,6,"Сканировать QR-код");
        m.getMenu().add(0,8,7,"Сменить аккаунт");
        m.getMenu().add(0,6,8,"Настройки");
        m.setOnMenuItemClickListener(it->{
            int id=it.getItemId();
            if(id==1)showCreateChat("group");
            else if(id==2)showCreateChat("channel");
            else if(id==3)showFindChats();
            else if(id==4)showStories();
            else if(id==5)showQrCode();
            else if(id==7)scanQr();
            else if(id==8)showAccounts();
            else if(id==9)showEchoCalls();
            else showSettings();
            return true;
        });
        m.show();
    }
    final int[][] QR_THEMES={
        {Color.rgb(20,90,200),Color.rgb(27,38,52),Color.rgb(30,50,74)},
        {Color.rgb(30,140,70),Color.rgb(24,60,44),Color.rgb(18,36,34)},
        {Color.rgb(120,60,200),Color.rgb(50,30,90),Color.rgb(24,18,52)},
        {Color.rgb(200,60,110),Color.rgb(90,30,56),Color.rgb(40,20,40)},
        {Color.rgb(210,120,20),Color.rgb(96,54,20),Color.rgb(44,28,24)},
        {Color.rgb(20,140,160),Color.rgb(16,70,80),Color.rgb(14,36,50)}};
    void showQrCode(){
        String uname=profileUsername==null?"":profileUsername;
        final String link="echo://u/"+uname;
        final int theme=Math.max(0,Math.min(QR_THEMES.length-1,getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("qr_theme",0)));
        final int moduleColor=QR_THEMES[theme][0];
        clear("QR-код");
        if(appHeader!=null)appHeader.setVisibility(android.view.View.GONE);
        chatMode(true);
        ScrollView sv=new ScrollView(this);
        sv.setFillViewport(true);
        GradientDrawable pageBg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{QR_THEMES[theme][1],QR_THEMES[theme][2]});
        sv.setBackground(pageBg);
        content.addView(sv,new LinearLayout.LayoutParams(-1,-1));
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(18),dp(6),dp(18),dp(18));
        sv.addView(page,new FrameLayout.LayoutParams(-1,-2));
        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=tv(ico("←"),26,TEXT);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(x->showProfile());
        top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
        page.addView(top,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(24),dp(22),dp(24),dp(20));
        card.setBackground(bg(Color.WHITE,24));
        card.addView(avatar(profileName,dp(64)),new LinearLayout.LayoutParams(dp(64),dp(64)));
        ImageView qrView=new ImageView(this);
        try{
            com.google.zxing.common.BitMatrix bm=new com.google.zxing.qrcode.QRCodeWriter().encode(link,com.google.zxing.BarcodeFormat.QR_CODE,512,512);
            int w=bm.getWidth(),h=bm.getHeight();
            int[] px=new int[w*h];
            for(int iy=0;iy<h;iy++)for(int ix=0;ix<w;ix++)px[iy*w+ix]=bm.get(ix,iy)?moduleColor:Color.WHITE;
            qrView.setImageBitmap(android.graphics.Bitmap.createBitmap(px,w,h,android.graphics.Bitmap.Config.ARGB_8888));
        }catch(Exception e){toast("Не удалось создать QR-код");}
        LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(dp(220),dp(220));
        qp.topMargin=dp(12);
        card.addView(qrView,qp);
        TextView un=tv("@"+uname.toUpperCase(java.util.Locale.ROOT),18,moduleColor);
        un.setTypeface(null,Typeface.BOLD);
        un.setGravity(Gravity.CENTER);
        card.addView(un,new LinearLayout.LayoutParams(-2,dp(40)));
        LinearLayout.LayoutParams cardP=new LinearLayout.LayoutParams(dp(290),-2);
        cardP.topMargin=dp(12);
        page.addView(card,cardP);
        TextView themeTitle=tv("Тема QR-кода",14,TEXT);
        themeTitle.setTypeface(null,Typeface.BOLD);
        page.addView(themeTitle,margins(4,16,4,4,30));
        HorizontalScrollView hs=new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout themes=new LinearLayout(this);
        hs.addView(themes);
        for(int i=0;i<QR_THEMES.length;i++){
            final int idx=i;
            TextView th=new TextView(this);
            GradientDrawable tb=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{QR_THEMES[i][1],QR_THEMES[i][2]});
            tb.setCornerRadius(dp(12));
            if(i==theme)tb.setStroke(dp(2),Color.WHITE);
            th.setBackground(tb);
            th.setText(ico("▦"));
            th.setTextColor(Color.WHITE);
            th.setTextSize(22);
            th.setGravity(Gravity.CENTER);
            th.setOnClickListener(x->{getSharedPreferences("echo_settings",MODE_PRIVATE).edit().putInt("qr_theme",idx).apply();showQrCode();});
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(56),dp(70));
            tp.setMargins(dp(4),dp(4),dp(4),dp(4));
            themes.addView(th,tp);
        }
        page.addView(hs,new LinearLayout.LayoutParams(-1,dp(82)));
        Button share=btn("Поделиться");
        share.setBackground(bg(DEEP,24));
        share.setTextColor(Color.WHITE);
        share.setOnClickListener(x->{Intent si=new Intent(Intent.ACTION_SEND);si.setType("text/plain");si.putExtra(Intent.EXTRA_TEXT,"Я в Echo Messenger: @"+profileUsername+" · "+link);startActivity(Intent.createChooser(si,"Поделиться"));});
        page.addView(share,margins(12,10,12,0,50));
        Button scan=btn("Сканировать QR-код");
        scan.setBackground(null);
        scan.setTextColor(Color.rgb(120,190,250));
        scan.setOnClickListener(x->scanQr());
        page.addView(scan,margins(12,4,12,0,50));
    }

    void showOwnerPanel(){
        clear("Панель владельца");addPageBack(()->showProfile());
        TextView intro=tv("Управление Echo Messenger",21,TEXT);intro.setTypeface(null,Typeface.BOLD);content.addView(intro,wrapMargins(14,8,14,6));
        TextView note=tv("Изменения выполняются через защищённые Firebase Cloud Functions. Укажи UID пользователя, не username.",13,MUTED);content.addView(note,wrapMargins(14,0,14,14));
        Button verify=btn(ico("🔵 Выдать / снять галочку"));content.addView(verify,margins(14,4,14,8,52));verify.setOnClickListener(v->promptOwnerTarget("setUserVerification","verified","Верификация","Выдать галочку?"));
        Button premium=btn(ico("💎 Включить / отключить Echo Plus"));content.addView(premium,margins(14,4,14,8,52));premium.setOnClickListener(v->promptOwnerTarget("setUserPremium","premium","Echo Plus","Изменить статус Echo Plus?"));
        Button moderator=btn(ico("🛡️ Назначить / снять модератора"));content.addView(moderator,margins(14,4,14,8,52));moderator.setOnClickListener(v->promptOwnerTarget("setUserRole","role","Роль модератора","Назначить или снять роль модератора?"));
        Button ban=btn(ico("⛔ Заблокировать / разблокировать"));content.addView(ban,margins(14,4,14,8,52));ban.setOnClickListener(v->promptOwnerTarget("setUserBanned","banned","Блокировка","Изменить статус блокировки?"));
        TextView security=tv("Не выдавай права владельца другим пользователям. Проверка owner выполняется на сервере.",12,MUTED);content.addView(security,wrapMargins(14,16,14,8));
    }
    void promptOwnerTarget(String function,String field,String label,String question){
        EditText target=edit("UID пользователя",false);
        new android.app.AlertDialog.Builder(this).setTitle(label).setMessage(question).setView(target).setNegativeButton("Отмена",null).setPositiveButton("Продолжить",(d,w)->{
            String targetUid=target.getText().toString().trim();if(targetUid.isEmpty()){toast("Введи UID пользователя");return;}
            Map<String,Object> data=new HashMap<>();data.put("uid",targetUid);
            com.google.firebase.functions.FirebaseFunctions.getInstance().getHttpsCallable(function).call(data).addOnSuccessListener(result->{toast("Готово: "+label);}).addOnFailureListener(e->toast("Не удалось выполнить действие: "+authMessage(e)));
        }).show();
    }

    void showEchoAssist(){
        clear("Echo Assist Beta");addPageBack(()->showChats());
        TextView intro=tv("Помощник для черновиков сообщений. Работает локально по шаблонам и не отправляет текст на внешний AI-сервис.",13,MUTED);intro.setPadding(dp(14),dp(8),dp(14),dp(12));content.addView(intro);
        EditText topic=edit("О чём написать? (необязательно)",false);content.addView(topic,margins(12,4,12,8,54));
        String[] kinds={"Дружелюбный ответ","Вежливый отказ","Извинение","Приглашение","Объявление проекта"};
        Spinner choices=new Spinner(this);choices.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,kinds));content.addView(choices,margins(12,2,12,10,48));
        TextView result=tv("Выбери тип сообщения и нажми «Создать черновик».",15,TEXT);result.setGravity(Gravity.TOP);result.setPadding(dp(14),dp(14),dp(14),dp(14));result.setBackground(glass(18));content.addView(result,margins(12,4,12,10,150));
        Button generate=btn(ico("✨ Создать черновик"));content.addView(generate,margins(12,4,12,8,52));
        Button share=btn("Поделиться / скопировать текст");content.addView(share,margins(12,4,12,8,52));
        final String[] draft={""};
        generate.setOnClickListener(v->{String subject=topic.getText().toString().trim();String suffix=subject.isEmpty()?"":(" Тема: "+subject+".");switch(choices.getSelectedItemPosition()){case 0:draft[0]="Привет! Спасибо за сообщение. Я увидел(а) его и скоро отвечу."+suffix;break;case 1:draft[0]="Спасибо, что предложил(а). К сожалению, сейчас не получится, но я ценю приглашение."+suffix;break;case 2:draft[0]="Прости, пожалуйста, что так получилось. Я не хотел(а) тебя расстроить и постараюсь исправить ситуацию."+suffix;break;case 3:draft[0]="Привет! Будет здорово, если присоединишься. Дай знать, сможешь ли прийти."+suffix;break;default:draft[0]="Обновление проекта"+(subject.isEmpty()?"":" — "+subject)+"\nМы продолжаем работу над Echo Messenger. Спасибо всем, кто тестирует Beta и присылает отзывы!";}result.setText(draft[0]);});
        share.setOnClickListener(v->{if(draft[0].isEmpty()){toast("Сначала создай черновик");return;}Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,draft[0]);startActivity(Intent.createChooser(i,"Поделиться черновиком"));});
        TextView disclaimer=tv("Это не генеративная нейросеть: функция собирает черновик из встроенных шаблонов. Подключение настоящего AI потребует отдельного защищённого сервера.",12,MUTED);disclaimer.setPadding(dp(14),dp(12),dp(14),dp(8));content.addView(disclaimer);
    }

    void showEchoPlus(){
        clear("Echo Plus");
        ScrollView scroll=new ScrollView(this);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(18),dp(20),dp(18),dp(24));scroll.addView(page);content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        TextView icon=tv(ico("✦"),62,Color.rgb(202,164,255));icon.setGravity(Gravity.CENTER);page.addView(icon,margins(0,18,0,8,84));
        TextView heading=tv("Echo Plus",30,TEXT);heading.setTypeface(null,Typeface.BOLD);heading.setGravity(Gravity.CENTER);page.addView(heading,margins(0,0,0,8,44));
        TextView sub=tv("Больше возможностей. Тот же Echo.",15,MUTED);sub.setGravity(Gravity.CENTER);page.addView(sub,margins(0,0,0,22,30));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(14),dp(18),dp(14));card.setBackground(glass(22));
        CharSequence[] perks={ico("✦  Эксклюзивный значок Echo Plus"),ico("🎨  Дополнительные темы профиля"),ico("✨  Больше персонализации"),ico("🚀  Ранний доступ к новым функциям")};
        for(CharSequence perk:perks){TextView line=tv(perk,15,TEXT);card.addView(line,margins(0,5,0,5,42));}
        page.addView(card,wrapMargins(0,0,0,16));
        TextView themeTitle=tv("Персонализация профиля",17,TEXT);themeTitle.setTypeface(null,Typeface.BOLD);page.addView(themeTitle,margins(0,4,0,8,34));
        String[] themeNames={"Ocean Blue","Violet Glass","Rose Glow","Emerald"};int[] themeColors={Color.rgb(51,144,236),Color.rgb(139,92,246),Color.rgb(232,82,142),Color.rgb(16,163,127)};
        android.content.SharedPreferences plusPrefs=getSharedPreferences("echo_plus",MODE_PRIVATE);int savedTheme=plusPrefs.getInt("profile_theme",0);if(savedTheme<0||savedTheme>=themeColors.length)savedTheme=0;
        LinearLayout themeCard=new LinearLayout(this);themeCard.setOrientation(LinearLayout.VERTICAL);themeCard.setPadding(dp(14),dp(12),dp(14),dp(12));themeCard.setBackground(glass(18));
        TextView themePreview=tv(ico("✦  Echo Messenger\n      Твой профиль — твой стиль"),16,TEXT);themePreview.setPadding(dp(14),dp(10),dp(14),dp(10));themePreview.setBackground(bg(themeColors[savedTheme],18));themeCard.addView(themePreview,margins(0,0,0,10,76));
        Button chooseTheme=btn(ico("🎨 Выбрать акцент профиля"));themeCard.addView(chooseTheme,margins(0,0,0,0,48));chooseTheme.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Тема профиля").setSingleChoiceItems(themeNames,plusPrefs.getInt("profile_theme",0),(dialog,which)->{plusPrefs.edit().putInt("profile_theme",which).apply();themePreview.setBackground(bg(themeColors[which],18));toast("Тема профиля сохранена");dialog.dismiss();}).setNegativeButton("Закрыть",null).show());page.addView(themeCard,wrapMargins(0,0,0,14));
        TextView note=tv("Echo Plus находится в Beta. Выбор темы сохраняется на этом устройстве и пока меняет только карточку предпросмотра. Оплата и платная подписка не подключены.",13,MUTED);note.setGravity(Gravity.CENTER);page.addView(note,wrapMargins(4,0,4,16));
        Button back=btn("‹  Назад в профиль");back.setBackground(bg(Color.rgb(111,72,190),18));page.addView(back,margins(0,8,0,0,52));back.setOnClickListener(v->showProfile());
    }
    void addProfileDetail(LinearLayout parent,String icon,String label,String value,Runnable action){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),dp(8),dp(4),dp(8));TextView ic=tv(ico(icon),19,BLUE);ic.setGravity(Gravity.CENTER);row.addView(ic,new LinearLayout.LayoutParams(dp(42),dp(48)));LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);TextView l=tv(label,12,MUTED),v=tv(value,15,TEXT);col.addView(l);col.addView(v);row.addView(col,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=tv(ico("›"),24,MUTED);row.addView(arrow);row.setOnClickListener(clicked->action.run());parent.addView(row,new LinearLayout.LayoutParams(-1,-2));}
    void editProfile(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText n=edit("Имя профиля",false),u=edit("Имя пользователя (username)",false),a=edit("О себе",false),loc=edit("Местоположение",false),birth=edit("День рождения",false);
        n.setText(profileName);u.setText(profileUsername);a.setText(profileAbout);loc.setText(profileLocation);birth.setText(profileBirthday);
        u.setFilters(new android.text.InputFilter[]{(src,st,en,dst,ds,de)->{StringBuilder out=new StringBuilder();for(int i=st;i<en;i++){char c=Character.toLowerCase(src.charAt(i));if((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_')out.append(c);}return out.toString();},new android.text.InputFilter.LengthFilter(24)});
        TextView hint=tv("3–24 символа: латинские буквы, цифры и _; начинается с буквы; должен быть уникальным",12,MUTED);form.addView(hint,wrapMargins(2,0,2,6));
        attachUsernameChecker(u,hint,"3–24 символа: латинские буквы, цифры и _; начинается с буквы; должен быть уникальным",new String[]{profileUsername==null?"":profileUsername.toLowerCase(java.util.Locale.ROOT)},false,null);
        for(EditText e:new EditText[]{n,u,a,loc,birth})form.addView(e,margins(0,4,0,4,52));
        new android.app.AlertDialog.Builder(this).setTitle("Изменить профиль").setView(form).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(dialog,which)->{
            String newName=n.getText().toString().trim();String newUsername=u.getText().toString().trim().replace("@", "").toLowerCase(java.util.Locale.ROOT);
            String newAbout=a.getText().toString().trim(),newLocation=loc.getText().toString().trim(),newBirthday=birth.getText().toString().trim();
            if(!newUsername.equals(profileUsername==null?"":profileUsername.toLowerCase(java.util.Locale.ROOT))){String unErr=usernameError(newUsername);if(unErr!=null){toast(unErr);return;}}
            else if(!newUsername.matches("[a-z0-9_]{3,24}")){toast("Username должен содержать 3–24 символа: a-z, 0-9 и _");return;}
            if(uid==null){toast("Сначала войди в аккаунт");return;}
            final String oldUsername=profileUsername==null?"":profileUsername.toLowerCase(java.util.Locale.ROOT);
            Map<String,Object> data=new HashMap<>();data.put("name",newName);data.put("username",newUsername);data.put("about",newAbout);data.put("location",newLocation);data.put("birthday",newBirthday);
            db.runTransaction(tr->{
                DocumentReference newRef=db.collection("usernames").document(newUsername);
                DocumentSnapshot newSnap=tr.get(newRef);
                DocumentReference oldRef=oldUsername.isEmpty()?null:db.collection("usernames").document(oldUsername);
                DocumentSnapshot oldSnap=oldRef==null?null:tr.get(oldRef);
                if(newSnap.exists()&&(!uid.equals(newSnap.getString("uid"))||"channel".equals(newSnap.getString("kind"))))throw new FirebaseFirestoreException("taken",FirebaseFirestoreException.Code.ALREADY_EXISTS);
                if(oldRef!=null&&!oldUsername.equals(newUsername)&&oldSnap!=null&&oldSnap.exists()&&uid.equals(oldSnap.getString("uid")))tr.delete(oldRef);
                Map<String,Object> claim=new HashMap<>();claim.put("uid",uid);tr.set(newRef,claim);
                tr.set(db.collection("users").document(uid),data,SetOptions.merge());return null;
            }).addOnSuccessListener(v->{
                profileName=newName;profileUsername=newUsername;profileAbout=newAbout;profileLocation=newLocation;profileBirthday=newBirthday;
                getSharedPreferences("echo_profile",MODE_PRIVATE).edit().putString("name",profileName).putString("username",profileUsername).putString("about",profileAbout).putString("location",profileLocation).putString("birthday",profileBirthday).apply();
                toast("Профиль сохранён");showProfile();
            }).addOnFailureListener(e->{if(e instanceof FirebaseFirestoreException&&((FirebaseFirestoreException)e).getCode()==FirebaseFirestoreException.Code.ALREADY_EXISTS)toast("Имя @"+newUsername+" уже занято — выбери другое");else if(e instanceof FirebaseFirestoreException&&((FirebaseFirestoreException)e).getCode()==FirebaseFirestoreException.Code.PERMISSION_DENIED)toast("Нет доступа к usernames. Опубликуй обновлённые firestore.rules");else toast("Не удалось сохранить профиль: "+authMessage(e));});
        }).show();
    }
    void editMusic(){EditText field=edit("Название трека / исполнитель",false);field.setText(profileMusic);new android.app.AlertDialog.Builder(this).setTitle("Музыка профиля").setMessage("Укажи трек, который будет отображаться в профиле.").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{profileMusic=field.getText().toString().trim();getSharedPreferences("echo_profile",MODE_PRIVATE).edit().putString("music",profileMusic).apply();if(uid!=null)db.collection("users").document(uid).set(java.util.Collections.singletonMap("music",profileMusic),SetOptions.merge());showProfile();}).show();}
    void chooseProfilePhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,401);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_MEDIA){if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)uploadAndSend(data.getData());return;}if(requestCode==402){if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null){onboardPhoto=data.getData();try{getContentResolver().takePersistableUriPermission(onboardPhoto,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(onPhotoPicked!=null)onPhotoPicked.run();}return;}if(requestCode==401&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){profilePhotoUri=data.getData();try{getContentResolver().takePersistableUriPermission(profilePhotoUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}getSharedPreferences("echo_profile",MODE_PRIVATE).edit().putString("photo",profilePhotoUri.toString()).apply();toast("Фото выбрано. Для синхронизации фото между устройствами потребуется отдельное внешнее хранилище; Firebase Storage не используется.");showProfile();}}
    void createPost(){EditText text=edit("Текст публикации",false);text.setSingleLine(false);text.setMinLines(3);new android.app.AlertDialog.Builder(this).setTitle("Новая публикация").setView(text).setNegativeButton("Отмена",null).setPositiveButton("Опубликовать",(d,w)->{String body=text.getText().toString().trim();if(body.isEmpty()){toast("Напиши текст публикации");return;}Map<String,Object> post=new HashMap<>();post.put("text",body);post.put("owner",uid);post.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(uid).collection("posts").add(post).addOnSuccessListener(ref->{toast("Публикация сохранена");showProfile();}).addOnFailureListener(e->toast("Не удалось опубликовать: "+e.getMessage()));}).show();}
    void showFavorites(){
        clear("Избранное"); addPageBack(()->showChats());
        Button note=btn("+ Добавить заметку"); content.addView(note,margins(12,8,12,8,48));
        note.setOnClickListener(v->{EditText e=edit("Текст заметки",false);e.setMinLines(3);new android.app.AlertDialog.Builder(this).setTitle("Новая заметка").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{String text=e.getText().toString().trim();if(text.isEmpty()||uid==null)return;Map<String,Object> m=new HashMap<>();m.put("text",text);m.put("kind","note");m.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(uid).collection("favorites").add(m).addOnSuccessListener(x->{toast("Заметка сохранена");showFavorites();}).addOnFailureListener(err->toast("Ошибка сохранения: "+authMessage(err)));}).show();});
        if(uid==null){simpleInfo("Избранное","Войди в аккаунт, чтобы синхронизировать сохранённые сообщения.");return;}
        db.collection("users").document(uid).collection("favorites").orderBy("createdAt",Query.Direction.DESCENDING).limit(100).get().addOnSuccessListener(snap->{if(snap.isEmpty()){TextView empty=tv("Здесь будут сохранённые сообщения и заметки",14,MUTED);empty.setGravity(Gravity.CENTER);content.addView(empty,margins(12,24,12,0,80));return;}for(DocumentSnapshot d:snap.getDocuments()){String savedText=d.getString("text");final String text=savedText==null?"":savedText;String chat=d.getString("chatName");LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(14),dp(12),dp(14),dp(12));row.setBackground(glass(16));TextView body=tv(text,15,TEXT);row.addView(body);if(chat!=null){TextView source=tv("Из чата: "+chat,12,MUTED);row.addView(source);}row.setOnLongClickListener(v->{new android.app.AlertDialog.Builder(this).setItems(new String[]{"Копировать","Удалить из Избранного"},(dd,which)->{if(which==0){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("Echo",text));toast("Скопировано");}else db.collection("users").document(uid).collection("favorites").document(d.getId()).delete().addOnSuccessListener(z->showFavorites()).addOnFailureListener(err->toast(authMessage(err)));}).show();return true;});content.addView(row,margins(12,4,12,4,-2));}}).addOnFailureListener(e->toast("Не удалось загрузить Избранное: "+authMessage(e)));
    }

    void showChatFolders(){
        clear("Папки с чатами");addPageBack(()->showChatSettings());
        android.content.SharedPreferences p=getSharedPreferences("echo_chat_folders",MODE_PRIVATE);
        Button add=btn("+ Создать папку");content.addView(add,margins(12,8,12,8,50));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list,new LinearLayout.LayoutParams(-1,-2));
        final Runnable[] refresh=new Runnable[1];refresh[0]=()->{list.removeAllViews();java.util.Set<String> folders=p.getStringSet("folders",new java.util.HashSet<String>());if(folders.isEmpty()){TextView empty=tv("Пока нет папок. Создай папку, например «Работа» или «Друзья».",14,MUTED);empty.setGravity(Gravity.CENTER);list.addView(empty,margins(16,16,16,0,72));}else for(String f:new java.util.TreeSet<String>(folders)){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(14),dp(12),dp(14),dp(12));r.setBackground(glass(16));TextView t=tv(f,16,TEXT);r.addView(t,new LinearLayout.LayoutParams(0,dp(42),1));TextView del=tv("Удалить",13,Color.rgb(255,110,110));r.addView(del);del.setOnClickListener(v->{java.util.Set<String> next=new java.util.HashSet<>(p.getStringSet("folders",new java.util.HashSet<String>()));next.remove(f);p.edit().putStringSet("folders",next).apply();refresh[0].run();});list.addView(r,margins(12,4,12,4,60));}};
        add.setOnClickListener(v->{EditText e=edit("Название папки",false);new android.app.AlertDialog.Builder(this).setTitle("Создать папку").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Создать",(d,w)->{String f=e.getText().toString().trim();if(f.isEmpty())return;java.util.Set<String> next=new java.util.HashSet<>(p.getStringSet("folders",new java.util.HashSet<String>()));next.add(f);p.edit().putStringSet("folders",next).apply();refresh[0].run();}).show();});refresh[0].run();
        TextView info=tv("Папки пока хранятся на этом устройстве. Привязка чатов к папкам и синхронизация будут следующим этапом.",12,MUTED);content.addView(info,margins(14,12,14,8,-2));
    }

    void showAppLockSettings(){
        clear("Защита приложения");addPageBack(()->showPrivacySettings());
        android.content.SharedPreferences p=getSharedPreferences("echo_app_lock",MODE_PRIVATE);
        boolean enabled=p.getBoolean("enabled",false);
        simpleSettingRow("Статус PIN-кода",enabled?"Включён":"Выключен",()->{if(p.getString("pin_hash","").isEmpty()){toast("Сначала установи PIN-код ниже");}else{boolean next=!p.getBoolean("enabled",false);p.edit().putBoolean("enabled",next).apply();getSharedPreferences("echo_settings",MODE_PRIVATE).edit().putBoolean("app_pin_enabled",next).apply();toast(next?"PIN включён":"PIN выключен");showAppLockSettings();}});
        simpleSettingRow("Установить или изменить PIN","PIN из 4–8 цифр",()->{EditText e=edit("Новый PIN-код",true);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);new android.app.AlertDialog.Builder(this).setTitle("Настроить PIN").setMessage("Выбери код длиной от 4 до 8 цифр.").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{String pin=e.getText().toString();if(!pin.matches("[0-9]{4,8}")){toast("PIN должен содержать 4–8 цифр");return;}p.edit().putString("pin_hash",pinHash(pin)).putBoolean("enabled",true).apply();getSharedPreferences("echo_settings",MODE_PRIVATE).edit().putBoolean("app_pin_enabled",true).apply();toast("PIN настроен");showAppLockSettings();}).show();});
        simpleSettingRow("Заблокировать сейчас","Проверить PIN на этом устройстве",()->showPinUnlock(()->showAppLockSettings()));
        simpleSettingRow("Вход по биометрии",p.getBoolean("biometric",false)?"Включён":"Выключен",()->{if(!biometricAvailable()){toast("Биометрия недоступна: настрой отпечаток или лицо в системе (Android 10+)");return;}p.edit().putBoolean("biometric",!p.getBoolean("biometric",false)).apply();showAppLockSettings();});simpleSettingRow("Автоблокировка","Через: "+lockAfterLabel(p.getLong("lock_after_ms",30000L)),()->{final long[] vals={0L,30000L,60000L,300000L};new android.app.AlertDialog.Builder(this).setTitle("Блокировать через").setItems(new String[]{"Сразу","30 секунд","1 минута","5 минут"},(dd,w)->{p.edit().putLong("lock_after_ms",vals[w]).apply();showAppLockSettings();}).show();});TextView note=tv("PIN хранится в виде SHA-256-хеша на устройстве. Приложение блокируется при запуске и после возврата из фона через выбранное время.",12,MUTED);content.addView(note,margins(14,12,14,8,-2));
    }

    // ---- App lock: auto-lock on start/background + biometrics (ECHO 0.10) ----
    long pausedAt=0;boolean lockShowing=false,externalLaunch=false;
    @Override public void startActivityForResult(Intent intent,int requestCode,Bundle options){externalLaunch=true;super.startActivityForResult(intent,requestCode,options);}
    void maybeAutoLock(){
        boolean ext=externalLaunch;externalLaunch=false;
        if(uid==null||lockShowing||ext)return;
        android.content.SharedPreferences p=getSharedPreferences("echo_app_lock",MODE_PRIVATE);
        if(!p.getBoolean("enabled",false)||p.getString("pin_hash","").isEmpty())return;
        long after=p.getLong("lock_after_ms",30000L);
        long away=pausedAt==0?Long.MAX_VALUE:android.os.SystemClock.elapsedRealtime()-pausedAt;
        if(away<after)return;
        lockShowing=true;
        showPinUnlock(()->{lockShowing=false;pausedAt=android.os.SystemClock.elapsedRealtime();});
    }
    @android.annotation.SuppressLint("NewApi")
    boolean biometricAvailable(){
        if(android.os.Build.VERSION.SDK_INT<29)return false;
        try{android.hardware.biometrics.BiometricManager bm=getSystemService(android.hardware.biometrics.BiometricManager.class);return bm!=null&&bm.canAuthenticate()==android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS;}catch(Exception e){return false;}
    }
    @android.annotation.SuppressLint("NewApi")
    void biometricUnlock(Runnable ok){
        if(android.os.Build.VERSION.SDK_INT<28){toast("Биометрия недоступна на этой версии Android");return;}
        try{
            android.hardware.biometrics.BiometricPrompt bp=new android.hardware.biometrics.BiometricPrompt.Builder(this)
                .setTitle("Разблокировать Echo").setNegativeButton("PIN-код",getMainExecutor(),(d,w)->{}).build();
            bp.authenticate(new android.os.CancellationSignal(),getMainExecutor(),new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback(){
                @Override public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult r){ok.run();}
            });
        }catch(Exception e){toast("Биометрия недоступна: "+e.getMessage());}
    }
    String lockAfterLabel(long ms){return ms<=0?"сразу":ms<60000?(ms/1000)+" сек":(ms/60000)+" мин";}
    String pinHash(String pin){try{byte[] b=java.security.MessageDigest.getInstance("SHA-256").digest(pin.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(java.util.Locale.ROOT,"%02x",x));return s.toString();}catch(Exception e){return pin;}}
    void showPinUnlock(Runnable success){
        android.content.SharedPreferences p=getSharedPreferences("echo_app_lock",MODE_PRIVATE);String expected=p.getString("pin_hash","");boolean bioOn=p.getBoolean("biometric",false)&&biometricAvailable();if(expected.isEmpty()){simpleInfo("Защита PIN-кодом","Сначала установи PIN-код в настройках защиты.");return;}EditText e=edit("PIN-код",true);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setTitle("Echo заблокирован").setMessage("Введи PIN-код для продолжения.").setView(e).setCancelable(false).setPositiveButton("Разблокировать",null).setNeutralButton(bioOn?"Биометрия":null,null).create();dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(x->{if(pinHash(e.getText().toString()).equals(expected)){dialog.dismiss();success.run();}else{e.setText("");e.setError("Неверный PIN");}}));dialog.show();if(bioOn){android.widget.Button nb=dialog.getButton(-3);if(nb!=null)nb.setOnClickListener(x->biometricUnlock(()->{dialog.dismiss();success.run();}));biometricUnlock(()->{dialog.dismiss();success.run();});}
    }

    void showStories(){
        clear("Echo Stories 2.0");addPageBack(()->showChats());
        TextView intro=tv("Текстовые истории исчезают через 24 часа. Выбери фон, напиши короткое обновление и поделись настроением.",13,MUTED);intro.setPadding(dp(14),dp(6),dp(14),dp(10));content.addView(intro);
        Button create=btn(ico("＋  Создать историю"));create.setBackground(glassAccent(BLUE,18));content.addView(create,margins(12,8,12,12,52));
        create.setOnClickListener(v->newStoryDialog());
        if(uid!=null)db.collection("users").document(uid).collection("stories").orderBy("createdAt",Query.Direction.DESCENDING).limit(30).get().addOnSuccessListener(snap->{
            if(snap.isEmpty()){TextView empty=tv("Пока нет историй. Создай первую!",15,MUTED);empty.setGravity(Gravity.CENTER);content.addView(empty,margins(12,20,12,10,70));}
            for(DocumentSnapshot d:snap.getDocuments()){
                Long expiry=d.getLong("expiresAt");if(expiry!=null&&expiry<System.currentTimeMillis())continue;String body=d.getString("text");Long storedColor=d.getLong("backgroundColor");int color=storedColor==null?CARD2:storedColor.intValue();
                LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(16),dp(14),dp(16),dp(12));card.setBackground(bg(color,22));
                TextView author=tv("Твоя история  ·  24 часа",12,Color.WHITE);card.addView(author,new LinearLayout.LayoutParams(-1,dp(24)));
                TextView text=tv(body==null?"История":body,17,Color.WHITE);text.setGravity(Gravity.CENTER_VERTICAL);text.setMaxLines(5);card.addView(text,new LinearLayout.LayoutParams(-1,-2));
                TextView expiryLabel=tv(expiry==null?"Срок действия: 24 часа":"Истекает через "+Math.max(1,(expiry-System.currentTimeMillis())/3600000)+" ч.",11,Color.WHITE);card.addView(expiryLabel,new LinearLayout.LayoutParams(-1,dp(24)));
                LinearLayout actions=new LinearLayout(this);Button react=btn(ico("❤️ Реакция"));Button delete=btn("Удалить");actions.addView(react,new LinearLayout.LayoutParams(0,dp(42),1));actions.addView(delete,new LinearLayout.LayoutParams(0,dp(42),1));card.addView(actions);content.addView(card,margins(12,4,12,8,-2));
                react.setOnClickListener(v->{String[] emojis={"❤️","🔥","😂","👍","😮"};new android.app.AlertDialog.Builder(this).setTitle("Реакция на историю").setItems(emojis,(dlg,which)->db.collection("users").document(uid).collection("stories").document(d.getId()).collection("reactions").document(uid).set(new HashMap<String,Object>(){{put("emoji",emojis[which]);put("uid",uid);put("createdAt",FieldValue.serverTimestamp());}}).addOnSuccessListener(ok->toast("Реакция сохранена")).addOnFailureListener(err->toast("Не удалось сохранить реакцию: "+authMessage(err)))).show();});
                delete.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Удалить историю?").setMessage("Это действие нельзя отменить.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(dlg,w)->db.collection("users").document(uid).collection("stories").document(d.getId()).delete().addOnSuccessListener(ok->{toast("История удалена");showStories();}).addOnFailureListener(err->toast("Не удалось удалить: "+authMessage(err)))).show());
            }
        }).addOnFailureListener(e->toast("Не удалось загрузить истории: "+authMessage(e)));
        TextView note=tv("В 0.9.0 доступны текстовые истории с цветными фонами и реакциями. Фото/видео не добавляем: Firebase Storage не используется.",12,MUTED);note.setPadding(dp(14),dp(8),dp(14),dp(8));content.addView(note);
    }

    void newStoryDialog(){
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(4));
            EditText e=edit("Что нового?",false);e.setSingleLine(false);e.setMinLines(3);e.setMaxLines(6);box.addView(e,new LinearLayout.LayoutParams(-1,dp(110)));
            String[] colors={"Синий","Фиолетовый","Розовый","Зелёный","Тёмный"};int[] values={Color.rgb(35,115,220),Color.rgb(119,75,220),Color.rgb(220,65,135),Color.rgb(24,145,110),Color.rgb(35,43,55)};final int[] selected={0};
            Spinner spinner=new Spinner(this);spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,colors));box.addView(spinner,new LinearLayout.LayoutParams(-1,dp(48)));spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,android.view.View v,int pos,long id){selected[0]=pos;}public void onNothingSelected(android.widget.AdapterView<?> a){}});
            TextView preview=tv("Предпросмотр истории",16,TEXT);preview.setGravity(Gravity.CENTER);preview.setPadding(dp(12),dp(16),dp(12),dp(16));preview.setBackground(bg(values[0],20));box.addView(preview,new LinearLayout.LayoutParams(-1,dp(76)));spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,android.view.View v,int pos,long id){selected[0]=pos;preview.setBackground(bg(values[pos],20));}public void onNothingSelected(android.widget.AdapterView<?> a){}});
            new android.app.AlertDialog.Builder(this).setTitle("Новая история").setView(box).setNegativeButton("Отмена",null).setPositiveButton("Опубликовать",(d,w)->{String body=e.getText().toString().trim();if(body.isEmpty()){toast("Напиши текст истории");return;}if(uid==null)return;Map<String,Object> story=new HashMap<>();story.put("text",body);story.put("owner",uid);story.put("backgroundColor",values[selected[0]]);story.put("createdAt",FieldValue.serverTimestamp());story.put("expiresAt",System.currentTimeMillis()+24L*60*60*1000);story.put("reactionCount",0);db.collection("users").document(uid).collection("stories").add(story).addOnSuccessListener(x->{toast("История опубликована на 24 часа");showStories();}).addOnFailureListener(err->toast("Не удалось опубликовать: "+authMessage(err)));}).show();
    }
    void showEasterEggs(){
        clear("Пасхалки Echo");addPageBack(()->showSettings());
        TextView title=tv("Секретный раздел Echo",24,TEXT);title.setTypeface(null,Typeface.BOLD);title.setGravity(Gravity.CENTER);content.addView(title,margins(12,20,12,8,50));
        TextView copy=tv("Нажми на логотип Echo 10 раз подряд, чтобы открыть скрытую пасхалку. В будущих версиях здесь появятся секретные темы и достижения.",15,MUTED);copy.setGravity(Gravity.CENTER);content.addView(copy,margins(18,8,18,8,90));
        Button test=btn("Проверить пасхалку");content.addView(test,margins(20,8,20,8,48));test.setOnClickListener(v->{getSharedPreferences("echo_settings",MODE_PRIVATE).edit().putInt("easter_egg_count",getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("easter_egg_count",0)+1).apply();new android.app.AlertDialog.Builder(this).setTitle("ХАЙП").setMessage("Ты нашёл секрет Echo! Новые секреты появятся в следующих обновлениях.").setPositiveButton("Круто",null).show();});
    }

    void showSettings(){
        clear("Настройки");
        if(appHeader!=null)appHeader.setVisibility(android.view.View.GONE);
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12),0,dp(12),dp(18));
        scroll.addView(page);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        page.addView(topBar(true,""));
        FirebaseUser user=auth.getCurrentUser();
        String phone=user!=null&&user.getPhoneNumber()!=null&&!user.getPhoneNumber().isEmpty()?user.getPhoneNumber():(user!=null&&user.getEmail()!=null?user.getEmail():"Аккаунт Echo");
        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(0,dp(4),0,dp(16));
        LinearLayout.LayoutParams heroAv=new LinearLayout.LayoutParams(dp(96),dp(96));
        heroAv.gravity=Gravity.CENTER_HORIZONTAL;
        hero.addView(avatarWithCamera(96,()->chooseProfilePhoto()),heroAv);
        TextView pn=tv(profileName,21,TEXT);
        pn.setTypeface(null,Typeface.BOLD);
        pn.setGravity(Gravity.CENTER);
        hero.addView(pn,margins(0,10,0,0,32));
        TextView handle=tv(phone+"  •  @"+profileUsername,13,MUTED);
        handle.setGravity(Gravity.CENTER);
        hero.addView(handle,new LinearLayout.LayoutParams(-1,dp(24)));
        hero.setOnClickListener(v->showProfile());
        page.addView(hero,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout card=settingsCard(page);
        addSettingTo(card,"account","Аккаунт","Номер, почта, устройства",()->showAccountSettings());
        addSettingTo(card,"switch","Сменить аккаунт",AccountStore.all(this).size()>1?"Сохранено аккаунтов: "+AccountStore.all(this).size():"Добавить или переключить аккаунт",()->showAccounts());
        addSettingTo(card,"chat_settings","Настройки чатов","Обои, папки, перевод, анимации",()->showChatSettings());
        addSettingTo(card,"privacy","Конфиденциальность","Блокировки, PIN-код, статус",()->showPrivacySettings());
        addSettingTo(card,"notifications","Уведомления","Звуки, звонки, счётчик сообщений",()->showNotificationSettings());
        addSettingTo(card,"storage","Данные и память","Медиафайлы и энергосбережение",()->showDataSettings());
        addSettingTo(card,"language","Язык","Русский",()->showLanguageSettings());

        LinearLayout plus=settingsCard(page);
        addSettingTo(plus,"plus","Echo Plus","Темы и персонализация",()->showEchoPlus());
        addSettingTo(plus,"service","Служебные уведомления","Профиль Echo, звук и чат",()->showServiceProfile());
        addSettingTo(plus,"stars","Звёзды Echo","Баланс, бонус и подарки",()->showStars());
        addSettingTo(plus,"business","Echo для бизнеса","Профиль компании и приветствие",()->showBusiness());

        addSectionLabel(page,"Помощь");
        LinearLayout help=settingsCard(page);
        addSettingTo(help,"help","Задать вопрос","Напиши команде Echo",()->simpleInfo("Задать вопрос","Напиши в чат «Echo Messenger» или владельцу Echo — мы ответим, как только сможем."));
        addSettingTo(help,"faq","Вопросы об Echo","Ответы на частые вопросы",()->simpleInfo("Вопросы об Echo","Echo Messenger — мессенджер в бета-разработке. Вход по e-mail или номеру, личные и групповые чаты, каналы, сообщества и истории."));
        addSettingTo(help,"features","Возможности Echo","Что нового в 0.9.1 Beta",()->simpleInfo("Возможности Echo","Смена аккаунтов, новые иконки вместо эмодзи, Echo Assist Beta, темы Echo Plus и текстовые истории."));
        addSettingTo(help,"privacy","Политика конфиденциальности","Как Echo работает с данными",()->simpleInfo("Политика конфиденциальности","Полный текст политики будет опубликован к релизу 1.0."));

        TextView ver=tv("Echo Messenger v0.9.1 (10) · Android",12,MUTED);ver.setOnClickListener(v->showEasterEggs());
        ver.setGravity(Gravity.CENTER);
        page.addView(ver,margins(0,0,0,6,36));
        LinearLayout out=settingsCard(page);
        addSettingTo(out,"logout","Выйти из аккаунта","Завершить текущий сеанс",()->confirmLogout());
    }
    LinearLayout settingsCard(LinearLayout page){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(4),dp(6),dp(4),dp(6));
        card.setBackground(glass(18));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.setMargins(0,0,0,dp(12));
        page.addView(card,cp);
        return card;
    }
    void addSectionLabel(LinearLayout page,String text){
        TextView t=tv(text,14,Color.rgb(98,170,235));
        t.setTypeface(null,Typeface.BOLD);
        t.setPadding(dp(14),0,dp(14),0);
        page.addView(t,new LinearLayout.LayoutParams(-1,dp(34)));
    }
    int settingsIconRes(String key){
        switch(key){
            case "account": return R.drawable.ic_settings_account;
            case "switch": return R.drawable.ic_switch;
            case "chat_settings": return R.drawable.ic_settings_chat;
            case "privacy": return R.drawable.ic_settings_privacy;
            case "notifications": return R.drawable.ic_settings_notifications;
            case "storage": return R.drawable.ic_settings_storage;
            case "folders": return R.drawable.ic_settings_folder;
            case "devices": return R.drawable.ic_settings_devices;
            case "battery": return R.drawable.ic_settings_battery;
            case "language": return R.drawable.ic_settings_language;
            case "plus": return R.drawable.ic_gem;
            case "service": return R.drawable.ic_bell;
            case "stars": return R.drawable.ic_star;
            case "business": return R.drawable.ic_briefcase;
            case "gift": return R.drawable.ic_gift;
            case "assist": case "features": return R.drawable.ic_sparkle;
            case "bots": return R.drawable.ic_bot;
            case "help": return R.drawable.ic_help;
            case "faq": return R.drawable.ic_info;
            case "logout": return R.drawable.ic_settings_logout;
            default: return R.drawable.ic_settings_info;
        }
    }
    int settingsColor(String key){
        switch(key){
            case "account": return Color.rgb(48,148,232);
            case "chat_settings": return Color.rgb(240,150,45);
            case "switch": return Color.rgb(48,148,232);
            case "privacy": return Color.rgb(84,190,72);
            case "notifications": return Color.rgb(228,84,84);
            case "storage": return Color.rgb(58,122,232);
            case "folders": return Color.rgb(48,148,232);
            case "devices": return Color.rgb(38,186,186);
            case "battery": return Color.rgb(238,126,48);
            case "language": return Color.rgb(150,92,228);
            case "plus": return Color.rgb(150,92,228);
            case "service": return Color.rgb(51,144,236);
            case "stars": return Color.rgb(240,160,40);
            case "assist": return Color.rgb(228,84,140);
            case "bots": return Color.rgb(38,186,186);
            case "help": return Color.rgb(240,150,45);
            case "faq": return Color.rgb(48,148,232);
            case "features": return Color.rgb(150,92,228);
            case "business": return Color.rgb(226,70,110);
            case "gift": return Color.rgb(240,150,45);
            case "logout": return Color.rgb(228,84,84);
            default: return Color.rgb(48,148,232);
        }
    }
    void addSettingTo(LinearLayout parent,String icon,String name,String subtitle,Runnable action){
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10),dp(4),dp(10),dp(4));
        ImageView glyph=new ImageView(this);
        glyph.setImageResource(settingsIconRes(icon));
        glyph.setColorFilter(Color.WHITE);
        glyph.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        glyph.setPadding(dp(9),dp(9),dp(9),dp(9));
        glyph.setBackground(bg(settingsColor(icon),12));
        row.addView(glyph,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout labels=new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(14),0,0,0);
        TextView titleText=tv(name,16,TEXT);
        titleText.setTypeface(null,Typeface.BOLD);
        titleText.setSingleLine(true);
        TextView sub=tv(subtitle,12,MUTED);
        sub.setSingleLine(true);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(titleText,new LinearLayout.LayoutParams(-1,dp(22)));
        labels.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
        row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v->action.run());
        parent.addView(row,margins(0,2,0,2,56));
    }
    // ===== Account switching =====
    void rememberAccount(){
        FirebaseUser u=auth.getCurrentUser();
        if(u==null)return;
        String pw=lastEmailPw;lastEmailPw=null;
        if(u.getEmail()==null||u.getEmail().isEmpty())pw=null;
        AccountStore.save(this,u.getUid(),u.getEmail()==null?"":u.getEmail(),u.getPhoneNumber()==null?"":u.getPhoneNumber(),profileName,profileUsername,pw);
    }
    void detachSession(){
        if(listener!=null){listener.remove();listener=null;}
        if(listener2!=null){listener2.remove();listener2=null;}
    }
    void setOfflinePresence(){
        if(uid==null||db==null)return;
        Map<String,Object> state=new HashMap<>();state.put("online",false);state.put("lastSeen",FieldValue.serverTimestamp());
        db.collection("users").document(uid).set(state,SetOptions.merge());
    }
    void resetSessionState(){
        myChats.clear();findResults.clear();unread.clear();verifiedCache.clear();
        generalLast="Пока нет сообщений — напиши первым";generalTime="";chatQuery="";chatTab=0;
    }
    void switchAccount(AccountStore.Entry e){
        if(e.uid.equals(uid))return;
        rememberAccount();
        if(!e.canSwitchSilently()){
            detachSession();setOfflinePresence();auth.signOut();uid=null;content=null;
            prefillEmail=e.email==null?"":e.email;startOnPhone=e.email==null||e.email.isEmpty();
            showAuth();toast("Войди в аккаунт «"+e.label()+"»");
            return;
        }
        toast("Переключаю на «"+e.label()+"»…");
        setOfflinePresence();
        auth.signInWithEmailAndPassword(e.email,e.pw).addOnCompleteListener(t->{
            if(!t.isSuccessful()){
                Exception ex=t.getException();
                if(ex instanceof FirebaseAuthInvalidCredentialsException||ex instanceof com.google.firebase.auth.FirebaseAuthInvalidUserException){
                    AccountStore.forgetPassword(this,e.uid);
                    detachSession();auth.signOut();uid=null;content=null;prefillEmail=e.email;
                    showAuth();toast("Пароль изменился — войди в этот аккаунт заново");
                }else toast("Не удалось переключиться: "+authMessage(ex));
                return;
            }
            detachSession();resetSessionState();authDone();
        });
    }
    void addAccount(){
        rememberAccount();detachSession();setOfflinePresence();
        auth.signOut();uid=null;content=null;prefillEmail="";
        showAuth();toast("Войди в другой аккаунт или создай новый");
    }
    void confirmRemoveAccount(AccountStore.Entry e){
        new android.app.AlertDialog.Builder(this).setTitle("Убрать аккаунт?").setMessage("«"+e.label()+"» исчезнет из списка на этом устройстве. Сам аккаунт не удаляется.")
            .setNegativeButton("Отмена",null).setPositiveButton("Убрать",(d,w)->{AccountStore.remove(this,e.uid);showAccounts();}).show();
    }
    void showAccounts(){
        clear("Аккаунты");
        addPageBack(()->showSettings());
        rememberAccount();
        ScrollView scroll=new ScrollView(this);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12),dp(4),dp(12),dp(18));
        scroll.addView(page);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        java.util.List<AccountStore.Entry> list=AccountStore.all(this);
        LinearLayout card=addCard(page);
        for(AccountStore.Entry e:list){
            boolean cur=e.uid.equals(uid);
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(4),dp(8),dp(4),dp(8));
            row.addView(avatar(e.label(),dp(44)),new LinearLayout.LayoutParams(dp(44),dp(44)));
            LinearLayout col=new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(12),0,0,0);
            TextView n=tv(e.label(),16,TEXT);n.setTypeface(null,Typeface.BOLD);n.setSingleLine(true);n.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(n);
            String sub=cur?"Текущий аккаунт":(e.canSwitchSilently()?e.subtitle():"Нужен вход"+(e.subtitle().isEmpty()?"":"  •  "+e.subtitle()));
            TextView st=tv(sub.isEmpty()?"Аккаунт Echo":sub,12,cur?ACCENT:MUTED);st.setSingleLine(true);st.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(st);
            row.addView(col,new LinearLayout.LayoutParams(0,-2,1));
            ImageView end=new ImageView(this);
            end.setImageResource(cur?R.drawable.ic_check:R.drawable.ic_close);
            end.setColorFilter(cur?ACCENT:MUTED);
            end.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            end.setPadding(dp(10),dp(10),dp(10),dp(10));
            row.addView(end,new LinearLayout.LayoutParams(dp(42),dp(42)));
            if(!cur){
                row.setOnClickListener(v->switchAccount(e));
                end.setOnClickListener(v->confirmRemoveAccount(e));
                row.setOnLongClickListener(v->{confirmRemoveAccount(e);return true;});
            }
            card.addView(row,new LinearLayout.LayoutParams(-1,-2));
        }
        Button add=btn(ico("＋  Добавить аккаунт"));
        add.setBackground(glassAccent(BLUE,18));
        add.setOnClickListener(v->addAccount());
        page.addView(add,margins(0,4,0,10,52));
        TextView note=tv("Аккаунты с входом по почте переключаются в одно касание: пароль хранится только на этом устройстве в зашифрованном виде (Android Keystore). Для аккаунтов по телефону нужно подтвердить вход кодом из SMS. Нажми на значок справа, чтобы убрать аккаунт из списка.",12,MUTED);
        note.setPadding(dp(8),dp(4),dp(8),dp(4));
        page.addView(note,new LinearLayout.LayoutParams(-1,-2));
    }
    void addSavedAccountsToAuth(){
        java.util.List<AccountStore.Entry> list=AccountStore.all(this);
        if(list.isEmpty())return;
        TextView h=tv("Сохранённые аккаунты",13,MUTED);
        h.setPadding(dp(4),dp(18),dp(4),dp(4));
        content.addView(h,new LinearLayout.LayoutParams(-1,-2));
        for(AccountStore.Entry e:list){
            Button b=btn(e.label()+(e.subtitle().isEmpty()?"":"  ·  "+e.subtitle()));
            b.setSingleLine(true);b.setEllipsize(android.text.TextUtils.TruncateAt.END);
            b.setOnClickListener(v->switchAccount(e));
            content.addView(b,margins(0,4,0,4,52));
        }
    }
    void simpleInfo(String titleText,String message){new android.app.AlertDialog.Builder(this).setTitle(titleText).setMessage(message).setPositiveButton("Понятно",(d,w)->{}).show();}
    String deviceSessionId(){String id=android.provider.Settings.Secure.getString(getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);return id==null||id.trim().isEmpty()?"android-device":id;}
    void registerPushAndSession(){
        if(uid==null||auth==null||auth.getCurrentUser()==null)return;
        final String currentUid=uid; final String sessionId=deviceSessionId();
        com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token->{
            if(uid==null||!uid.equals(currentUid))return;
            Map<String,Object> userData=new HashMap<>();userData.put("fcmToken",token);userData.put("fcmTokenUpdatedAt",FieldValue.serverTimestamp());
            db.collection("users").document(currentUid).set(userData,SetOptions.merge());
            Map<String,Object> session=new HashMap<>();session.put("deviceId",sessionId);session.put("deviceName",android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL);session.put("platform","Android");session.put("fcmToken",token);session.put("lastActiveAt",FieldValue.serverTimestamp());session.put("appVersion","0.5.0 Beta");
            db.collection("users").document(currentUid).collection("sessions").document(sessionId).set(session,SetOptions.merge());
        }).addOnFailureListener(e->android.util.Log.w("EchoFCM","Could not register FCM token",e));
    }
    void showSessions(){
        clear("Устройства");addPageBack(()->showAccountSettings());
        TextView intro=tv("Сессия текущего устройства и состояние регистрации push-уведомлений.",13,MUTED);content.addView(intro,wrapMargins(14,4,14,10));
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(glass(20));
        TextView device=tv(android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL,17,TEXT);device.setTypeface(null,Typeface.BOLD);card.addView(device);TextView details=tv("Android · ID устройства: "+deviceSessionId(),12,MUTED);card.addView(details,wrapMargins(0,4,0,8));content.addView(card,margins(12,4,12,8,100));
        if(uid!=null)db.collection("users").document(uid).collection("sessions").document(deviceSessionId()).get().addOnSuccessListener(d->{if(d.exists()){Object last=d.get("lastActiveAt");details.setText("Android · Push зарегистрирован\nID устройства: "+deviceSessionId());}else details.setText("Android · Сессия ещё не зарегистрирована. Перезапусти приложение при подключённом интернете.");});
        Button refresh=btn("Обновить регистрацию push");content.addView(refresh,margins(12,6,12,6,50));refresh.setOnClickListener(v->{registerPushAndSession();toast("Запрошена регистрация FCM-токена");});
        Button logout=btn("Выйти с этого устройства");content.addView(logout,margins(12,6,12,6,50));logout.setOnClickListener(v->confirmLogout());
        TextView note=tv("Важно: Android Firebase Auth не позволяет приложению безопасно перечислить и отозвать все остальные входы самостоятельно. Здесь отображается текущая сессия; глобальный отзыв сессий требует серверной функции.",12,MUTED);content.addView(note,wrapMargins(14,10,14,8));
    }
    void showAccountSettings(){clear("Аккаунт");addPageBack(()->showSettings());FirebaseUser u=auth.getCurrentUser();String em=u!=null&&u.getEmail()!=null?u.getEmail():"Не привязана";addSetting("✉","Электронная почта",em);addSetting("📱","Номер телефона",u!=null&&u.getPhoneNumber()!=null?u.getPhoneNumber():"Не привязан");addSetting("🔐","Подтверждение почты",u!=null&&u.isEmailVerified()?"Подтверждена":"Не подтверждена");simpleSettingRow("Сменить пароль","Отправим ссылку на почту аккаунта",()->{FirebaseUser cu=auth.getCurrentUser();if(cu==null||cu.getEmail()==null||cu.getEmail().isEmpty()){simpleInfo("Сменить пароль","К аккаунту не привязана почта. Вход по номеру телефона не требует пароля.");return;}String address=cu.getEmail();new android.app.AlertDialog.Builder(this).setTitle("Сменить пароль").setMessage("Отправить ссылку для смены пароля на "+address+"?").setNegativeButton("Отмена",null).setPositiveButton("Отправить",(dlg,w)->auth.sendPasswordResetEmail(address).addOnCompleteListener(t->toast(t.isSuccessful()?"Письмо отправлено на "+address:authMessage(t.getException())))).show();});simpleSettingRow("Сменить аккаунт","Переключиться на другой сохранённый аккаунт",()->showAccounts());simpleSettingRow("Устройства","Управление активными сеансами",()->showSessions());Button logout=btn("Выйти из аккаунта");content.addView(logout,margins(12,18,12,8,54));logout.setOnClickListener(v->confirmLogout());}
    String snowLevelName(){return new String[]{"Лёгкий","Обычный","Метель"}[Math.max(0,Math.min(2,getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("snow_level",1)))];}
    void showChatSettings(){clear("Настройки чатов");addPageBack(()->showSettings());simpleSettingRow("Обои чата","Сейчас: "+wallpaperName(),()->showWallpaperPicker());addPreferenceSwitch("Предпросмотр сообщений","Показывать текст сообщений в списке", "preview_messages",true);addPreferenceSwitch("Liquid Glass","Стеклянные панели и мягкие акценты","liquid_glass",true);addPreferenceSwitch("Анимации","Плавные переходы интерфейса","chat_animations",true);addPreferenceSwitch("Зимний снегопад","Падающий снег на заднем плане","winter_snow",true);addPreferenceSwitch("Зимний декор","Иней, сосульки, сугробы и снежные шапки","winter_frost",true);simpleSettingRow("Интенсивность снега",snowLevelName(),()->new android.app.AlertDialog.Builder(this).setTitle("Интенсивность снега").setSingleChoiceItems(new String[]{"Лёгкий","Обычный","Метель"},getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("snow_level",1),(dlg,which)->{getSharedPreferences("echo_settings",MODE_PRIVATE).edit().putInt("snow_level",which).apply();dlg.dismiss();showChatSettings();}).setNegativeButton("Отмена",null).show());simpleSettingRow("Устроить метель","Порыв ветра: снег летит в сторону",()->{if(windowSnow!=null)windowSnow.gust();});addPreferenceSwitch("Звук отправки","Звук при отправке сообщений","send_sound",true);simpleSettingRow("Размер текста","Обычный",()->new android.app.AlertDialog.Builder(this).setTitle("Размер текста").setItems(new String[]{"Маленький","Обычный","Большой"},(d,w)->toast("Размер текста: "+new String[]{"Маленький","Обычный","Большой"}[w])).show());simpleSettingRow("Папки с чатами","Сортировка чатов по папкам",()->showChatFolders());simpleSettingRow("Echo Translate","Перевод сообщений через Cloud Functions",()->showEchoTranslate());simpleSettingRow("Отложенные сообщения","Просмотр и отмена запланированной отправки",()->showScheduledMessages());}
    void showEchoBots(){
        clear("Echo Bots");addPageBack(()->showChats());
        TextView intro=tv("Встроенные боты Echo",20,TEXT);intro.setTypeface(null,Typeface.BOLD);content.addView(intro,margins(12,8,12,6,40));
        content.addView(tv("Команды работают локально и не требуют Firebase Storage.",13,MUTED),wrapMargins(12,0,12,12));
        String[] names={"/help — список команд","/time — текущее время","/echo текст — повторить текст","/dice — бросить кубик","/coin — подбросить монету","/id — показать мой ID"};
        for(String n:names){Button b=btn(n);content.addView(b,margins(12,4,12,4,48));b.setOnClickListener(v->{String result;if(n.startsWith("/help"))result="Команды: /time, /echo текст, /dice, /coin, /id";else if(n.startsWith("/time"))result=new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date());else if(n.startsWith("/echo")){EditText e=edit("Текст для Echo",false);new android.app.AlertDialog.Builder(this).setTitle("Echo Bot").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Ответить",(d,w)->simpleInfo("Echo Bot",e.getText().toString())).show();return;}else if(n.startsWith("/dice"))result="Выпало: "+(1+(int)(Math.random()*6));else if(n.startsWith("/coin"))result=Math.random()<0.5?"Орёл":"Решка";else result="Твой Echo ID: "+(uid==null?"не выполнен вход":uid);simpleInfo("Echo Bot",result);});}
    }
    void showEchoTranslate(){
        clear("Echo Translate");addPageBack(()->showChatSettings());
        EditText source=edit("Введи текст для перевода",false);source.setSingleLine(false);source.setMinLines(4);content.addView(source,margins(12,12,12,8,130));
        String[] langs={"English","Russian","Ukrainian","Chinese","Spanish","French","German","Japanese"};String[] codes={"en","ru","uk","zh","es","fr","de","ja"};final int[] selected={0};Button language=btn("Язык: English");content.addView(language,margins(12,4,12,8,48));language.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Перевести на").setSingleChoiceItems(langs,selected[0],(d,w)->{selected[0]=w;language.setText("Язык: "+langs[w]);d.dismiss();}).show());
        Button translate=btn("Перевести");content.addView(translate,margins(12,4,12,8,50));TextView output=tv("Здесь появится перевод",15,MUTED);output.setPadding(dp(14),dp(12),dp(14),dp(12));output.setBackground(glass(16));content.addView(output,margins(12,6,12,8,150));
        translate.setOnClickListener(v->{String text=source.getText().toString().trim();if(text.isEmpty()){toast("Введи текст");return;}translate.setEnabled(false);Map<String,Object> data=new HashMap<>();data.put("text",text);data.put("target",codes[selected[0]]);com.google.firebase.functions.FirebaseFunctions.getInstance().getHttpsCallable("translateText").call(data).addOnSuccessListener(r->{translate.setEnabled(true);Object value=((Map<?,?>)r.getData()).get("translatedText");output.setText(value==null?"Перевод не получен":String.valueOf(value));output.setTextColor(TEXT);}).addOnFailureListener(e->{translate.setEnabled(true);output.setText("Не удалось перевести. Проверь развёртывание функции и включение Cloud Translation API.\n"+authMessage(e));});});
    }
    void showEchoCalls(){
        clear("Echo Calls");addPageBack(()->showChats());
        content.addView(tv("Приглашения к аудиозвонку",19,TEXT),margins(12,10,12,6,40));
        EditText target=edit("UID пользователя",false);content.addView(target,margins(12,8,12,8,54));
        Button call=btn("Отправить приглашение");content.addView(call,margins(12,4,12,8,50));
        call.setOnClickListener(v->{String other=target.getText().toString().trim();if(uid==null||other.length()<10||other.equals(uid)){toast("Укажи корректный UID другого пользователя");return;}Map<String,Object> c=new HashMap<>();c.put("callerUid",uid);c.put("calleeUid",other);c.put("status","ringing");c.put("createdAt",FieldValue.serverTimestamp());c.put("kind","audio");db.collection("calls").add(c).addOnSuccessListener(r->simpleInfo("Echo Calls","Приглашение создано. Для работы аудиопотока требуется WebRTC-соединение; сейчас реализована серверная сигнализация приглашения, а не передача звука внутри приложения.")).addOnFailureListener(e->toast("Не удалось создать вызов: "+authMessage(e)));});
        Button incoming=btn("Проверить входящие вызовы");content.addView(incoming,margins(12,8,12,8,50));incoming.setOnClickListener(v->{if(uid==null)return;db.collection("calls").whereEqualTo("calleeUid",uid).whereEqualTo("status","ringing").get().addOnSuccessListener(s->{if(s.isEmpty()){toast("Входящих вызовов нет");return;}String[] labels=new String[s.size()];java.util.List<DocumentSnapshot> docs=s.getDocuments();for(int i=0;i<docs.size();i++)labels[i]="Вызов от "+docs.get(i).getString("callerUid");new android.app.AlertDialog.Builder(this).setTitle("Входящие вызовы").setItems(labels,(d,w)->{DocumentSnapshot doc=docs.get(w);new android.app.AlertDialog.Builder(this).setTitle("Вызов").setItems(new String[]{"Принять приглашение","Отклонить"},(dd,ww)->doc.getReference().update("status",ww==0?"accepted":"declined").addOnSuccessListener(x->toast(ww==0?"Приглашение принято":"Вызов отклонён"))).show();}).show();}).addOnFailureListener(e->toast(authMessage(e)));});
        content.addView(tv("Важно: эта версия создаёт и принимает приглашения через Firestore. Реальный звук в приложении требует интеграции WebRTC и ICE/STUN/TURN-конфигурации.",12,MUTED),wrapMargins(12,12,12,8));
    }
    void showBlockedUsers(){
        clear("Заблокированные пользователи");addPageBack(()->showPrivacySettings());if(uid==null)return;
        db.collection("users").document(uid).get().addOnSuccessListener(s->{java.util.List<String> ids=(java.util.List<String>)s.get("blockedUsers");if(ids==null||ids.isEmpty()){content.addView(tv("Нет заблокированных пользователей",14,MUTED),margins(12,20,12,8,48));return;}for(String id:ids){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(12),dp(8));row.setBackground(glass(16));TextView label=tv(id,13,TEXT);row.addView(label,new LinearLayout.LayoutParams(0,dp(44),1));Button unblock=btn("Разблокировать");row.addView(unblock);unblock.setOnClickListener(v->db.collection("users").document(uid).update("blockedUsers",FieldValue.arrayRemove(id)).addOnSuccessListener(x->{toast("Пользователь разблокирован");showBlockedUsers();}).addOnFailureListener(e->toast(authMessage(e))));content.addView(row,margins(12,4,12,4,60));}}).addOnFailureListener(e->toast(authMessage(e)));
    }
    void showPrivacySettings(){clear("Конфиденциальность");addPageBack(()->showSettings());addPreferenceSwitch("Показывать email в профиле","Управляет отображением в этом приложении","show_email",false);addPreferenceSwitch("Защита предпросмотра","Скрывать содержимое уведомлений","hide_previews",false);addPreferenceSwitch("Показывать статус онлайн","Настройка видимости статуса","presence_visible",true);simpleSettingRow("Заблокированные пользователи","Просмотр и снятие блокировок",()->showBlockedUsers());simpleSettingRow("Политика конфиденциальности","Посмотреть информацию",()->simpleInfo("Конфиденциальность","Не публикуй пароль, коды SMS или данные Firebase. Блокировка сохраняется в профиле пользователя. Для полного запрета чтения сообщений нужны согласованные Firestore Rules."));simpleSettingRow("Защита PIN-кодом","Блокировка приложения",()->showAppLockSettings());}
    void showNotificationSettings(){clear("Уведомления");addPageBack(()->showSettings());addPreferenceSwitch("Уведомления в приложении","Локальная настройка отображения","notifications_enabled",true);addPreferenceSwitch("Звук","Звуковые сигналы","notifications_sound",true);addPreferenceSwitch("Вибрация","Вибрация при уведомлениях","notifications_vibration",true);simpleInfo("Push-уведомления","FCM-токен этого устройства регистрируется в Firebase. Для отправки уведомлений другим участникам нужно развернуть Cloud Function из папки functions.");}
    void showDataSettings(){clear("Данные и память");addPageBack(()->showSettings());simpleSettingRow("Экспортировать данные профиля","Поделиться текстовой копией основных данных",()->shareProfileData());simpleSettingRow("Аккаунт Firebase","ID: "+(uid==null?"—":uid.substring(0,Math.min(12,uid.length()))),()->simpleInfo("Аккаунт Firebase",uid==null?"Нет активного аккаунта":"ID пользователя: "+uid));simpleSettingRow("Очистить локальные настройки","Сбросить переключатели",()->new android.app.AlertDialog.Builder(this).setTitle("Сбросить настройки?").setMessage("Все локальные настройки будут возвращены к значениям по умолчанию.").setNegativeButton("Отмена",null).setPositiveButton("Сбросить",(d,w)->{getSharedPreferences("echo_settings",MODE_PRIVATE).edit().clear().apply();toast("Настройки сброшены");showDataSettings();}).show());simpleSettingRow("Хранилище","Кэш приложения",()->simpleInfo("Хранилище","Файлы и сообщения хранятся отдельно. Эта версия не очищает данные Firestore."));simpleSettingRow("Энергосбережение","Экономия при низком заряде",()->showEnergySettings());}
    void shareProfileData(){FirebaseUser user=auth.getCurrentUser();String email=user!=null&&user.getEmail()!=null?user.getEmail():"Не указан";String data="Echo Messenger — данные профиля\nИмя: "+profileName+"\nUsername: @"+profileUsername+"\nО себе: "+profileAbout+"\nМестоположение: "+profileLocation+"\nДень рождения: "+profileBirthday+"\nEmail: "+email+"\n\nЭкспорт содержит только отображаемые данные профиля и не включает пароли, токены или личные переписки.";Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,data);startActivity(Intent.createChooser(i,"Экспорт данных Echo"));}
    void showEnergySettings(){clear("Энергосбережение");addPageBack(()->showDataSettings());addPreferenceSwitch("Экономить заряд","Уменьшить анимации приложения","battery_saver",false);addPreferenceSwitch("Уменьшить обновления","Не обновлять интерфейс без необходимости","reduced_updates",false);}
    void showLanguageSettings(){new android.app.AlertDialog.Builder(this).setTitle("Язык").setSingleChoiceItems(new String[]{"Русский","English","Українська"},0,(d,w)->{toast("Выбран язык: "+new String[]{"Русский","English","Українська"}[w]+". Полный перевод будет добавлен отдельно.");d.dismiss();}).setNegativeButton("Отмена",null).show();}
    void addPreferenceSwitch(String name,String description,String key,boolean def){android.content.SharedPreferences prefs=getSharedPreferences("echo_settings",MODE_PRIVATE);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(8),dp(12),dp(8));row.setBackground(glass(16));LinearLayout textCol=new LinearLayout(this);textCol.setOrientation(LinearLayout.VERTICAL);TextView a=tv(name,16,TEXT);a.setTypeface(null,Typeface.BOLD);TextView b=tv(description,12,MUTED);textCol.addView(a,new LinearLayout.LayoutParams(-1,dp(28)));textCol.addView(b,new LinearLayout.LayoutParams(-1,dp(34)));row.addView(textCol,new LinearLayout.LayoutParams(0,dp(64),1));Switch sw=new Switch(this);sw.setButtonTintList(null);sw.setChecked(prefs.getBoolean(key,def));sw.setOnCheckedChangeListener((button,checked)->prefs.edit().putBoolean(key,checked).apply());row.addView(sw);row.setOnClickListener(v->sw.setChecked(!sw.isChecked()));content.addView(row,margins(12,5,12,5,80));}
    void simpleSettingRow(String name,String subtitle,Runnable action){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(16),dp(8),dp(16),dp(8));r.setBackground(glass(16));LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);TextView a=tv(name,16,TEXT);a.setTypeface(null,Typeface.BOLD);TextView b=tv(subtitle,13,MUTED);t.addView(a,new LinearLayout.LayoutParams(-1,dp(30)));t.addView(b,new LinearLayout.LayoutParams(-1,dp(26)));r.addView(t,new LinearLayout.LayoutParams(0,dp(58),1));TextView arrow=tv(ico("›"),26,MUTED);r.addView(arrow);r.setOnClickListener(v->action.run());content.addView(r,margins(12,5,12,5,76));}
    void addPageBack(Runnable action){Button back=btn("‹  Назад");back.setOnClickListener(v->action.run());content.addView(back,margins(12,4,12,10,48));}
    void confirmLogout(){new android.app.AlertDialog.Builder(this).setTitle("Выйти из аккаунта?").setMessage("Тебе потребуется войти снова, чтобы пользоваться Echo.").setNegativeButton("Отмена",null).setPositiveButton("Выйти",(d,w)->{if(uid!=null)AccountStore.forgetPassword(this,uid);if(listener!=null){listener.remove();listener=null;}auth.signOut();uid=null;content=null;showAuth();}).show();}
    void addSetting(String i,String n,String s){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(16),dp(8),dp(16),dp(8));r.setBackground(glass(18));TextView ic=tv(ico(i),24,TEXT);ic.setGravity(Gravity.CENTER);r.addView(ic,new LinearLayout.LayoutParams(dp(52),dp(62)));LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);TextView a=tv(n,16,TEXT);a.setTypeface(null,Typeface.BOLD);TextView b=tv(s,13,MUTED);t.addView(a,new LinearLayout.LayoutParams(-1,dp(30)));t.addView(b,new LinearLayout.LayoutParams(-1,dp(28)));r.addView(t,new LinearLayout.LayoutParams(0,dp(70),1));content.addView(r,margins(12,5,12,5,80));}

    // ===== QR scanner (Google code scanner, no camera permission needed) =====
    void scanQr(){
        try{
            com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(this).startScan()
                .addOnSuccessListener(barcode->handleScannedCode(barcode.getRawValue()))
                .addOnFailureListener(e->toast("Сканер недоступен: "+e.getMessage()));
        }catch(Exception e){toast("Сканер недоступен на этом устройстве");}
    }
    void handleScannedCode(String raw){
        if(raw==null||!raw.startsWith("echo://u/")){toast("Это не QR-код Echo");return;}
        final String uname=raw.substring("echo://u/".length()).trim();
        if(uname.isEmpty()){toast("Пустой QR-код");return;}
        db.collection("users").whereEqualTo("username",uname).limit(1).get().addOnSuccessListener(snap->{
            if(!snap.isEmpty()){DocumentSnapshot u=snap.getDocuments().get(0);contactActions(u.getId(),userLabel(u,uname));return;}
            db.collection("users").whereEqualTo("username",uname.toLowerCase(java.util.Locale.ROOT)).limit(1).get().addOnSuccessListener(s2->{
                if(s2.isEmpty()){toast("Пользователь @"+uname+" не найден");return;}
                DocumentSnapshot u=s2.getDocuments().get(0);
                contactActions(u.getId(),userLabel(u,uname));
            }).addOnFailureListener(e->toast("Ошибка поиска: "+authMessage(e)));
        }).addOnFailureListener(e->toast("Ошибка поиска: "+authMessage(e)));
    }

    // ===== Unread counters =====
    void markChatRead(String chatId){
        getSharedPreferences("echo_read",MODE_PRIVATE).edit().putLong("r_"+chatId,System.currentTimeMillis()).apply();
        unread.remove(chatId);
        unreadChecked.remove(chatId);
        updateNavBadge();
    }
    void refreshUnread(String chatId,long lastAt,Runnable done){
        if(uid==null||db==null)return;
        android.content.SharedPreferences rp=getSharedPreferences("echo_read",MODE_PRIVATE);
        long lastRead=rp.getLong("r_"+chatId,0);
        if(lastRead==0){rp.edit().putLong("r_"+chatId,System.currentTimeMillis()).apply();return;}
        if(lastAt<=lastRead){
            if(unread.remove(chatId)!=null){updateNavBadge();done.run();}
            return;
        }
        Long prevChecked=unreadChecked.get(chatId);
        if(prevChecked!=null&&prevChecked==lastAt)return; // already counted for this last message
        unreadChecked.put(chatId,lastAt);
        messagesOf(chatId).whereGreaterThan("createdAt",new java.util.Date(lastRead)).limit(100).get().addOnSuccessListener(snap->{
            int n=0;
            for(DocumentSnapshot m:snap.getDocuments()){String sdr=m.getString("sender");if(sdr!=null&&!sdr.equals(uid))n++;}
            if(n>0)unread.put(chatId,n);else unread.remove(chatId);
            updateNavBadge();
            done.run();
        }).addOnFailureListener(e->unreadChecked.remove(chatId));
    }
    void updateNavBadge(){
        if(navBadge==null)return;
        int total=0;
        for(int v:unread.values())total+=v;
        navBadge.setText(total>99?"99+":String.valueOf(total));
        navBadge.setVisibility(total>0?android.view.View.VISIBLE:android.view.View.GONE);
    }
    void addHeaderStackAvatar(String name){
        if(avatarStack==null||!"Чаты".equals(titleBase)||avatarStack.getChildCount()>=3)return;
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(36),dp(36));
        lp.leftMargin=-dp(12);
        avatarStack.addView(avatar(name,dp(36)),lp);
    }
    void sendChatMessage(String chatId,boolean general,String text,Runnable onOk){
        if(uid==null)return;
        Map<String,Object> m=new HashMap<>();
        m.put("text",text);
        m.put("sender",uid);
        m.put("senderName",profileName);
        m.put("createdAt",FieldValue.serverTimestamp());
        m.put("readBy",java.util.Arrays.asList(uid));
        messagesOf(chatId).add(m).addOnSuccessListener(r->{
            if(!general){
                Map<String,Object> up=new HashMap<>();
                up.put("lastText",text);
                up.put("lastSender",profileName);
                up.put("lastAt",FieldValue.serverTimestamp());
                db.collection("chats").document(chatId).update(up);
            }
            if(onOk!=null)onOk.run();
        }).addOnFailureListener(e->toast("Не удалось отправить: "+authMessage(e)));
    }

    // ===== Chat wallpapers =====
    final String[] WALLPAPERS={"Каракули","Однотонный тёмный","Синий","Зелёный","Фиолетовый","Закат","Зимняя ночь (по умолчанию)"};
    String wallpaperName(){
        int w=getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("wallpaper",6);
        return WALLPAPERS[Math.max(0,Math.min(w,WALLPAPERS.length-1))];
    }
    android.graphics.drawable.Drawable makeWallpaper(){
        int w=Math.max(0,Math.min(getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("wallpaper",6),WALLPAPERS.length-1));
        int[][] c={{Color.rgb(24,34,45),Color.rgb(28,42,56)},{BG,BG},{Color.rgb(24,56,110),Color.rgb(18,30,64)},{Color.rgb(18,70,58),Color.rgb(14,36,40)},{Color.rgb(70,40,120),Color.rgb(30,22,66)},{Color.rgb(120,56,60),Color.rgb(50,30,60)},{Color.rgb(7,44,40),Color.rgb(3,20,28)}};
        DoodleDrawable dd=new DoodleDrawable(c[w][0],c[w][1],w!=1,getResources().getDisplayMetrics().density);
        dd.winter=(w==6);
        return dd;
    }
    // фон чата: обои (+ сугробы для зимних) + снег
    android.graphics.drawable.Drawable chatBackground(){
        float dn=getResources().getDisplayMetrics().density;
        java.util.ArrayList<android.graphics.drawable.Drawable> ls=new java.util.ArrayList<>();
        ls.add(makeWallpaper());
        if(frostCache&&getSharedPreferences("echo_settings",MODE_PRIVATE).getInt("wallpaper",6)==6)ls.add(new WinterDecor.Drift(dn));
        ls.add(new SnowDrawable(dn,getSharedPreferences("echo_settings",MODE_PRIVATE)));
        return new android.graphics.drawable.LayerDrawable(ls.toArray(new android.graphics.drawable.Drawable[0]));
    }
    void showWallpaperPicker(){
        android.content.SharedPreferences prefs=getSharedPreferences("echo_settings",MODE_PRIVATE);
        new android.app.AlertDialog.Builder(this).setTitle("Обои чата").setSingleChoiceItems(WALLPAPERS,prefs.getInt("wallpaper",6),(dlg,which)->{
            prefs.edit().putInt("wallpaper",which).apply();
            dlg.dismiss();
            showChatSettings();
        }).setNegativeButton("Отмена",null).show();
    }
    static class DoodleDrawable extends android.graphics.drawable.Drawable{
        final int c1,c2;
        final boolean pattern;
        boolean winter;
        final float d;
        final android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final android.graphics.Path path=new android.graphics.Path();
        android.graphics.Shader shader;
        DoodleDrawable(int c1,int c2,boolean pattern,float d){this.c1=c1;this.c2=c2;this.pattern=pattern;this.d=d;}
        @Override protected void onBoundsChange(android.graphics.Rect b){
            shader=new android.graphics.LinearGradient(0,b.top,0,b.bottom,c1,c2,android.graphics.Shader.TileMode.CLAMP);
        }
        @Override public void draw(android.graphics.Canvas cv){
            android.graphics.Rect b=getBounds();
            if(shader==null)onBoundsChange(b);
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setShader(shader);
            cv.drawRect(b,p);
            p.setShader(null);
            if(!pattern)return;
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(1.5f*d);
            p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            p.setColor(Color.argb(26,255,255,255));
            float cell=58*d;
            int row=0;
            for(float y=b.top+cell/2;y<b.bottom;y+=cell){
                int col=0;
                for(float x=b.left+cell/2+(row%2==1?cell/2:0);x<b.right;x+=cell){
                    doodle(cv,x,y,(row*5+col*3)%6);
                    col++;
                }
                row++;
            }
        }
        void doodle(android.graphics.Canvas cv,float x,float y,int k){
            float r=8*d;
            if(winter){
                // снежинка: три луча + точка
                if(k%3==0){for(int i=0;i<3;i++){double a=Math.PI/3*i;float dx=(float)Math.cos(a)*r*.9f,dy=(float)Math.sin(a)*r*.9f;cv.drawLine(x-dx,y-dy,x+dx,y+dy,p);}}
                else if(k%3==1){cv.drawCircle(x,y,r*.22f,p);}
                else{cv.drawLine(x-r*.5f,y,x+r*.5f,y,p);cv.drawLine(x,y-r*.5f,x,y+r*.5f,p);}
                return;
            }
            switch(k){
                case 0: cv.drawCircle(x,y,r,p);break;
                case 1: cv.drawLine(x-r,y,x+r,y,p);cv.drawLine(x,y-r,x,y+r,p);break;
                case 2: cv.drawRoundRect(x-r,y-r*0.7f,x+r,y+r*0.7f,3*d,3*d,p);break;
                case 3: path.reset();path.moveTo(x,y-r);path.lineTo(x+r,y+r*0.8f);path.lineTo(x-r,y+r*0.8f);path.close();cv.drawPath(path,p);break;
                case 4: cv.drawArc(x-r,y-r*0.6f,x+r,y+r*0.6f,0,180,false,p);break;
                default: cv.drawLine(x-r*0.7f,y-r*0.7f,x+r*0.7f,y+r*0.7f,p);cv.drawLine(x-r*0.7f,y+r*0.7f,x+r*0.7f,y-r*0.7f,p);
            }
        }
        @Override public void setAlpha(int a){}
        @Override public void setColorFilter(android.graphics.ColorFilter f){}
        @Override public int getOpacity(){return android.graphics.PixelFormat.OPAQUE;}
    }

    // ===== Echo Stars, gifts, business profile (beta: stored on the device, no payments, no Storage) =====
    int starBalance(){return getSharedPreferences("echo_stars",MODE_PRIVATE).getInt("balance",0);}
    void setStarBalance(int v){getSharedPreferences("echo_stars",MODE_PRIVATE).edit().putInt("balance",v).apply();}
    void showStars(){
        clear("Звёзды Echo");
        addPageBack(()->showSettings());
        android.content.SharedPreferences sp=getSharedPreferences("echo_stars",MODE_PRIVATE);
        TextView big=tv(ico("★ "+starBalance()),42,Color.rgb(255,196,60));
        big.setTypeface(null,Typeface.BOLD);
        big.setGravity(Gravity.CENTER);
        content.addView(big,margins(12,16,12,0,74));
        TextView cap=tv("Баланс звёзд",14,MUTED);
        cap.setGravity(Gravity.CENTER);
        content.addView(cap,margins(12,0,12,12,28));
        boolean can=System.currentTimeMillis()-sp.getLong("bonus_at",0)>=24L*60*60*1000;
        Button bonus=btn(can?"Получить ежедневный бонус  +10":"Бонус получен — приходи завтра");
        bonus.setEnabled(can);
        bonus.setBackground(bg(can?ACCENT:CARD2,18));
        bonus.setOnClickListener(v->{setStarBalance(starBalance()+10);sp.edit().putLong("bonus_at",System.currentTimeMillis()).apply();showStars();});
        content.addView(bonus,margins(12,6,12,8,52));
        Button gift=btn("Отправить подарок");
        gift.setOnClickListener(v->showGiftFlow());
        content.addView(gift,margins(12,4,12,8,52));
        TextView note=tv("Бета-режим: звёзды хранятся на этом устройстве и тратятся на подарки. Реальные платежи не подключены.",12,MUTED);
        note.setPadding(dp(16),dp(8),dp(16),dp(8));
        content.addView(note);
    }
    void showGiftFlow(){
        if(uid==null){simpleInfo("Подарки","Войди в аккаунт.");return;}
        clear("Отправка подарка");
        addPageBack(()->showStars());
        TextView bal=tv(ico("Твой баланс: ★ "+starBalance()),14,Color.rgb(255,196,60));
        bal.setPadding(dp(16),0,dp(16),0);
        content.addView(bal,margins(0,6,0,6,32));
        final String[] emo={"🎁","🌹","🧸","💎","🏆"};
        final String[] names={"Сюрприз","Роза","Мишка","Алмаз","Кубок"};
        final int[] cost={10,15,25,50,100};
        for(int i=0;i<emo.length;i++){
            final int idx=i;
            Button b=btn(ico(emo[i]+"  "+names[i]+"  ·  ★ "+cost[i]));
            content.addView(b,margins(12,4,12,4,52));
            b.setOnClickListener(v->chooseGiftRecipient(emo[idx],names[idx],cost[idx]));
        }
    }
    void chooseGiftRecipient(String emoji,String giftName,int cost){
        if(starBalance()<cost){toast("Не хватает звёзд. Забери ежедневный бонус в разделе «Звёзды Echo»");return;}
        db.collection("users").limit(50).get().addOnSuccessListener(snap->{
            java.util.ArrayList<String> ids=new java.util.ArrayList<>();
            java.util.ArrayList<String> labels=new java.util.ArrayList<>();
            for(DocumentSnapshot u:snap.getDocuments()){
                if(u.getId().equals(uid))continue;
                ids.add(u.getId());
                labels.add(userLabel(u,"Пользователь"));
            }
            if(ids.isEmpty()){toast("Пока некому отправить подарок");return;}
            new android.app.AlertDialog.Builder(this).setTitle(ico("Кому отправить "+emoji+"?")).setItems(labels.toArray(new String[0]),(dlg,which)->{
                pendingGift=emoji+" Подарок: "+giftName;
                pendingGiftCost=cost;
                pendingGiftAt=System.currentTimeMillis();
                openDirectChat(ids.get(which),labels.get(which));
            }).show();
        }).addOnFailureListener(e->toast("Не удалось загрузить контакты: "+authMessage(e)));
    }
    void showBusiness(){
        clear("Echo для бизнеса");
        addPageBack(()->showSettings());
        final android.content.SharedPreferences bp=getSharedPreferences("echo_business",MODE_PRIVATE);
        TextView intro=tv("Данные компании показываются в твоём профиле на этом устройстве.",13,MUTED);
        intro.setPadding(dp(16),dp(4),dp(16),dp(8));
        content.addView(intro);
        final String[] keys={"name","about","address","hours","greeting"};
        String[] hints={"Название компании","Описание","Адрес","Часы работы","Приветственное сообщение"};
        final EditText[] fields=new EditText[keys.length];
        for(int i=0;i<keys.length;i++){
            fields[i]=edit(hints[i],false);
            fields[i].setText(bp.getString(keys[i],""));
            content.addView(fields[i],margins(14,4,14,4,52));
        }
        Button save=btn("Сохранить");
        save.setBackground(bg(DEEP,18));
        save.setOnClickListener(v->{
            android.content.SharedPreferences.Editor ed=bp.edit();
            for(int j=0;j<keys.length;j++)ed.putString(keys[j],fields[j].getText().toString().trim());
            ed.apply();
            toast("Сохранено");
            showSettings();
        });
        content.addView(save,margins(14,10,14,8,52));
    }

    // ===== Edit channel / group (owner only) =====
    void showEditChat(String chatId,String name,String type,String owner){
        boolean channel=type.equals("channel");
        clear(channel?"Изменить канал":"Изменить группу");
        LinearLayout page=profilePage(()->showChatProfile(chatId,name,type,owner));
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(88),dp(88));
        avp.gravity=Gravity.CENTER_HORIZONTAL;
        avp.bottomMargin=dp(10);
        page.addView(avatar(name,dp(88)),avp);
        EditText nameInput=edit("Название",false);
        nameInput.setText(name);
        page.addView(nameInput,margins(0,0,0,8,52));
        EditText descInput=edit("Описание",false);
        descInput.setSingleLine(false);
        descInput.setMinLines(3);
        descInput.setMaxLines(6);
        descInput.setGravity(Gravity.TOP|Gravity.START);
        page.addView(descInput,margins(0,0,0,8,110));
        final String[] curUser={""};
        EditText userInput=null;
        int[] userState={3};
        if(channel){
            TextView[] stOut=new TextView[1];
            String defHint="Публичная ссылка @username. Оставь пустым, чтобы убрать.";
            userInput=usernameRow(page,stOut,defHint);
            userState=attachUsernameChecker(userInput,stOut[0],defHint,curUser,true,chatId);
        }
        final EditText userField=userInput;
        LinearLayout info=addCard(page);
        addProfileDetail(info,"ℹ","Тип",channel?"Публичный канал":"Группа",()->{});
        addProfileDetail(info,"★","Администраторы","Только владелец",()->{});
        Button save=btn("Сохранить");
        save.setBackground(bg(DEEP,18));
        page.addView(save,margins(0,6,0,8,52));
        db.collection("chats").document(chatId).get().addOnSuccessListener(d->{
            String ds=d.getString("description");
            if(ds!=null)descInput.setText(ds);
            String cu=d.getString("username");
            if(userField!=null){curUser[0]=cu==null?"":cu;userField.setText(curUser[0]);}
            String pm=d.getString("pinnedMessageText");
            if(pm!=null&&!pm.isEmpty()){
                Button unpin=btn("Открепить сообщение");
                unpin.setOnClickListener(x->db.collection("chats").document(chatId).update("pinnedMessageId",FieldValue.delete(),"pinnedMessageText",FieldValue.delete()).addOnSuccessListener(z->{toast("Сообщение откреплено");showEditChat(chatId,name,type,owner);}));
                page.addView(unpin,margins(0,0,0,8,48));
            }
        });
        save.setOnClickListener(x->{
            String n=nameInput.getText().toString().trim();
            if(n.isEmpty()){toast("Введи название");return;}
            Map<String,Object> up=new HashMap<>();
            up.put("name",n);
            up.put("description",descInput.getText().toString().trim());
            final String newUn=userField==null?curUser[0]:cleanUsername(userField.getText());
            final String oldUn=curUser[0];
            if(userField==null||newUn.equals(oldUn)){
                db.collection("chats").document(chatId).update(up).addOnSuccessListener(z->{toast("Сохранено");showChatProfile(chatId,n,type,owner);}).addOnFailureListener(e->toast("Не удалось сохранить: "+authMessage(e)));
                return;
            }
            if(!newUn.isEmpty()){String unErr=usernameError(newUn);if(unErr!=null){toast(unErr);return;}}
            if(uid==null)return;
            save.setEnabled(false);
            // release the old @name and claim the new one together with the chat update
            db.runTransaction(tr->{
                DocumentReference chatRef=db.collection("chats").document(chatId);
                DocumentReference newRef=newUn.isEmpty()?null:db.collection("usernames").document(newUn);
                DocumentReference oldRef=oldUn.isEmpty()?null:db.collection("usernames").document(oldUn);
                DocumentSnapshot ns=newRef==null?null:tr.get(newRef);
                DocumentSnapshot os=oldRef==null?null:tr.get(oldRef);
                if(ns!=null&&ns.exists())throw new FirebaseFirestoreException("taken",FirebaseFirestoreException.Code.ALREADY_EXISTS);
                if(oldRef!=null&&os!=null&&os.exists()&&chatId.equals(os.getString("chatId")))tr.delete(oldRef);
                if(newRef!=null){Map<String,Object> claim=new HashMap<>();claim.put("uid",uid);claim.put("kind","channel");claim.put("chatId",chatId);tr.set(newRef,claim);}
                up.put("username",newUn.isEmpty()?FieldValue.delete():newUn);
                tr.update(chatRef,up);
                return null;
            }).addOnSuccessListener(z->{toast("Сохранено");showChatProfile(chatId,n,type,owner);}).addOnFailureListener(e->{
                save.setEnabled(true);
                if(isCode(e,FirebaseFirestoreException.Code.ALREADY_EXISTS))toast("@"+newUn+" уже занято — выбери другое");
                else if(isCode(e,FirebaseFirestoreException.Code.PERMISSION_DENIED))toast("Нет доступа. Опубликуй обновлённые firestore.rules и повтори.");
                else toast("Не удалось сохранить: "+authMessage(e));
            });
        });
    }
}
