package com.echo.messenger;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

import java.util.Random;

/**
 * Зимний декор: иней с сосульками сверху экрана, сугробы под навигацией
 * и снежная «шапка» на плавающей панели. Пути и градиенты строятся один раз
 * при смене размеров; в draw() только заливка готового Path.
 */
public final class WinterDecor {
    private WinterDecor() {}

    private static float noise(Random r, float lo, float hi) { return lo + r.nextFloat() * (hi - lo); }

    /** Снежный карниз у верхнего края экрана + сосульки, на кончиках которых бегает блик. */
    public static class FrostEdge extends Drawable {
        private final float d;
        private float insetTop = 0f;
        private final Path snow = new Path();
        private final Path ice = new Path();
        private final Path shade = new Path();
        private final Paint snowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint icePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float[] tipX = new float[0], tipY = new float[0];
        private boolean scheduled;
        private final Runnable tick = new Runnable() {
            @Override public void run() { scheduled = false; invalidateSelf(); }
        };

        public FrostEdge(float density) {
            d = density;
            glint.setColor(Color.WHITE);
            glint.setStyle(Paint.Style.STROKE);
            glint.setStrokeCap(Paint.Cap.ROUND);
            glint.setStrokeWidth(1.4f * d);
        }

        public void setInset(float px) {
            if (Math.abs(px - insetTop) < 0.5f) return;
            insetTop = px;
            if (!getBounds().isEmpty()) build(getBounds());
            invalidateSelf();
        }

        @Override protected void onBoundsChange(Rect b) { build(b); }

        private void build(Rect b) {
            snow.reset(); ice.reset(); shade.reset();
            float w = b.width();
            float base = Math.max(0f, insetTop - 5f * d);       // карниз сидит у нижней кромки статус-бара
            float cap = 9f * d;
            Random r = new Random(77);
            // карниз: сверху ровно, снизу волнистая кромка
            snow.moveTo(0, 0);
            snow.lineTo(w, 0);
            snow.lineTo(w, base + cap * .4f);
            float x = w;
            while (x > 0) {
                float step = noise(r, 18f * d, 40f * d);
                float nx = Math.max(0f, x - step);
                float hgt = base + cap * noise(r, .55f, 1.0f);
                snow.quadTo((x + nx) / 2f, hgt + cap * .35f, nx, base + cap * noise(r, .35f, .7f));
                x = nx;
            }
            snow.close();
            // сосульки
            int n = 0;
            float[] tx = new float[40], ty = new float[40];
            float px = 62f * d;                                  // слева — под аватар/кнопку «назад», не рисуем
            while (px < w - 14f * d && n < 40) {
                float wid = noise(r, 4.5f * d, 9f * d);
                float len = noise(r, 5f * d, 17f * d);
                float y0 = base + cap * .55f;
                ice.moveTo(px - wid / 2f, y0);
                ice.quadTo(px - wid * .18f, y0 + len * .55f, px, y0 + len);
                ice.quadTo(px + wid * .18f, y0 + len * .55f, px + wid / 2f, y0);
                ice.close();
                tx[n] = px; ty[n] = y0 + len; n++;
                px += noise(r, 26f * d, 70f * d);
            }
            tipX = new float[n]; tipY = new float[n];
            System.arraycopy(tx, 0, tipX, 0, n);
            System.arraycopy(ty, 0, tipY, 0, n);
            snowPaint.setShader(new LinearGradient(0, 0, 0, base + cap * 1.4f,
                    new int[]{0xFFFFFFFF, 0xFFEAF5FF, 0xFFC9E3F8}, new float[]{0f, .6f, 1f}, Shader.TileMode.CLAMP));
            icePaint.setShader(new LinearGradient(0, base, 0, base + 24f * d,
                    new int[]{0xEEF4FBFF, 0xB8BFE3FF, 0x70A5D4FF}, new float[]{0f, .6f, 1f}, Shader.TileMode.CLAMP));
            shadePaint.setColor(0x33081A24);
            shade.set(snow);
            shade.offset(0, 2.2f * d);
        }

        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            if (b.isEmpty()) return;
            c.drawPath(shade, shadePaint);
            c.drawPath(ice, icePaint);
            c.drawPath(snow, snowPaint);
            boolean anim = !SnowDrawable.systemReduceMotion && tipX.length > 0;
            if (anim) {
                long now = SystemClock.uptimeMillis();
                int idx = (int) ((now / 1300L) % tipX.length);
                float ph = (now % 1300L) / 1300f;
                float a = (float) Math.sin(Math.PI * ph);
                float s = (2.5f + 3.5f * a) * d;
                glint.setAlpha((int) (235 * a));
                c.drawLine(tipX[idx] - s, tipY[idx], tipX[idx] + s, tipY[idx], glint);
                c.drawLine(tipX[idx], tipY[idx] - s, tipX[idx], tipY[idx] + s, glint);
                if (!scheduled) {
                    scheduled = true;
                    scheduleSelf(tick, now + (SnowDrawable.powerSaving ? 120 : 66));
                }
            }
        }

        @Override public boolean setVisible(boolean visible, boolean restart) {
            boolean ch = super.setVisible(visible, restart);
            if (!visible) { unscheduleSelf(tick); scheduled = false; }
            else if (ch) invalidateSelf();
            return ch;
        }
        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter cf) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Снежная шапка для верхней кромки стеклянной панели (рисуется в границах Drawable). */
    public static class SnowCap extends Drawable {
        private final float d;
        private final long seed;
        private final Path path = new Path();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path shadePath = new Path();

        public SnowCap(float density, long seed) { d = density; this.seed = seed; shade.setColor(0x2A06141E); }

        @Override protected void onBoundsChange(Rect b) {
            path.reset();
            Random r = new Random(seed);
            float w = b.width(), top = b.top, hh = b.height();
            path.moveTo(b.left, top + hh * .30f);
            float x = 0;
            while (x < w) {
                float step = noise(r, 14f * d, 34f * d);
                float nx = Math.min(w, x + step);
                path.quadTo(b.left + (x + nx) / 2f, top - hh * noise(r, .05f, .30f),
                        b.left + nx, top + hh * noise(r, .25f, .50f));
                x = nx;
            }
            // нижняя кромка с каплями
            path.lineTo(b.right, top + hh * .62f);
            x = w;
            while (x > 0) {
                float step = noise(r, 10f * d, 30f * d);
                float nx = Math.max(0f, x - step);
                path.quadTo(b.left + (x + nx) / 2f, top + hh * noise(r, .75f, 1.0f),
                        b.left + nx, top + hh * noise(r, .50f, .68f));
                x = nx;
            }
            path.close();
            shadePath.set(path);
            shadePath.offset(0, 1.6f * d);
            paint.setShader(new LinearGradient(0, top, 0, b.bottom,
                    new int[]{0xFFFFFFFF, 0xFFEAF5FF, 0xFFBFDDF5}, new float[]{0f, .55f, 1f}, Shader.TileMode.CLAMP));
        }

        @Override public void draw(Canvas c) {
            if (getBounds().isEmpty()) return;
            c.drawPath(shadePath, shade);
            c.drawPath(path, paint);
        }
        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter cf) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Мягкие сугробы у нижнего края окна: за стеклянной навигацией они красиво «преломляются». */
    public static class Drift extends Drawable {
        private final float d;
        private final Path back = new Path(), front = new Path();
        private final Paint pb = new Paint(Paint.ANTI_ALIAS_FLAG), pf = new Paint(Paint.ANTI_ALIAS_FLAG);

        public Drift(float density) { d = density; }

        @Override protected void onBoundsChange(Rect b) {
            back.reset(); front.reset();
            float w = b.width(), bot = b.bottom, h = Math.min(b.height() * .16f, 150f * d);
            Random r = new Random(5);
            back.moveTo(b.left, bot);
            back.lineTo(b.left, bot - h * .55f);
            float x = 0;
            while (x < w) {
                float nx = Math.min(w, x + noise(r, 90f * d, 190f * d));
                back.quadTo(b.left + (x + nx) / 2f, bot - h * noise(r, .85f, 1.25f), b.left + nx, bot - h * noise(r, .45f, .75f));
                x = nx;
            }
            back.lineTo(b.right, bot);
            back.close();
            front.moveTo(b.left, bot);
            front.lineTo(b.left, bot - h * .32f);
            x = 0;
            while (x < w) {
                float nx = Math.min(w, x + noise(r, 110f * d, 230f * d));
                front.quadTo(b.left + (x + nx) / 2f, bot - h * noise(r, .55f, .85f), b.left + nx, bot - h * noise(r, .22f, .42f));
                x = nx;
            }
            front.lineTo(b.right, bot);
            front.close();
            pb.setShader(new LinearGradient(0, bot - h, 0, bot,
                    new int[]{0x38CFE8FF, 0x14CFE8FF}, null, Shader.TileMode.CLAMP));
            pf.setShader(new LinearGradient(0, bot - h * .8f, 0, bot,
                    new int[]{0x66FFFFFF, 0x26BFE0FF}, null, Shader.TileMode.CLAMP));
        }

        @Override public void draw(Canvas c) {
            if (getBounds().isEmpty()) return;
            c.drawPath(back, pb);
            c.drawPath(front, pf);
        }
        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter cf) {}
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
