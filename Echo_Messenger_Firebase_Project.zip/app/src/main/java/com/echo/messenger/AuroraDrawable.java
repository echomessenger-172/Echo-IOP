package com.echo.messenger;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Тёмный хвойный фон с тремя размытыми пятнами: изумруд, лёд, мята. Стеклянные панели поверх него
 * получают живые цвета. Градиенты создаются один раз, анимация — только матрицы.
 */
public class AuroraDrawable extends Drawable {
    private static final int[] COLORS = {
            Color.rgb(30, 215, 120), Color.rgb(90, 200, 255), Color.rgb(0, 185, 160)};
    private final int base;
    private final Paint basePaint = new Paint();
    private final Paint[] orbs = new Paint[3];
    private final RadialGradient[] shaders = new RadialGradient[3];
    private final Matrix m = new Matrix();
    private float phase = 0f;
    private float orbRadius = 1f;

    public AuroraDrawable(int baseColor) {
        base = baseColor;
        basePaint.setColor(baseColor);
        for (int i = 0; i < 3; i++) orbs[i] = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    @Override protected void onBoundsChange(Rect b) {
        orbRadius = Math.max(b.width(), b.height()) * .62f;
        for (int i = 0; i < 3; i++) {
            shaders[i] = new RadialGradient(0, 0, Math.max(orbRadius, 1f),
                    new int[]{Color.argb(138, Color.red(COLORS[i]), Color.green(COLORS[i]), Color.blue(COLORS[i])),
                            Color.argb(0, Color.red(COLORS[i]), Color.green(COLORS[i]), Color.blue(COLORS[i]))},
                    null, Shader.TileMode.CLAMP);
            orbs[i].setShader(shaders[i]);
        }
    }

    /** phase: 0..1 — один полный цикл дрейфа. */
    public void setPhase(float p) {
        // ~12 кадров/с достаточно для медленного дрейфа и экономит батарею
        if (p != 0f && Math.abs(p - phase) < 0.002f) return;
        phase = p;
        invalidateSelf();
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        c.drawRect(b, basePaint);
        double a = phase * Math.PI * 2;
        float w = b.width(), h = b.height();
        float[][] pos = {
                {w * (.15f + .10f * (float) Math.sin(a)), h * (.10f + .08f * (float) Math.cos(a))},
                {w * (.90f + .08f * (float) Math.cos(a + 2)), h * (.45f + .10f * (float) Math.sin(a + 1))},
                {w * (.30f + .12f * (float) Math.sin(a + 4)), h * (.95f + .05f * (float) Math.cos(a + 3))}};
        for (int i = 0; i < 3; i++) {
            if (shaders[i] == null) continue;
            m.setTranslate(pos[i][0], pos[i][1]);
            shaders[i].setLocalMatrix(m);
            c.drawRect(b, orbs[i]);
        }
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter cf) {}
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
