package com.echo.messenger;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

import java.util.Random;

/**
 * Зимний снегопад 2.0. Три слоя глубины, мягкие боке-снежинки и настоящие
 * кристаллы-снежинки (вращаются), порывы ветра, мерцание. Всё рисуется готовыми
 * спрайтами (drawBitmap) — без блюра и без аллокаций в draw().
 * Плотность: «Лёгкий» / «Обычный» / «Метель» (настройка snow_level).
 * Сам планирует кадры, останавливается когда View скрыт, замедляется в режиме
 * энергосбережения и полностью выключается настройками или системным
 * «Убрать анимации».
 */
public class SnowDrawable extends Drawable {
    private static final int MAX = 150;
    private static final int[] LEVEL_COUNT = {50, 90, 150};
    private static final long GUST_MS = 2600;
    private static final long IDLE_MS = 1000;

    /** Выставляется из MainActivity: системная экономия заряда / «Убрать анимации». */
    public static volatile boolean powerSaving = false;
    public static volatile boolean systemReduceMotion = false;

    private static Bitmap DOT, CRYSTAL;

    private final float[] x0 = new float[MAX], speed = new float[MAX], off = new float[MAX];
    private final float[] phase = new float[MAX], freq = new float[MAX], sway = new float[MAX];
    private final float[] size = new float[MAX], depthArr = new float[MAX], spin = new float[MAX];
    private final int[] alpha = new int[MAX];
    private final boolean[] crystal = new boolean[MAX], twinkle = new boolean[MAX];

    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();
    private final Matrix m = new Matrix();
    private final float density;
    private final SharedPreferences prefs;

    private int count = LEVEL_COUNT[1];
    private boolean enabled = true;
    private boolean scheduled = false;
    private long lastPrefCheck = 0;
    private long gustT0 = -100000;
    private float gustDir = 1f;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            scheduled = false;
            invalidateSelf();
        }
    };

    public SnowDrawable(float density, SharedPreferences settings) {
        this.density = density;
        this.prefs = settings;
        ensureSprites();
        Random r = new Random(2026);
        for (int i = 0; i < MAX; i++) {
            float depth = r.nextFloat();                      // 0 — далеко, 1 — близко
            depthArr[i] = depth;
            x0[i] = r.nextFloat();
            off[i] = r.nextFloat();
            phase[i] = r.nextFloat() * 6.2831855f;
            freq[i] = .35f + r.nextFloat() * .8f;
            sway[i] = 6f + r.nextFloat() * 18f;
            crystal[i] = (i % 7 == 3);
            twinkle[i] = (i % 5 == 0);
            if (crystal[i]) {
                size[i] = 5f + depth * 5f;                    // половина ширины кристалла, dp
                speed[i] = .028f + depth * .035f;
                alpha[i] = 150 + (int) (depth * 100);
                spin[i] = (r.nextFloat() - .5f) * 90f;        // градусов в секунду
            } else {
                size[i] = 0.9f + depth * depth * 3.0f;
                speed[i] = .035f + depth * .080f + r.nextFloat() * .02f;
                alpha[i] = 90 + (int) (depth * 160);
            }
        }
    }

    private static synchronized void ensureSprites() {
        if (DOT == null) {
            int s = 48;
            Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setShader(new RadialGradient(s / 2f, s / 2f, s / 2f,
                    new int[]{0xFFFFFFFF, 0xF2FFFFFF, 0x40D6EBFF, 0x00D6EBFF},
                    new float[]{0f, .36f, .72f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(s / 2f, s / 2f, s / 2f, p);
            DOT = b;
        }
        if (CRYSTAL == null) {
            int s = 96;
            float cx = s / 2f, cy = s / 2f;
            Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setShader(new RadialGradient(cx, cy, s / 2f,
                    new int[]{0x40BFE0FF, 0x00BFE0FF}, null, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, s / 2f, glow);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(0xFFF2FAFF);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(4f);
            for (int i = 0; i < 6; i++) {
                c.save();
                c.rotate(60f * i, cx, cy);
                c.drawLine(cx, cy, cx, cy - 40f, p);
                c.drawLine(cx, cy - 22f, cx + 10f, cy - 33f, p);
                c.drawLine(cx, cy - 22f, cx - 10f, cy - 33f, p);
                c.drawLine(cx, cy - 33f, cx + 6f, cy - 39f, p);
                c.drawLine(cx, cy - 33f, cx - 6f, cy - 39f, p);
                c.restore();
            }
            Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
            core.setColor(0xFFFFFFFF);
            c.drawCircle(cx, cy, 4.5f, core);
            CRYSTAL = b;
        }
    }

    private void refreshEnabled() {
        long now = SystemClock.uptimeMillis();
        if (now - lastPrefCheck < 800) return;
        lastPrefCheck = now;
        if (prefs == null) { enabled = !systemReduceMotion; return; }
        enabled = prefs.getBoolean("winter_snow", true)
                && prefs.getBoolean("chat_animations", true)
                && !prefs.getBoolean("battery_saver", false)
                && !systemReduceMotion;
        int lvl = Math.max(0, Math.min(2, prefs.getInt("snow_level", 1)));
        count = LEVEL_COUNT[lvl];
        if (powerSaving) count = Math.min(count, 45);
    }

    /** Порыв ветра: снег плавно сносит в сторону и возвращает (вызывается по тапу на «Echo»). */
    public void gust() {
        gustT0 = SystemClock.uptimeMillis();
        gustDir = (gustT0 & 1L) == 0L ? 1f : -1f;
        invalidateSelf();
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        refreshEnabled();
        if (enabled) {
            final float w = b.width(), h = b.height();
            final long now = SystemClock.uptimeMillis();
            final float t = (now % 3_600_000L) / 1000f;
            final float wind = (float) (Math.sin(t * .17) + .5 * Math.sin(t * .43 + 1.0)) * 40f * density;
            float gust = 0f;
            long gt = now - gustT0;
            if (gt >= 0 && gt < GUST_MS) {
                gust = gustDir * (float) Math.sin(Math.PI * gt / (float) GUST_MS) * 190f * density;
            }
            final float dotScale = DOT.getWidth();
            for (int i = 0; i < count; i++) {
                final float depth = depthArr[i];
                final float r = size[i] * density;
                final float travel = h + 6f * r;
                final float y = ((t * speed[i] + off[i]) % 1f) * travel - 3f * r;
                float x = x0[i] * w + (float) Math.sin(t * freq[i] + phase[i]) * sway[i] * density
                        + (wind + gust) * (.35f + depth);
                final float mg = r * 3f, span = w + 2f * mg;
                x = ((x + mg) % span + span) % span - mg;
                float a = alpha[i];
                if (twinkle[i]) a *= .68f + .32f * (float) Math.sin(t * 3.1f + phase[i] * 3f);
                paint.setAlpha((int) a);
                if (crystal[i]) {
                    final float sc = (r * 2f) / CRYSTAL.getWidth();
                    m.setTranslate(-CRYSTAL.getWidth() / 2f, -CRYSTAL.getHeight() / 2f);
                    m.postRotate(phase[i] * 57.3f + t * spin[i]);
                    m.postScale(sc, sc);
                    m.postTranslate(b.left + x, b.top + y);
                    c.drawBitmap(CRYSTAL, m, paint);
                } else {
                    final float hr = r * 2.4f;
                    dst.set(b.left + x - hr, b.top + y - hr, b.left + x + hr, b.top + y + hr);
                    c.drawBitmap(DOT, null, dst, paint);
                }
            }
        }
        if (!scheduled) {
            scheduled = true;
            long frame = powerSaving ? 50 : 33;
            scheduleSelf(tick, SystemClock.uptimeMillis() + (enabled ? frame : IDLE_MS));
        }
    }

    @Override public boolean setVisible(boolean visible, boolean restart) {
        boolean changed = super.setVisible(visible, restart);
        if (!visible) {
            unscheduleSelf(tick);
            scheduled = false;
        } else if (changed) {
            invalidateSelf();
        }
        return changed;
    }

    @Override public void setAlpha(int a) {}
    @Override public void setColorFilter(ColorFilter cf) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
