package com.echo.messenger;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.HashMap;
import java.util.Map;

public class EchoMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL = "echo_messages";
    @Override public void onNewToken(String token) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String,Object> data = new HashMap<>(); data.put("fcmToken", token); data.put("fcmTokenUpdatedAt", com.google.firebase.firestore.FieldValue.serverTimestamp());
        db.collection("users").document(uid).set(data, com.google.firebase.firestore.SetOptions.merge());
        String deviceId = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        if (deviceId != null) {
            Map<String,Object> session = new HashMap<>();
            session.put("deviceId", deviceId); session.put("deviceName", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
            session.put("platform", "Android"); session.put("fcmToken", token); session.put("lastActiveAt", com.google.firebase.firestore.FieldValue.serverTimestamp()); session.put("appVersion", "0.5.0 Beta");
            db.collection("users").document(uid).collection("sessions").document(deviceId).set(session, com.google.firebase.firestore.SetOptions.merge());
        }
    }
    @Override public void onMessageReceived(RemoteMessage message) {
        String title = message.getNotification()!=null && message.getNotification().getTitle()!=null ? message.getNotification().getTitle() : "Echo Messenger";
        String body = message.getNotification()!=null && message.getNotification().getBody()!=null ? message.getNotification().getBody() : "Новое сообщение";
        NotificationManager manager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Сообщения Echo",NotificationManager.IMPORTANCE_HIGH));
        Intent intent=new Intent(this,MainActivity.class); intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        NotificationCompat.Builder n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH);
        manager.notify((int)System.currentTimeMillis(),n.build());
    }
}
