package com.echo.messenger;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Список аккаунтов, с которых пользователь входил на этом устройстве.
 * Пароль (только для входа по почте) хранится зашифрованным ключом из AndroidKeyStore —
 * ключ нельзя достать из устройства, поэтому переключение аккаунтов не требует повторного ввода пароля.
 */
public final class AccountStore {
    private static final String PREFS = "echo_accounts";
    private static final String KEY_LIST = "list";
    private static final String ALIAS = "echo_accounts_key";

    public static final class Entry {
        public String uid = "", email = "", phone = "", name = "", username = "", pw = "";

        public String label() {
            if (name != null && !name.isEmpty()) return name;
            if (username != null && !username.isEmpty()) return "@" + username;
            if (email != null && !email.isEmpty()) return email;
            if (phone != null && !phone.isEmpty()) return phone;
            return "Аккаунт Echo";
        }

        public String subtitle() {
            StringBuilder sb = new StringBuilder();
            if (username != null && !username.isEmpty()) sb.append('@').append(username);
            String contact = email != null && !email.isEmpty() ? email : phone;
            if (contact != null && !contact.isEmpty()) {
                if (sb.length() > 0) sb.append("  •  ");
                sb.append(contact);
            }
            return sb.toString();
        }

        public boolean canSwitchSilently() {
            return email != null && !email.isEmpty() && pw != null && !pw.isEmpty();
        }
    }

    private AccountStore() {}

    public static List<Entry> all(Context c) {
        ArrayList<Entry> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY_LIST, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Entry e = new Entry();
                e.uid = o.optString("uid");
                e.email = o.optString("email");
                e.phone = o.optString("phone");
                e.name = o.optString("name");
                e.username = o.optString("username");
                e.pw = decrypt(o.optString("pw"));
                if (!e.uid.isEmpty()) out.add(e);
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Добавляет или обновляет аккаунт. pw == null — оставить ранее сохранённый пароль. */
    public static void save(Context c, String uid, String email, String phone, String name, String username, String pw) {
        if (uid == null || uid.isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY_LIST, "[]"));
            JSONObject target = null;
            for (int i = 0; i < arr.length(); i++) {
                if (uid.equals(arr.getJSONObject(i).optString("uid"))) { target = arr.getJSONObject(i); break; }
            }
            if (target == null) { target = new JSONObject(); target.put("uid", uid); arr.put(target); }
            if (email != null) target.put("email", email);
            if (phone != null) target.put("phone", phone);
            if (name != null && !name.isEmpty()) target.put("name", name);
            if (username != null && !username.isEmpty()) target.put("username", username);
            if (pw != null && !pw.isEmpty()) {
                String enc = encrypt(pw);
                if (!enc.isEmpty()) target.put("pw", enc);
            }
            prefs(c).edit().putString(KEY_LIST, arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    public static void remove(Context c, String uid) {
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY_LIST, "[]"));
            JSONArray next = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                if (!uid.equals(arr.getJSONObject(i).optString("uid"))) next.put(arr.getJSONObject(i));
            }
            prefs(c).edit().putString(KEY_LIST, next.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** Забыть сохранённый пароль (например, если он перестал подходить). */
    public static void forgetPassword(Context c, String uid) {
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY_LIST, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (uid.equals(o.optString("uid"))) o.remove("pw");
            }
            prefs(c).edit().putString(KEY_LIST, arr.toString()).apply();
        } catch (Exception ignored) { }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    private static String encrypt(String plain) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = cipher.getIV();
            byte[] ct = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private static String decrypt(String stored) {
        if (stored == null || !stored.contains(":")) return "";
        try {
            String[] parts = stored.split(":");
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] ct = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }
}
