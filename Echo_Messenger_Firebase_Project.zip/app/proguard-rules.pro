# Echo Messenger
-keepattributes SourceFile,LineNumberTable,Signature,*Annotation*
-renamesourcefileattribute SourceFile
-allowaccessmodification
-optimizationpasses 5
-assumenosideeffects class android.util.Log { public static int d(...); public static int v(...); }
