# Echo Messenger 0.5.0 Beta — feature status

## Retained from the uploaded project
- Firebase email/phone authentication and email verification flow
- Username onboarding and uniqueness check
- Profile editing and user search
- Direct chat creation, chat list, groups and channels
- Existing Firestore security rules and owner moderation Cloud Functions

## Added in this archive
- Version metadata: `versionCode 5`, `versionName 0.5.0-beta`
- FCM token registration after sign-in and on token refresh
- Current Android device session metadata under `users/{uid}/sessions/{androidId}`
- Current-device session screen in Settings
- `notifyChatMembers` Cloud Function for new chat messages
- Firestore rules for session documents
- Liquid Glass preference toggle in chat settings

## Still needs implementation/configuration before calling it complete
- Message edit/delete/reactions/read receipts need end-to-end validation against the deployed rules.
- Push delivery requires deployment of Cloud Functions and correct FCM project configuration.
- Voice messages require a media upload endpoint or externally hosted URL; Firebase Storage is not used.
- Echo Plus needs a trusted entitlement/payment policy; the current screen is informational.
- Full session revocation for other devices requires a trusted Admin SDK function.
- Liquid Glass toggle currently saves the preference; it does not yet restyle every screen.
- Run GitHub Actions to verify compilation; no successful build is claimed by this archive.
