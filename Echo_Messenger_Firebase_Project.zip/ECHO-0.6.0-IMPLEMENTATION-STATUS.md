# Echo Messenger 0.6.0 Beta — current patch status

Implemented in this patch:
- Android app version bumped to 0.6.0-beta / versionCode 6.
- Message long-press menu can save a message to Favorites.
- Favorites screen loads saved items from Firestore, supports text notes, copy and delete.
- Local chat-folder names can be created/deleted.
- PIN setup stores a SHA-256 hash locally and provides a manual PIN verification dialog.
- Text Stories can be created and listed for the current user with 24-hour expiry metadata.
- Settings links added for these features, Easter Eggs and Echo Plus 2.0.
- Firestore rules added for per-user Favorites and Stories.

Not yet complete / requires next implementation pass:
- End-to-end voice messages: no media upload backend is configured; Firebase Storage remains excluded.
- Automatic PIN gate on app launch/background and biometric unlock.
- Actual chat-to-folder assignment/filtering.
- Cross-user Stories feed, media Stories and expiration cleanup job.
- Full Echo Easter egg image trigger.
- Complete Echo Plus subscription/payment backend.
- Full group/channel role and invitation improvements.

Build status: source ZIP assembled; Android compilation and live Firebase behavior have not been verified in this environment. Run GitHub Actions before installing.
