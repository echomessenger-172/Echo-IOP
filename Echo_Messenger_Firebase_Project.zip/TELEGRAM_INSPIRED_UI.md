# Echo Messenger — Telegram-inspired UI update

- Replaced bottom navigation emoji with Android Vector Drawable icons (Chats, Contacts, Settings, Profile).
- Removed emoji prefixes from chat list rows and new-chat menu options.
- Updated accent/background colors toward a clean Telegram-inspired blue/dark palette.
- Kept Echo branding and existing Firebase/auth/chat code.

This is an original implementation inspired by common messenger layout patterns, not a pixel-perfect copy of Telegram's proprietary assets.

Build via the existing GitHub Actions workflow. The project has not been compiled in this environment; test the workflow before installing.
