# Echo Messenger 0.10.0 Beta

Android messenger source project. Version: `1.1.0` (versionCode 12) — см. WINTER_UPDATE.md.

### Included in 0.9.0 Beta
- Echo Assist Beta with local draft templates and Android sharing.
- Echo Plus profile-accent preview presets saved on-device.
- Export/share visible profile data.
- Existing text-only Stories and community entry from 0.8.0 Beta.

### Build on GitHub Actions
1. Upload/extract this project into your repository, preserving `.github/workflows/build.yml`.
2. Add your Firebase project's `app/google-services.json` (not included in this archive).
3. Open **Actions → Build Echo Messenger APK → Run workflow**.
4. Download the APK artifact after a successful run.

Firebase Storage is not used or required. The app depends on Firebase Auth, Firestore, Messaging, and Functions. Compilation must be verified by running the repository workflow; no complete Gradle build was run while preparing this archive.


См. TELEGRAM_VIDEO_UI.md — обновление интерфейса по видеозаписи.
См. LIQUID_GLASS_AND_MOTION.md — liquid glass, анимации переходов, оптимизация.
См. CHANNEL_USERNAMES.md — username каналов и проверка username.

См. ECHO-0.10.0-CHANGES.md — автоблокировка, пагинация, медиа, правила (0.10.0).
